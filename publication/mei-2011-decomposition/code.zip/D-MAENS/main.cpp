#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "functions.h"

int vertex_num;
int req_edge_num;
int req_arc_num;
int nonreq_edge_num;
int nonreq_arc_num;
int task_num;
int total_arc_num;
int vehicle_num;
int capacity;
int lower_bound;

int DEPOT;

int trav_cost[MAX_NODE_TAG_LENGTH][MAX_NODE_TAG_LENGTH];
int serve_cost[MAX_NODE_TAG_LENGTH][MAX_NODE_TAG_LENGTH];
int shortest_path[MAX_NODE_TAG_LENGTH][MAX_NODE_TAG_LENGTH][MAX_NODE_TAG_LENGTH];
int min_cost[MAX_NODE_TAG_LENGTH][MAX_NODE_TAG_LENGTH];

individual nondominated_indis[MAX_NONDOMINATED_NUM];
individual pop[MAX_TOTALSIZE];
individual inter_pop[MAX_TOTALSIZE];
individual sub_pop[MAX_TOTALSIZE];
individual total_pop[MAX_TOTALSIZE];
int popsize = 60;
int nondominated_num;
int max_ndtotalcost;
int min_ndtotalcost;
int max_ndmaxlength;
int min_ndmaxlength;

int exc_min_f1;
int exc_min_f2;
int exc_max_f1;
int exc_max_f2; // f1 = total_cost, f2 = max_length
int min_f1;
int max_f1;
int min_f2;
int max_f2;
double norm_f1;
double norm_f2;

char dummy_string[50];
char curr_file[50];
char output_file[50];

char input_file[100] = "instance/example.dat"; // the instance can be changed here

task inst_tasks[MAX_TASK_TAG_LENGTH];
arc inst_arcs[MAX_ARCS_TAG_LENGTH];

int main(void)
{
	/* input and preprocessing */

	FILE *fp;

	fp = fopen(input_file, "r");

	req_arc_num = 0;
	nonreq_arc_num = 0;
	
	while (1)
	{
		fscanf(fp, "%s", dummy_string);
		//printf("dummy_string = %s\n", dummy_string);
			
		if (strcmp(dummy_string, "VERTICES") == 0)
		{
			fscanf(fp, "%s", dummy_string);
			fscanf(fp, "%d", &vertex_num);
		}
		else if (strcmp(dummy_string, "ARISTAS_REQ") == 0)
		{
			fscanf(fp, "%s", dummy_string);
			fscanf(fp, "%d", &req_edge_num);
		}
		else if (strcmp(dummy_string, "ARISTAS_NOREQ") == 0)
		{
			fscanf(fp, "%s", dummy_string);
			fscanf(fp, "%d", &nonreq_edge_num);
		}
		else if (strcmp(dummy_string, "VEHICULOS") == 0)
		{
			fscanf(fp, "%s", dummy_string);
			fscanf(fp, "%d", &vehicle_num);
		}
		else if (strcmp(dummy_string, "CAPACIDAD") == 0)
		{
			fscanf(fp, "%s", dummy_string);
			fscanf(fp, "%d", &capacity);
		}
		else if (strcmp(dummy_string, "LISTA_ARISTAS_REQ") == 0)
		{
			task_num = 2*req_edge_num+req_arc_num;
			total_arc_num = task_num+2*nonreq_edge_num+nonreq_arc_num;

			fscanf(fp, "%s", dummy_string);

			for (int i = 1; i <= req_edge_num; i++)
			{
				fscanf(fp, "%s", dummy_string);
				fscanf(fp, "%d,", &inst_tasks[i].head_node);
				fscanf(fp, "%d)", &inst_tasks[i].tail_node);
				fscanf(fp, "%s", dummy_string);
				fscanf(fp, "%d", &inst_tasks[i].serv_cost);
				fscanf(fp, "%s", dummy_string);
				fscanf(fp, "%d", &inst_tasks[i].demand);
				inst_tasks[i].dead_cost = inst_tasks[i].serv_cost;
				inst_tasks[i].inverse = i+req_edge_num;
				
				inst_tasks[i+req_edge_num].head_node = inst_tasks[i].tail_node;
				inst_tasks[i+req_edge_num].tail_node = inst_tasks[i].head_node;
				inst_tasks[i+req_edge_num].dead_cost = inst_tasks[i].dead_cost;
				inst_tasks[i+req_edge_num].serv_cost = inst_tasks[i].serv_cost;
				inst_tasks[i+req_edge_num].demand = inst_tasks[i].demand;
				inst_tasks[i+req_edge_num].inverse = i;

				inst_arcs[i].head_node = inst_tasks[i].head_node;
				inst_arcs[i].tail_node = inst_tasks[i].tail_node;
				inst_arcs[i].trav_cost = inst_tasks[i].dead_cost;
				inst_arcs[i+req_edge_num].head_node = inst_arcs[i].tail_node;
				inst_arcs[i+req_edge_num].tail_node = inst_arcs[i].head_node;
				inst_arcs[i+req_edge_num].trav_cost = inst_arcs[i].trav_cost;
			}
		}
		else if (strcmp(dummy_string, "LISTA_ARISTAS_NOREQ") == 0)
		{
			fscanf(fp, "%s", dummy_string);
		
			for (int i = task_num+1; i <= task_num+nonreq_edge_num; i++)
			{
				fscanf(fp, "%s", dummy_string);
				fscanf(fp, "%d,", &inst_arcs[i].head_node);
				fscanf(fp, "%d)", &inst_arcs[i].tail_node);
				fscanf(fp, "%s", dummy_string);
				fscanf(fp, "%d", &inst_arcs[i].trav_cost);

				inst_arcs[i+nonreq_edge_num].head_node = inst_arcs[i].tail_node;
				inst_arcs[i+nonreq_edge_num].tail_node = inst_arcs[i].head_node;
				inst_arcs[i+nonreq_edge_num].trav_cost = inst_arcs[i].trav_cost;
			}
		}
		else if (strcmp(dummy_string, "DEPOSITO") == 0)
		{
			fscanf(fp, "%s", dummy_string);
			fscanf(fp, "%d", &DEPOT);
			break;
		}
	}

	fclose(fp);

	inst_tasks[DUMMY_CYCLE].tail_node = DEPOT;
	inst_tasks[DUMMY_CYCLE].head_node = DEPOT;
	inst_tasks[DUMMY_CYCLE].dead_cost = 0;
	inst_tasks[DUMMY_CYCLE].serv_cost = 0;
	inst_tasks[DUMMY_CYCLE].demand = 0;
	inst_tasks[DUMMY_CYCLE].inverse = DUMMY_CYCLE;
	inst_arcs[DUMMY_CYCLE].tail_node = 1;
	inst_arcs[DUMMY_CYCLE].head_node = 1;
	inst_arcs[DUMMY_CYCLE].trav_cost = 0;

	for (int i = 1; i <= vertex_num; i++)
	{
		for (int j = 1; j <= vertex_num; j++)
		{
			trav_cost[i][j] = INF;
			serve_cost[i][j] = 0;
		}
	}

	for (int i = 1; i <= total_arc_num; i++)
	{
		trav_cost[inst_arcs[i].tail_node][inst_arcs[i].head_node] = inst_arcs[i].trav_cost;
	}

	for (int i = 1; i <= task_num; i++)
	{
		serve_cost[inst_tasks[i].tail_node][inst_tasks[i].head_node] = inst_tasks[i].serv_cost;
	}

	mod_dijkstra();
			
	/* get output_file */

	char output_file[100] = "output.dat"; // the name of the output file can be set here

	/* random seed */

	clock_t start = clock();

	int tm;
	tm = time(NULL);
	//tm = 1239002157;
	srand(tm);

	//printf("tm = %d\n", tm);

	fp = fopen(output_file, "w");

	fprintf(fp, "The random seed is %d.\n", tm);
	fprintf(fp, "There are %d vertices, %d tasks, and the capacities of vehicles is %d.\n\n", vertex_num, req_edge_num+req_arc_num, capacity);

	fclose(fp);

	/* got LBs of makespan */

	double lamda[MAX_TOTALSIZE];
	for (int i = 0; i < popsize; i++)
	{
		lamda[i] = 1.0*i/(popsize-1);
		//lamda[i] = 1.0*(i+1)/(popsize+1);
	}
	int neighborhoods[MAX_TOTALSIZE][NHSIZE+1];
	for (int i = 0; i < popsize; i++)
	{
		neighborhoods[i][0] = 0;
	}

	for (int i = 0; i < popsize; i++)
	{
		int start = i-NHSIZE/2;
		int finish = i+NHSIZE/2;

		if (start < 0)
		{
			start = 0;
			finish = start+NHSIZE-1;
		}
		if (finish > popsize-1)
		{
			finish = popsize-1;
			start = finish-NHSIZE+1;
		}

		for (int j = start; j <= finish; j++)
		{
			neighborhoods[i][0] ++;
			neighborhoods[i][neighborhoods[i][0]] = j;
		}
	}

	/* initialization */

	individual elite_indi[3], tmp_indi;
	int serve_mark[MAX_TASK_TAG_LENGTH];

	nondominated_num = 0;

	int used;

	memset(serve_mark, 0, sizeof(serve_mark));
	serve_mark[0] = task_num;
	for (int i = 1; i <= task_num; i++)
	{
		serve_mark[i] = 1;
	}
	path_scanning(&elite_indi[0], inst_tasks, serve_mark);
	elite_indi[0].total_vio_load = 0;

	memset(serve_mark, 0, sizeof(serve_mark));
	serve_mark[0] = task_num;
	for (int i = 1; i <= task_num; i++)
	{
		serve_mark[i] = 1;
	}
	augment_merge(&elite_indi[1], inst_tasks, serve_mark);
	elite_indi[1].total_vio_load = 0;

	memset(serve_mark, 0, sizeof(serve_mark));
	serve_mark[0] = task_num;
	for (int i = 1; i <= task_num; i++)
	{
		serve_mark[i] = 1;
	}
	ulusoy_heuristic(&elite_indi[2], inst_tasks, serve_mark);
	elite_indi[2].total_vio_load = 0;

	for (int i = 0; i < 2; i++)
	{
		for (int j = i+1; j < 3; j++)
		{
			if (elite_indi[j].max_length < elite_indi[i].max_length || 
				(elite_indi[j].max_length == elite_indi[i].max_length && elite_indi[j].total_cost > elite_indi[i].total_cost))
			{
				indi_copy(&tmp_indi, &elite_indi[i]);
				indi_copy(&elite_indi[i], &elite_indi[j]);
				indi_copy(&elite_indi[j], &tmp_indi);
			}
		}
	}

	int tmp_popsize = 0;
	individual init_indi;
	while (tmp_popsize < 3)
	{
		indi_copy(&init_indi, &elite_indi[tmp_popsize]);
		tmp_popsize ++;
		indi_copy(&pop[tmp_popsize-1], &init_indi);
		nondominated_num = modify_nondominated_indis(nondominated_indis, nondominated_num, &init_indi);
	}
	while (tmp_popsize < popsize)
	{
		int trial = 0;
		while (trial < M_trial)
		{
			memset(serve_mark, 0, sizeof(serve_mark));
			serve_mark[0] = task_num;
			for (int i = 1; i <= task_num; i++)
			{
				serve_mark[i] = 1;
			}

			rand_scanning(&init_indi, inst_tasks, serve_mark);

			used = 0;
			for (int i = 0; i < tmp_popsize; i++)
			{
				if (init_indi.max_length == pop[i].max_length && init_indi.total_cost == pop[i].total_cost)
				{
					used = 1;
					break;
				}
			}

			if (!used)
				break;
		}

		if (trial == M_trial && used)
		{
			popsize = tmp_popsize;
			break;
		}

		tmp_popsize ++;
		indi_copy(&pop[tmp_popsize-1], &init_indi);
		nondominated_num = modify_nondominated_indis(nondominated_indis, nondominated_num, &init_indi);
	}

	printf("nondominated\n");
	for (int i = 0; i < nondominated_num; i++)
	{
		printf("(%d, %d, %d)\n", nondominated_indis[i].max_length, nondominated_indis[i].total_cost, nondominated_indis[i].total_vio_load);
	}

	min_f1 = INF;
	max_f1 = 0;
	min_f2 = INF;
	max_f2 = 0;

	for (int i = 0; i < popsize; i++)
	{
		//if (pop[i].total_vio_load > 0)
		//	continue;

		if (pop[i].total_vio_load == 0 && pop[i].total_cost < min_f1)
			min_f1 = pop[i].total_cost;
		if (pop[i].total_vio_load == 0 && pop[i].total_cost > max_f1)
			max_f1 = pop[i].total_cost;
		if (pop[i].total_vio_load == 0 && pop[i].max_length < min_f2)
			min_f2 = pop[i].max_length;
		if (pop[i].total_vio_load == 0 && pop[i].max_length > max_f2)
			max_f2 = pop[i].max_length;
	}

	/* searching phase */

	int ite = 0, wite = 0;
	individual parent1, parent2, xed_child, mted_child, child;

	int offsize = popsize; // the number of the generated offsprings
	int totalsize = popsize+offsize; // the number of the sum of the current population and the offsprings

	while (ite < M_ite)
	{
		//printf("min_f1 = %d, min_f2 = %d, max_f1 = %d, max_f2 = %d\n", min_f1, min_f2, max_f1, max_f2);
		ite ++;
		wite ++;

		// sorting of pop

		for (int i = 0; i < popsize-1; i++)
		{
			for (int j = i+1; j < popsize; j++)
			{
				if (pop[j].max_length < pop[i].max_length ||
					(pop[j].max_length == pop[i].max_length && pop[j].total_cost > pop[i].total_cost))
				{
					indi_copy(&tmp_indi, &pop[i]);
					indi_copy(&pop[i], &pop[j]);
					indi_copy(&pop[j], &tmp_indi);
				}
			}
		}

		/* generate offsprings */

		for (int i = 0; i < popsize; i++) // for each individual, i.e., each subproblem 
		{
			child.total_cost = 0; // child does not exist

			int k1, k2, pid1, pid2;
			int candi[NHSIZE+1];
			memcpy(candi, neighborhoods[i], sizeof(neighborhoods[i]));

			k1 = rand_choose(candi[0]);
			while (1)
			{
				k2 = rand_choose(candi[0]);
				if (k2 != k1)
					break;
			}
			pid1 = candi[k1];
			pid2 = candi[k2];
			//printf("k1 = %d, k2 = %d, popsize = %d\n", k1, k2, popsize);
			indi_copy(&parent1, &pop[pid1]);
			indi_copy(&parent2, &pop[pid2]);

			//printf("ite = %d, i = %d\n", ite, i);

			SBX(&xed_child, &parent1, &parent2, inst_tasks); // crossover

			//printf("xed totalcost = %d, maxlength = %d, tvl = %d\n", xed_child.total_cost, xed_child.max_length, xed_child.total_vio_load);

			used = 0; 
			for (int j = 1; j <= neighborhoods[i][0]; j++)
			{
				if (xed_child.max_length == pop[neighborhoods[i][j]].max_length && xed_child.total_cost == pop[neighborhoods[i][j]].total_cost &&
					xed_child.total_vio_load == pop[neighborhoods[i][j]].total_vio_load)
				{
					used = 1;
					break;
				}
			}

			if (!used)
			{
				indi_copy(&child, &xed_child);
			}

			//printf("ite = %d, i = %d\n", ite, i);
					
			double random = 1.0*rand()/RAND_MAX;
			if (random < M_PROB)
				//if (ite%10 == 0)
			{
				//printf("before totalcost = %d, maxlength = %d, tvl = %d\n", xed_child.total_cost, xed_child.max_length, xed_child.total_vio_load);
				lns_mut(&mted_child, &xed_child, inst_tasks, lamda[i]);
				//printf("after totalcost = %d, maxlength = %d, tvl = %d\n", mted_child.total_cost, mted_child.max_length, mted_child.total_vio_load);

				used = 0;
				for (int j = 1; j <= neighborhoods[i][0]; j++)
				{
					if (mted_child.max_length == pop[neighborhoods[i][j]].max_length && mted_child.total_cost == pop[neighborhoods[i][j]].total_cost &&
						mted_child.total_vio_load == pop[neighborhoods[i][j]].total_vio_load)
					{
						used = 1;
						break;
					}
				}

				if (!used)
				{
					indi_copy(&child, &mted_child);
				}
			}

			//indi_copy(&child, &mted_child);

			if (child.total_vio_load == 0 && child.total_cost > 0)
			{
				nondominated_num = modify_nondominated_indis(nondominated_indis, nondominated_num, &child);

				if (child.total_cost < min_f1)
					min_f1 = child.total_cost;
				if (child.total_cost > max_f1)
					max_f1 = child.total_cost;
				if (child.max_length < min_f2)
					min_f2 = child.max_length;
				if (child.max_length > max_f2)
					max_f2 = child.max_length;
			}

			if (child.total_cost  == 0)
			{
				indi_copy(&inter_pop[i], &pop[i]);
			}
			else
			{
				indi_copy(&inter_pop[i], &child);
			}
		}

		// sorting of pop

		for (int i = 0; i < popsize-1; i++)
		{
			for (int j = i+1; j < popsize; j++)
			{
				if (inter_pop[j].max_length < inter_pop[i].max_length ||
					(inter_pop[j].max_length == inter_pop[i].max_length && inter_pop[j].total_cost > inter_pop[i].total_cost))
				{
					indi_copy(&tmp_indi, &inter_pop[i]);
					indi_copy(&inter_pop[i], &inter_pop[j]);
					indi_copy(&inter_pop[j], &tmp_indi);
				}
			}
		}

		for (int i = 0; i < popsize; i++)
		{
			indi_copy(&total_pop[i], &pop[i]);
			indi_copy(&total_pop[i+popsize], &inter_pop[i]);
		}

		domination_sort(total_pop, 2*popsize);

		if (total_pop[popsize-1].rank == total_pop[popsize].rank)
		{
			front_crowdness_sort(total_pop, total_pop[popsize-1].rank, 2*popsize);
		}

		for (int i = 0; i < popsize; i++)
		{
			indi_copy(&pop[i], &total_pop[i]);
		}

		if (ite%10 == 0)
		{
			printf("ite = %d\n", ite);
			printf("nondominated\n");
			for (int i = 0; i < nondominated_num; i++)
			{
				printf("(%d, %d, %d)\n", nondominated_indis[i].max_length, nondominated_indis[i].total_cost, nondominated_indis[i].total_vio_load);
			}
		}

		for (int i = 0; i < nondominated_num-1; i++)
		{
			for (int j = i+1; j < nondominated_num; j++)
			{
				if (nondominated_indis[j].total_cost < nondominated_indis[i].total_cost)
				{
					indi_copy(&tmp_indi, &nondominated_indis[i]);
					indi_copy(&nondominated_indis[i], &nondominated_indis[j]);
					indi_copy(&nondominated_indis[j], &tmp_indi);
				}
			}
		}
	}

	clock_t finish = clock();
	double duration = (double)(finish-start)/CLOCKS_PER_SEC;
	    
	fp = fopen(output_file, "a");

	fprintf(fp, "Number of nondominated solutions is %d\n", nondominated_num);
	for (int i = 0; i < nondominated_num; i++)
	{
		fprintf(fp, "Solution %d: makespan = %d, total cost = %d\n", i, nondominated_indis[i].max_length, nondominated_indis[i].total_cost);
	}

	fprintf(fp, "\nDuration time = %f seconds\n", duration);
	fprintf(fp, "Number of iterations = %d\n", ite);
      
	fclose(fp);			
}