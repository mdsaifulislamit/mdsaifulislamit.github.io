/* The Decomposition-based Memetic Algorithm with Extended Neighborhood Search (D-MAENS) for MO-CARP */

The source codes include the following files:

main.cpp
initialization.cpp
searchoperators.cpp
arrayoperations.cpp
heuristic.cpp
functions.h

The input instance should be put in the folder "instance", in which there is already an example input file "example.dat" along with a file "Translation file.doc", giving the translation from Portuguese in the file to English. Any input file should be generated in the same form as in the file "example.dat".

The outputs are printed in the output file "output.dat".