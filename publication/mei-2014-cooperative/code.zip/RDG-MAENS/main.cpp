#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <direct.h> // to mkdir
#include "functions.h"


int node_num; // number of nodes of this instance
int req_edge_num; // number of required edges of this instance
int req_arc_num; // number of required arcs of this instance
int nonreq_edge_num; // number of nonrequired edges of this instance
int nonreq_arc_num; // number of nonrequired arcs of this instance
int task_num; // number of tasks of this instance ( = 2*req_edge_num+req_arc_num)
int total_arc_num; // number of total arcs in the graph of this instance ( = task_num+2*nonreq_edge_num+nonreq_arc_num)
int vehicle_num; // number of vehicles of this instance
int capacity;

int DEPOT;

int trav_cost[MAX_NODE_NUM][MAX_NODE_NUM]; // the traverse cost matrix between each pair of nodes
int serve_cost[MAX_NODE_NUM][MAX_NODE_NUM]; // the serve cost matrix between each pair of nodes
int shortest_path[MAX_NODE_NUM][MAX_NODE_NUM][MAX_NODE_NUM]; // the shortest path 3-D matrix between each pair of nodes, obtained by Dijkstra's method. Element [i][j][...] is the vector between i and j.
int min_cost[MAX_NODE_NUM][MAX_NODE_NUM]; // the minimal cost matrix between each pair of nodes, obtained by Dijkstra's method
double task_dist[MAX_TASK_NUM][MAX_TASK_NUM]; // pairwise distance between tasks

int popsize = 30; // population size can be set here
char test_set[50] = "beullens"; // "gve" or "eglg" or "beullens"

char input_dir[100] = "instance/";

// set of input files
char eglg_input_file_set[MAX_INSTANCE_NUM][100] = 
{
	"EGL-G1-A.dat", 
	"EGL-G1-B.dat",
	"EGL-G1-C.dat", 
	"EGL-G1-D.dat",
	"EGL-G1-E.dat",
	"EGL-G2-A.dat", 
	"EGL-G2-B.dat",
	"EGL-G2-C.dat", 
	"EGL-G2-D.dat",
	"EGL-G2-E.dat",
};

char gve_input_file_set[MAX_INSTANCE_NUM][100] = 
{
	"gdb1.dat",
	"gdb2.dat",
	"gdb3.dat",
	"gdb4.dat",
	"gdb5.dat",
	"gdb6.dat",
	"gdb7.dat",
	"gdb8.dat",
	"gdb9.dat",
	"gdb10.dat",
	"gdb11.dat",
	"gdb12.dat",
	"gdb13.dat",
	"gdb14.dat",
	"gdb15.dat",
	"gdb16.dat",
	"gdb17.dat",
	"gdb18.dat",
	"gdb19.dat",
	"gdb20.dat",
	"gdb21.dat",
	"gdb22.dat",
	"gdb23.dat",
	"val1A.dat",
	"val1B.dat",
	"val1C.dat",
	"val2A.dat",
	"val2B.dat",
	"val2C.dat",
	"val3A.dat",
	"val3B.dat",
	"val3C.dat",
	"val4A.dat",
	"val4B.dat",
	"val4C.dat",
	"val4D.dat",
	"val5A.dat",
	"val5B.dat",
	"val5C.dat",
	"val5D.dat",
	"val6A.dat",
	"val6B.dat",
	"val6C.dat",
	"val7A.dat",
	"val7B.dat",
	"val7C.dat",
	"val8A.dat",
	"val8B.dat",
	"val8C.dat",
	"val9A.dat",
	"val9B.dat",
	"val9C.dat",
	"val9D.dat",
	"val10A.dat",
	"val10B.dat",
	"val10C.dat",
	"val10D.dat",
	"egl-e1-A.dat",
	"egl-e1-B.dat",
	"egl-e1-C.dat",
	"egl-e2-A.dat",
	"egl-e2-B.dat",
	"egl-e2-C.dat",
	"egl-e3-A.dat",
	"egl-e3-B.dat",
	"egl-e3-C.dat",
	"egl-e4-A.dat",
	"egl-e4-B.dat",
	"egl-e4-C.dat",
	"egl-s1-A.dat",
	"egl-s1-B.dat",
	"egl-s1-C.dat",
	"egl-s2-A.dat",
	"egl-s2-B.dat",
	"egl-s2-C.dat",
	"egl-s3-A.dat",
	"egl-s3-B.dat",
	"egl-s3-C.dat",
	"egl-s4-A.dat",
	"egl-s4-B.dat",
	"egl-s4-C.dat",
};

char beullens_input_file_set[MAX_INSTANCE_NUM][100] = 
{
	"C01.txt", 
	"C02.txt",
	"C03.txt", 
	"C04.txt",
	"C05.txt",
	"C06.txt", 
	"C07.txt",
	"C08.txt", 
	"C09.txt",
	"C10.txt",
	"C11.txt", 
	"C12.txt",
	"C13.txt", 
	"C14.txt",
	"C15.txt",
	"C16.txt", 
	"C17.txt",
	"C18.txt", 
	"C19.txt",
	"C20.txt",
	"C21.txt", 
	"C22.txt",
	"C23.txt", 
	"C24.txt",
	"C25.txt",
	"E01.txt", 
	"E02.txt",
	"E03.txt", 
	"E04.txt",
	"E05.txt",
	"E06.txt", 
	"E07.txt",
	"E08.txt", 
	"E09.txt",
	"E10.txt",
	"E11.txt", 
	"E12.txt",
	"E13.txt", 
	"E14.txt",
	"E15.txt",
	"E16.txt", 
	"E17.txt",
	"E18.txt", 
	"E19.txt",
	"E20.txt",
	"E21.txt", 
	"E22.txt",
	"E23.txt", 
	"E24.txt",
	"E25.txt",
	"D01.txt", 
	"D02.txt",
	"D03.txt", 
	"D04.txt",
	"D05.txt",
	"D06.txt", 
	"D07.txt",
	"D08.txt", 
	"D09.txt",
	"D10.txt",
	"D11.txt", 
	"D12.txt",
	"D13.txt", 
	"D14.txt",
	"D15.txt",
	"D16.txt", 
	"D17.txt",
	"D18.txt", 
	"D19.txt",
	"D20.txt",
	"D21.txt", 
	"D22.txt",
	"D23.txt", 
	"D24.txt",
	"D25.txt",
	"F01.txt", 
	"F02.txt",
	"F03.txt", 
	"F04.txt",
	"F05.txt",
	"F06.txt", 
	"F07.txt",
	"F08.txt", 
	"F09.txt",
	"F10.txt",
	"F11.txt", 
	"F12.txt",
	"F13.txt", 
	"F14.txt",
	"F15.txt",
	"F16.txt", 
	"F17.txt",
	"F18.txt", 
	"F19.txt",
	"F20.txt",
	"F21.txt", 
	"F22.txt",
	"F23.txt", 
	"F24.txt",
	"F25.txt",
};

task inst_tasks[MAX_TASK_NUM];
arc inst_arcs[MAX_ARC_NUM];

population pop1;
population subpop[GROUP_NUM];
individual pop[MAX_TMP_POPSIZE];
individual best_fsb_solution;

int main(void)
{
	// read file according to the test set
	char input_file_set[MAX_INSTANCE_NUM][100];
	if (strcmp(test_set, "gve") == 0)
	{
		memcpy(input_file_set, gve_input_file_set, sizeof(gve_input_file_set));
	}
	else if(strcmp(test_set, "eglg") == 0)
	{
		memcpy(input_file_set, eglg_input_file_set, sizeof(eglg_input_file_set));
	}
	else if (strcmp(test_set, "beullens") == 0)
	{
		memcpy(input_file_set, beullens_input_file_set, sizeof(beullens_input_file_set));
	}

	// number of instances tested in this experiment
	int instance_num = INSTANCE_END_ID-INSTANCE_BEGIN_ID+1;
	
	for (int id = 1; id <= instance_num; id++)
	{
		// start running on this instance
		char input_file[50];
		strcpy(input_file, input_file_set[INSTANCE_BEGIN_ID+id-2]);

		/* input and preprocessing */
		char input_path[100];
		strcpy(input_path, input_dir);
		strcat(input_path, input_file);

		printf("solving instance %s\n", input_file);

		FILE *fp;
		fp = fopen(input_path, "r");

		if (strcmp(test_set, "gve") == 0)
		{
			read_gdb_val_egl(fp);
		}
		else if(strcmp(test_set, "eglg") == 0)
		{
			read_egl_large(fp);
		}
		else if(strcmp(test_set, "beullens") == 0)
		{
			read_beullens(fp);
			// if (id > 50)
				capacity = 600; // change capacity from 300 to 600 for D and F
		}

		fclose(fp);

		// output the task demand vector
		fp = fopen("taskdemand.dat", "w");
		for (int i = 1; i <= task_num; i++)
		{
			fprintf(fp, "%d\n", inst_tasks[i].demand);
		}
		fclose(fp);

		// output the task head vector
		fp = fopen("taskhead.dat", "w");
		for (int i = 1; i <= task_num; i++)
		{
			fprintf(fp, "%d\n", inst_tasks[i].head_node);
		}
		fclose(fp);

		// output the task tail vector
		fp = fopen("tasktail.dat", "w");
		for (int i = 1; i <= task_num; i++)
		{
			fprintf(fp, "%d\n", inst_tasks[i].tail_node);
		}
		fclose(fp);

		// output the min_cost matrix
		fp = fopen("mincost.dat", "w");
		for (int i = 1; i <= node_num; i++)
		{
			for (int j = 1; j <= node_num; j++)
			{
				fprintf(fp, "%d\t", min_cost[i][j]);
			}
			fprintf(fp, "\n");
		}
		fclose(fp);

		// output the task_dist matrix
		fp = fopen("taskdist.dat", "w");
		for (int i = 0; i <= task_num; i++)
		{
			for (int j = 0; j <= task_num; j++)
			{
				fprintf(fp, "%f\t", task_dist[i][j]);
			}
			fprintf(fp, "\n");
		}
		fclose(fp);

		// output the trav_cost matrix
		fp = fopen("travcost.dat", "w");
		for (int i = 1; i <= node_num; i++)
		{
			for (int j = 1; j <= node_num; j++)
			{
				fprintf(fp, "%d\t", trav_cost[i][j]);
			}
			fprintf(fp, "\n");
		}
		fclose(fp);

		/* create result directory and file */
		char res_dir[100];
		strcpy(res_dir, input_file);
		strcat(res_dir, "/");

		mkdir(res_dir);

		char res_path[MAX_RUN_NUM][100];
		int run_num = RUN_END_ID-RUN_BEGIN_ID+1;
		char run_ids[MAX_RUN_NUM][5];
		for (int r = 0; r < run_num; r++)
		{
			int num_id = RUN_BEGIN_ID+r;
			char char_id[5];
			itoa(num_id, char_id, 10);
			strcpy(run_ids[r], char_id);
		}

		for (int r = 0; r < run_num; r++)
		{
			strcpy(res_path[r], res_dir);
			strcat(res_path[r], "res");
			strcat(res_path[r], run_ids[r]);
			strcat(res_path[r], ".txt");
		}

		// start the runs
		int run_tcs[MAX_RUN_NUM];
		for (int r = 0; r < run_num; r++)
		{
			clock_t start = clock(); // start clock

			// random seed
			int tm;
			tm = time(NULL);
			//tm = 1354500171;
			srand(tm);

			//printf("tm = %d\n", tm);

			// decomposition
			int group_ids[MAX_TASK_NUM], centers[GROUP_NUM+1];

			//kcenter(group_ids, centers, task_dist, task_num, GROUP_NUM, inst_tasks);
			//
			//int total_cost0 = 0;
			///*for (int i = 1; i <= task_num/2; i++)
			//{
			//	total_cost0 += task_dist[i][centers[group_ids[i]]];
			//}*/
			//for (int g = 1; g <= GROUP_NUM; g++)
			//{
			//	int max_dist = 0;
			//	for (int i = 1; i < task_num/2; i++)
			//	{
			//		if (group_ids[i] != g)
			//			continue;

			//		for (int j = i+1; j <= task_num/2; j++)
			//		{
			//			if (group_ids[j] != g)
			//				continue;

			//			int tmp_dist = task_dist[i][j];
			//			if (tmp_dist > max_dist)
			//				max_dist = tmp_dist;
			//		}
			//	}

			//	total_cost0 += max_dist;
			//}

			/*kmedoids(group_ids, centers, task_dist, task_num, GROUP_NUM, inst_tasks);
			
			int total_cost1 = 0;
			for (int i = 1; i <= task_num/2; i++)
			{
				total_cost1 += task_dist[i][centers[group_ids[i]]];
			}*/

			/*kmedoids_cap(group_ids, centers, task_dist, capacity, task_num, GROUP_NUM, inst_tasks);

			int total_cost2 = 0;
			for (int i = 1; i <= task_num/2; i++)
			{
				total_cost2 += task_dist[i][centers[group_ids[i]]];
			}*/

			/*kmedoids_depot_cap(group_ids, centers, task_dist, capacity, task_num, GROUP_NUM, inst_tasks);

			int total_cost3 = 0;
			for (int i = 1; i <= task_num/2; i++)
			{
				total_cost3 += task_dist[i][centers[group_ids[i]]];
			}*/

			//lscluster_depot_cap(group_ids, task_dist, capacity, task_num, GROUP_NUM, inst_tasks);

			fp = fopen(res_path[r], "w");
			fprintf(fp, "The random seed is %d.\n", tm);
			fprintf(fp, "There are %d vertices, %d tasks, and the capacities of vehicles is %d.\n\n", node_num, req_edge_num+req_arc_num, capacity);
			fprintf(fp, "log_start\n");
			/*fprintf(fp, "group centers are\n");
			for (int g = 1; g <= GROUP_NUM; g++)
			{
				fprintf(fp, "%d ", centers[g]);
			}*/
			/*fprintf(fp, "\ngroup ids:\n");
			for (int i = 1; i <= group_ids[0]; i++)
			{
				fprintf(fp, "%d ", group_ids[i]);
			}*/
			fclose(fp);

			// initialize the population
			int sub_tasks[MAX_TASK_NUM]; // the subset of tasks in the subproblem
			sub_tasks[0] = task_num;
			for (int i = 1; i <= task_num; i++)
			{
				sub_tasks[i] = i;
			}
			MAENS_initialization(&best_fsb_solution, &pop1, sub_tasks, inst_tasks);

			/*for (int p = 0; p < pop1.popsize; p++)
			{
				int islegal = legal(pop1.indi[p].sequence, sub_tasks, inst_tasks);

				if (!islegal)
					continue;
			}

			int islegal = legal(best_fsb_solution.sequence, sub_tasks, inst_tasks);

			if (!islegal)
				continue;*/

			double adpt_exp[ROUND_NUM+1]; // used for defining the membership during the route distance grouping, adaptive
			adpt_exp[0] = ROUND_NUM;
			for (int i = 1; i <= ROUND_NUM; i++)
			{
				adpt_exp[i] = 1;
				//adpt_exp[i] = (-2.0/(ROUND_NUM-1))*i+(2.0*ROUND_NUM/(ROUND_NUM-1));
				//adpt_exp[i] = log(1.0*i-0.9)/log(0.5)-log(1.0*ROUND_NUM)/log(0.5);
			}
			double exp = 2; // used for defining the membership during the route distance grouping, self-adaptive
			int noimp_round = 0; // number of rounds without improvement

			int round_tc[ROUND_NUM+1];
			round_tc[0] = ROUND_NUM;
			int round_gen = floor((1.0*MAX_GEN)/ROUND_NUM);
			for (int round = 1; round <= ROUND_NUM; round++)
			{
				printf("Start round %d\n", round);

				route_distance_grouping(group_ids, GROUP_NUM, best_fsb_solution.sequence, task_dist, adpt_exp[round]);

				/*fp = fopen("groupids.txt", "w");
				for (int i = 1; i <= group_ids[0]; i++)
				{
					fprintf(fp, "%d ", group_ids[i]);
				}
				fclose(fp);*/

				// divide the population to sub-populations according to the group ids
				individual sub_best_fsb_solution[GROUP_NUM];

				// get sub_best_fsb_solution from the best_fsb_solution
				for (int g = 1; g <= GROUP_NUM; g++)
				{
					indi2subindi(&best_fsb_solution, &sub_best_fsb_solution[g-1], group_ids, g, inst_tasks);
				}

				for (int g = 1; g <= GROUP_NUM; g++)
				{
					pop2subpop(&subpop[g-1], &pop1, group_ids, g, inst_tasks);

					int sub_tasks[MAX_TASK_NUM]; // the subset of tasks in the subproblem
					sub_tasks[0] = 0;
					for (int i = 1; i <= task_num; i++)
					{
						if (group_ids[i] == g)
						{
							sub_tasks[0] ++;
							sub_tasks[sub_tasks[0]] = i;
						}
					}

					/*for (int p = 0; p < subpop[g-1].popsize; p++)
					{
						int islegal = legal(subpop[g-1].indi[p].sequence, sub_tasks, inst_tasks);

						if (!islegal)
							continue;
					}*/
				}
				
				// for each round
				for (int g = 1; g <= GROUP_NUM; g++)
				{
					printf("Start solving sub-problem %d\n", g);
					// apply MAENS loop for round_gen iterations on subpop[g-1]
					for (int ite = 0; ite < round_gen; ite++)
					{
						int wite = 0;
						MAENS_loop(&sub_best_fsb_solution[g-1], &subpop[g-1], wite, inst_tasks);

						// record the time passed and best result so far
						clock_t now_time = clock(); // finish clock
						double now_duration = (double)(now_time-start)/CLOCKS_PER_SEC;
						int now_best_tc = best_fsb_solution.total_cost;
						int tmp_tc = 0;
						for (int tg = 1; tg <= GROUP_NUM; tg++)
						{
							tmp_tc += sub_best_fsb_solution[tg-1].total_cost;
						}
						if (tmp_tc < now_best_tc)
							now_best_tc = tmp_tc;

						fp = fopen(res_path[r], "a");
						fprintf(fp, "%f %d\n", now_duration, now_best_tc);
						fclose(fp);
					}
				}

				for (int g = 1; g <= GROUP_NUM; g++)
				{
					int sub_tasks[MAX_TASK_NUM]; // the subset of tasks in the subproblem
					sub_tasks[0] = 0;
					for (int i = 1; i <= task_num; i++)
					{
						if (group_ids[i] == g)
						{
							sub_tasks[0] ++;
							sub_tasks[sub_tasks[0]] = i;
						}
					}

					/*for (int p = 0; p < subpop[g-1].popsize; p++)
					{
						int islegal = legal(subpop[g-1].indi[p].sequence, sub_tasks, inst_tasks);

						if (!islegal)
							continue;
					}*/
				}

				// combine subpop to pop1
				subpop2pop(&pop1, subpop, inst_tasks);

				int total_cost_sum = 0;
				for (int g = 1; g <= GROUP_NUM; g++)
				{
					total_cost_sum += sub_best_fsb_solution[g-1].total_cost;
				}
				if (total_cost_sum < best_fsb_solution.total_cost)
				{
					// combine the sub_best_fsb_solution to the whole best_fsb_solution
					best_fsb_solution.sequence[0] = 1;
					best_fsb_solution.route_load[0] = 0;
					best_fsb_solution.total_cost = total_cost_sum;
					for (int g = 1; g <= GROUP_NUM; g++)
					{
						best_fsb_solution.sequence[0] --;
						link_array(best_fsb_solution.sequence, sub_best_fsb_solution[g-1].sequence);
						link_array(best_fsb_solution.route_load, sub_best_fsb_solution[g-1].route_load);
					}
				}

				/*int islegal = legal(best_fsb_solution.sequence, inst_tasks);
				if (!islegal)
					continue;*/
				
				round_tc[round] = best_fsb_solution.total_cost;
				printf("After round %d, best cost = %d\n", round, best_fsb_solution.total_cost);
				
				//route_distance_grouping(group_ids, GROUP_NUM, best_fsb_solution.sequence, task_dist, adpt_exp[round]);
			}

			run_tcs[r] = best_fsb_solution.total_cost;

			clock_t finish = clock(); // finish clock
			double duration = (double)(finish-start)/CLOCKS_PER_SEC;

			fp = fopen(res_path[r], "a");
			fprintf(fp, "\nlog_ends\n");
			fprintf(fp, "\n%d round results\n", ROUND_NUM);
			for (int r = 1; r <= ROUND_NUM; r++)
			{
				fprintf(fp, "%d\n", round_tc[r]);
			}
			fprintf(fp, "\n\nThe best sequence is:\n");
			for (int i = 1; i <= best_fsb_solution.sequence[0]; i++)
			{
				fprintf(fp, "%d ", best_fsb_solution.sequence[i]);
			}
			fprintf(fp, "\nThe best node sequence is:\n");
			for (int i = 1; i < best_fsb_solution.sequence[0]; i++)
			{
				int tmp_tail = inst_tasks[best_fsb_solution.sequence[i]].tail_node;
				int tmp_head = inst_tasks[best_fsb_solution.sequence[i+1]].head_node;
				for (int j = 1; j <= shortest_path[tmp_tail][tmp_head][0]; j++)
				{
					fprintf(fp, "%d ", shortest_path[tmp_tail][tmp_head][j]);
				}
			}
			fprintf(fp, "\nThe best total cost is %d.\n", best_fsb_solution.total_cost);
			fprintf(fp, "The duration time is %f seconds.\n", duration);
			fclose(fp);
		}

		char run_tcs_path[100];
		strcpy(run_tcs_path, res_dir);
		strcat(run_tcs_path, "run_tcs.txt");

		fp = fopen(run_tcs_path, "w");
		for (int r = 0; r < run_num; r++)
		{
			fprintf(fp, "%d\n", run_tcs[r]);
		}
		fclose(fp);
	}
}