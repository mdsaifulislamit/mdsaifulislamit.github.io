
// Problem-related variables
#define INF 2100000000
#define DUMMY_CYCLE 0
#define MAX_ARC_NUM 1001 // maximal possible number of arcs in the graph
#define MAX_TASK_NUM 1001 // maximal possible number of tasks in the graph (a required edge leads to two tasks, but service on either of them is enough).
#define MAX_NODE_NUM 300 // maximal possible number of nodes ni the graph
#define MAX_ROUTE_NUM 50 // maximal possible number of routes in a solution
#define MAX_ROUTE_LENGTH 550 // maximal possible length of a route (number of tasks included in a route)
#define MAX_SOLUTION_LENGTH 550 // maximal possible length of a solution (the sequence of all the required tasks and the delimiters)

// Algorithm-related variables
#define SI 1 // id of single insertion
#define DI 2 // id of double insertion
#define SWAP 3 // id of SWAP

/* Parameters */
#define MAX_POPSIZE 30 // maximal possible population size
#define MAX_TMP_POPSIZE 210 // maximal possible temporal population size (parent size + offspring size) 
#define MAX_TRIAL 10 // during the initialization, the maximal trials to generate satisfactory initial solutions
#define MUTATION_PROB 0.2 // mutation probability
#define MAX_OFFSPRING_TRIAL 500 // maximal number of trials to generate distinct offsprings

// Parameters in Extended Neighborhood Search
#define MAX_NSIZE 10 // upper bound of nsize
#define MAX_ENSSIZE 100 // maximal ENS neighborhood size

// Parameters in decomposition
#define GROUP_NUM 2 // the number of groups to be decomposed
#define MAX_GEN 500 // maximal number of generations
#define ROUND_NUM 50 // the number of rounds to change the grouping

// Parameters of experiments
#define MAX_RUN_NUM 30 // maximal number of runs of the algorithm
#define RUN_BEGIN_ID 1 // beginning id of the run
#define RUN_END_ID 30 // end id of the run
#define MAX_INSTANCE_NUM 100 // maximal number of the tested instances
#define INSTANCE_BEGIN_ID 51 // begin id of the instances
#define INSTANCE_END_ID 73 // end id of the instances

extern int node_num; // number of nodes of this instance
extern int req_edge_num; // number of required edges of this instance
extern int req_arc_num; // number of required arcs of this instance
extern int nonreq_edge_num; // number of nonrequired edges of this instance
extern int nonreq_arc_num; // number of nonrequired arcs of this instance
extern int task_num; // number of tasks of this instance ( = 2*req_edge_num+req_arc_num)
extern int total_arc_num; // number of total arcs in the graph of this instance ( = task_num+2*nonreq_edge_num+nonreq_arc_num)
extern int vehicle_num; // number of vehicles of this instance
extern int capacity;

extern int DEPOT; // the depot node

extern int LBs[MAX_INSTANCE_NUM]; // the lower bounds of all the tested instances
extern int lower_bound; // lower bound of this instance

extern int trav_cost[MAX_NODE_NUM][MAX_NODE_NUM]; // the traverse cost matrix between each pair of nodes
extern int serve_cost[MAX_NODE_NUM][MAX_NODE_NUM]; // the serve cost matrix between each pair of nodes
extern int shortest_path[MAX_NODE_NUM][MAX_NODE_NUM][MAX_NODE_NUM]; // the shortest path 3-D matrix between each pair of nodes, obtained by Dijkstra's method. Element [i][j][...] is the vector between i and j.
extern int min_cost[MAX_NODE_NUM][MAX_NODE_NUM]; // the minimal cost matrix between each pair of nodes, obtained by Dijkstra's method
extern double task_dist[MAX_TASK_NUM][MAX_TASK_NUM]; // pairwise distance between tasks

/* randomness */

// generate a random permutation from 1 to num
void rand_perm(int *rp_vec, int num);

// choose a number randomly between LB and UB (num must be not too large)
int rand_choose(int LB, int UB);

// choose a number randomly between 1 and num (num must be not too large)
int rand_choose(int num);

/* operations for arrays */

// print vector
void print_one_dim_array(int *a);

// print 2-D matrix
void print_two_dim_matrix(int **a, int row, int col);

// delete the kth element from array a
void delete_element(int *a, int k);

// add element e to the kth position of array a
void add_element(int *a, int e, int k);

// reverse the direction of array a from position k1 to k2
void reverse_direction(int *a, int k1, int k2);

// find the positions that element e occurs in array a
void find_ele_positions(int *positions, int *a, int e);

// copy sub-array a[k1:k2] to array b
void copy_sub_array(int *b, int *a, int k1, int k2);

// insert array a into position k of array b
void insert_array(int *b, int *a, int k);

// replace the sub-array b[k1:k2] with array a
void replace_sub_array(int *b, int *a, int k1, int k2);

// link array a behind array b
void link_array(int *b, int *a);

// if array a equals array b, return 1, otherwise return 0
int equal(int *a, int *b);

// get minimal value within array a
int min(int *a);

// get maximal value within array a
int max(int *a);

// set kth bit of num to 1
int set_bit(int num, int k);

// set kth bit of num to 0
int unset_bit(int num, int k);

// return 1 if the kth bit of num is 1, otherwise return 0
int bit_one(int num, int k);

/* operations for task sequences (a special array) */

typedef struct task
{
	int head_node;
	int tail_node;
	int dead_cost;
	int serv_cost;
	int demand;
	int inverse;
} task;

typedef struct arc
{
	int tail_node;
	int head_node;
	int trav_cost;
} arc;

typedef struct individual
{
	int sequence[MAX_SOLUTION_LENGTH];
	int route_load[MAX_ROUTE_NUM];
	int total_cost;
	int total_vio_load;
	double fitness;
	int pred[MAX_TASK_NUM]; // pred[i] indicates the predecessor of task i in the sequence of the individual
	int succ[MAX_TASK_NUM]; // succ[i] indicates the successor of task i in the sequence of the individual
} individual;

typedef struct population
{
	individual indi[MAX_TMP_POPSIZE];
	int popsize;
} population;

extern population pop1;
extern population subpop[GROUP_NUM];

extern task inst_tasks[MAX_TASK_NUM];
extern arc inst_arcs[MAX_ARC_NUM];

extern individual pop[MAX_TMP_POPSIZE];
extern individual best_fsb_solution;
extern int popsize; // the population size for this instance, depending on whether enough satisfactory solutions have been generated in the initialization phase

// delete the kth individual from the individual set indis with its size as indis_size
int delete_element(individual *indis, int indis_size, int k);

// find arc index according to head_node and tail_node
int find_arc(int head_node, int tail_node, const arc *inst_arcs);

// find task index according to head_node and tail_node
int find_task(int head_node, int tail_node, const task *inst_tasks);

// remove delimiters '0' from task_seq
void remove_task_seq_delimiters(int *task_seq);

// split operator
int split(int *split_task_seq, int *one_task_seq, const task *inst_tasks);

// if task_seq is legal, return 1, otherwise return 0
int legal(int *task_seq, int *tasks, const task *inst_tasks);

int legal(int *task_seq, const task *inst_tasks);

// get total cost of task_seq
int get_task_seq_total_cost(int *task_seq, const task *inst_tasks);

// get load of each route according to task_seq
void get_route_load(int *route_loads, int *task_seq, const task *inst_tasks);

// get total_vio_load according to route_loads
int get_total_vio_load(int *route_loads);

// get length of each route according to task_seq
void get_route_seg_length(int *route_seg_length, int *task_seq, const task *inst_tasks);

// get assignment of each task according to task_seq
void get_assignment(int *assignment, int *task_seq, const task *inst_tasks);

// get predecessors and successors of the task sequence
void get_predsucc(int *pred, int *succ, int *task_seq, const task *inst_tasks);

// calculate the distance between indi1 and indi2 according to their 'pred' and 'succ'
int calc_distance(individual *indi1, individual *indi2, const task *inst_tasks);

// copy source to target
void indi_copy(individual *target, individual *source);

/* initialization and preprocessing functions */

// Dijkstra's algorithm
void mod_dijkstra();

void path_scanning(individual *ps_indi, const task *inst_tasks, int *serve_mark);

void rand_scanning(individual *rs_indi, const task *inst_tasks, int *serve_mark);

/* search operators */

typedef struct move
{
	int type;
	int task1;
	int task2;
	int orig_seg;
	int targ_seg;
	int orig_pos;
	int targ_pos;
	int orig_length;
	int targ_length;
	int total_cost;
	int total_vio_load;
	int max_length;
	double fitness;
} move;

// Random selection of parent ids
void rand_selection(int &id1, int &id2, population *pop);

void rand_selection(int &id1, int &id2, individual *pop);

// Tournament selection
void tour_selection(int &id1, int &id2, individual *pop);

// Sequential-based crossover
void SBX(individual *xed_child, individual *p1, individual *p2, const task *inst_tasks);

// Large-neighborhood search mutation
void lns_mut(individual *c, individual *p, individual *best_solution, const task *inst_tasks);

// Large-neighborhood search operator
void lns(individual *indi, double coef, int nsize, const task *inst_tasks);

void single_insertion(move *best_move, individual *curr_indi, double coef, const task *inst_tasks);

void double_insertion(move *best_move, individual *curr_indi, double coef, const task *inst_tasks);

void swap(move *best_move, individual *curr_indi, double coef, const task *inst_tasks);

void global_repair_operator(individual *indi, const task *inst_tasks);

/* algorithms */

// MAENS on the subset of tasks (the vector sub_tasks)
void MAENS(individual *output_indi, int *sub_tasks, const task *inst_tasks);

void MAENS_initialization(individual *output_indi, individual *pop, int &popsize, int *sub_tasks, const task *inst_tasks);

void MAENS_initialization(individual *output_indi, population *pop, int *sub_tasks, const task *inst_tasks);

void MAENS_loop(individual *output_indi, individual *pop, int popsize, int &wite, const task *inst_tasks);

void MAENS_loop(individual *output_indi, population *pop, int &wite, const task *inst_tasks);

/* decomposition */

// Divide the elements into k groups according to the distance matrix
void kcenter(int *group_ids, int *centers, double (*dist_mtx)[MAX_TASK_NUM], int task_num, int k, const task *inst_tasks);

// Divide the elements into k groups according to the distance matrix using k-medoids method
void kmedoids(int *group_ids, int *medoids, double (*dist_mtx)[MAX_TASK_NUM], int task_num, int group_num, const task *inst_tasks);

// Divide the elements into k groups according to the distance matrix and capacity constraint using k-medoids method
void kmedoids_cap(int *group_ids, int *medoids, double (*dist_mtx)[MAX_TASK_NUM], int capacity, int task_num, int group_num, const task *inst_tasks);

// Divide the elements into k groups according to the distance matrix with nearly equal demands using k-medoids method
void kmedoids_eq_cap(int *group_ids, int *medoids, double (*dist_mtx)[MAX_TASK_NUM], int capacity, int task_num, int group_num, const task *inst_tasks, double ratio);

// Divide the elements into k groups according to the distance matrix with nearly equal demands using fuzzy k-medoids method
void fuzzy_kmedoids_eq_cap(int *group_ids, int *medoids, double (*dist_mtx)[MAX_TASK_NUM], int capacity, int task_num, int group_num, const task *inst_tasks, double ratio);

// Divide the elements into k groups according to the distance matrix using k-medoids method considering the depot distance and capacity constraint
void kmedoids_depot_cap(int *group_ids, int *medoids, double (*dist_mtx)[MAX_TASK_NUM], int capacity, int task_num, int group_num, const task *inst_tasks);

// Cluster using local search
void lscluster_depot_cap(int *group_ids, double (*dist_mtx)[MAX_TASK_NUM], int capacity, int task_num, int group_num, const task *inst_tasks);

// Change groups based on the random grouping of each route
void route_random_grouping(int *group_ids, int group_num, int *task_seq);

// Change groups based on the membership of each route
void route_membership_grouping(int *group_ids, int group_num, int *task_seq);

// Change groups based on the group distance matrix and combine the routes
void route_distance_grouping(int *group_ids, int group_num, int *task_seq, double (*dist_mtx)[MAX_TASK_NUM], double exp);

// Divide the routes into k groups of routes according to the route distance matrix using k-medoids method
void route_kmedoids(int *route_group_ids, int *route_medoids, double (*route_dist_mtx)[MAX_ROUTE_NUM], int route_num, int group_num);

// Divide the routes into k groups of routes according to the route distance matrix using fuzzy k-medoids method
void route_fuzzy_kmedoids(int *route_group_ids, int *route_medoids, double (*route_dist_mtx)[MAX_ROUTE_NUM], int route_num, int group_num, double exp);

// Divide the population to sub-populations according to the group ids and current id
void pop2subpop(population *subpop, population *pop, int *group_ids, int subpop_id, const task *inst_tasks);

// Divide the individual to sub-individual according to the group ids and current id
void indi2subindi(individual *indi, individual *subindi, int *group_ids, int subpop_id, const task *inst_tasks);

// Combine all the sub-populations to the population
void subpop2pop(population *pop, population *subpop, const task *inst_tasks);

/* Read input file */

// Read gdb or val or egl file
void read_gdb_val_egl(FILE *fp);

// Read egl large file
void read_egl_large(FILE *fp);

// Read beullens file
void read_beullens(FILE *fp);

/* Fredrickson's heuristic */

typedef struct blossom
{
	int pnode;
	int bnode;
	int route[MAX_NODE_NUM];
	int nodes[MAX_NODE_NUM];
} blossom;

int fred_heuristic(int *fred_route, int *tasks, int route_num, const task *inst_tasks);

void link_depots(int (*adj_mtx)[MAX_NODE_NUM+2*MAX_ROUTE_NUM], double (*dist_mtx)[MAX_NODE_NUM+2*MAX_ROUTE_NUM], int (*orig_adj_mtx)[MAX_NODE_NUM+2*MAX_ROUTE_NUM], int req_depot_degree);

void connected_subset(int root, int curr_subset_id, int *subset_id, int (*adj_mtx)[MAX_NODE_NUM+2*MAX_ROUTE_NUM]);

void min_cost_spanning_tree(int (*mcspantree)[MAX_NODE_NUM+2*MAX_ROUTE_NUM], double (*dist_mtx)[MAX_NODE_NUM+2*MAX_ROUTE_NUM]);

void even_degree(int (*adj_mtx)[MAX_NODE_NUM+2*MAX_ROUTE_NUM], int *odd_deg_nodes, double (*dist_mtx)[MAX_NODE_NUM+2*MAX_ROUTE_NUM]);

void Euler_route(int *elroute, int (*adj_mtx)[MAX_NODE_NUM+2*MAX_ROUTE_NUM]);

void find_circuit(int *elroute, int curr_node, int (*adj_mtx)[MAX_NODE_NUM+2*MAX_ROUTE_NUM]);
//
//int SwitchDecimal(int *Binary);
//
//void SwitchBinary(int *Binary, int Decimal);

