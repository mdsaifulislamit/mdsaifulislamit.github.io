#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "functions.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// read gdb or val or egl file
void read_gdb_val_egl(FILE *fp)
{
	char dummy_string[50];

	req_arc_num = 0;
	nonreq_arc_num = 0;
	while (1)
	{
		fscanf(fp, "%s", dummy_string); // get the instance name
		//printf("dummy_string = %s\n", dummy_string);

		if (strcmp(dummy_string, "VERTICES") == 0)
		{
			fscanf(fp, "%s", dummy_string);
			fscanf(fp, "%d", &node_num);
		}
		else if (strcmp(dummy_string, "ARISTAS_REQ") == 0)
		{
			fscanf(fp, "%s", dummy_string);
			fscanf(fp, "%d", &req_edge_num);
		}
		else if (strcmp(dummy_string, "ARISTAS_NOREQ") == 0)
		{
			fscanf(fp, "%s", dummy_string);
			fscanf(fp, "%d", &nonreq_edge_num);
		}
		else if (strcmp(dummy_string, "VEHICULOS") == 0)
		{
			fscanf(fp, "%s", dummy_string);
			fscanf(fp, "%d", &vehicle_num);
		}
		else if (strcmp(dummy_string, "CAPACIDAD") == 0)
		{
			fscanf(fp, "%s", dummy_string);
			fscanf(fp, "%d", &capacity);
		}
		else if (strcmp(dummy_string, "LISTA_ARISTAS_REQ") == 0)
		{
			task_num = 2*req_edge_num+req_arc_num;
			total_arc_num = task_num+2*nonreq_edge_num+nonreq_arc_num;

			fscanf(fp, "%s", dummy_string);

			for (int i = 1; i <= req_edge_num; i++)
			{
				fscanf(fp, "%s", dummy_string); // get the left parenthesis "("
				fscanf(fp, "%d,", &inst_tasks[i].head_node);
				fscanf(fp, "%d)", &inst_tasks[i].tail_node);
				fscanf(fp, "%s", dummy_string); // get the right parenthesis ")" and the string "coste"
				fscanf(fp, "%d", &inst_tasks[i].serv_cost);
				fscanf(fp, "%s", dummy_string); // get the string "demanda"
				fscanf(fp, "%d", &inst_tasks[i].demand);
				inst_tasks[i].dead_cost = inst_tasks[i].serv_cost;
				inst_tasks[i].inverse = i+req_edge_num;

				inst_tasks[i+req_edge_num].head_node = inst_tasks[i].tail_node;
				inst_tasks[i+req_edge_num].tail_node = inst_tasks[i].head_node;
				inst_tasks[i+req_edge_num].dead_cost = inst_tasks[i].dead_cost;
				inst_tasks[i+req_edge_num].serv_cost = inst_tasks[i].serv_cost;
				inst_tasks[i+req_edge_num].demand = inst_tasks[i].demand;
				inst_tasks[i+req_edge_num].inverse = i;

				inst_arcs[i].head_node = inst_tasks[i].head_node;
				inst_arcs[i].tail_node = inst_tasks[i].tail_node;
				inst_arcs[i].trav_cost = inst_tasks[i].dead_cost;
				inst_arcs[i+req_edge_num].head_node = inst_arcs[i].tail_node;
				inst_arcs[i+req_edge_num].tail_node = inst_arcs[i].head_node;
				inst_arcs[i+req_edge_num].trav_cost = inst_arcs[i].trav_cost;
			}
		}
		else if (strcmp(dummy_string, "LISTA_ARISTAS_NOREQ") == 0)
		{
			fscanf(fp, "%s", dummy_string);

			for (int i = task_num+1; i <= task_num+nonreq_edge_num; i++)
			{
				fscanf(fp, "%s", dummy_string); // get the left parenthesis "("
				fscanf(fp, "%d,", &inst_arcs[i].head_node);
				fscanf(fp, "%d)", &inst_arcs[i].tail_node);
				fscanf(fp, "%s", dummy_string); // get the right parenthesis ")" and the string "coste"
				fscanf(fp, "%d", &inst_arcs[i].trav_cost);

				inst_arcs[i+nonreq_edge_num].head_node = inst_arcs[i].tail_node;
				inst_arcs[i+nonreq_edge_num].tail_node = inst_arcs[i].head_node;
				inst_arcs[i+nonreq_edge_num].trav_cost = inst_arcs[i].trav_cost;
			}
		}
		else if (strcmp(dummy_string, "DEPOSITO") == 0)
		{
			fscanf(fp, "%s", dummy_string);
			fscanf(fp, "%d", &DEPOT);
			break;
		}
	}

	inst_tasks[DUMMY_CYCLE].tail_node = DEPOT;
	inst_tasks[DUMMY_CYCLE].head_node = DEPOT;
	inst_tasks[DUMMY_CYCLE].dead_cost = 0;
	inst_tasks[DUMMY_CYCLE].serv_cost = 0;
	inst_tasks[DUMMY_CYCLE].demand = 0;
	inst_tasks[DUMMY_CYCLE].inverse = DUMMY_CYCLE;
	inst_arcs[DUMMY_CYCLE].tail_node = DEPOT;
	inst_arcs[DUMMY_CYCLE].head_node = DEPOT;
	inst_arcs[DUMMY_CYCLE].trav_cost = 0;

	for (int i = 1; i <= node_num; i++)
	{
		for (int j = 1; j <= node_num; j++)
		{
			trav_cost[i][j] = INF;
			serve_cost[i][j] = 0;
		}
	}

	for (int i = 1; i <= node_num; i++)
	{
		trav_cost[i][i] = 0;
	}

	for (int i = 1; i <= total_arc_num; i++)
	{
		trav_cost[inst_arcs[i].head_node][inst_arcs[i].tail_node] = inst_arcs[i].trav_cost;
	}

	for (int i = 1; i <= task_num; i++)
	{
		serve_cost[inst_tasks[i].head_node][inst_tasks[i].tail_node] = inst_tasks[i].serv_cost;
	}

	mod_dijkstra();

	// pairwise distance matrix between tasks
	// dist(i,j) is the average distance between the vertices of the tasks
	for (int i = 0; i <= task_num; i++)
	{
		for (int j = 0; j <= task_num; j++)
		{
			task_dist[i][j] = (min_cost[inst_tasks[i].head_node][inst_tasks[j].head_node]+
				min_cost[inst_tasks[i].head_node][inst_tasks[j].tail_node]+
				min_cost[inst_tasks[i].tail_node][inst_tasks[j].head_node]+
				min_cost[inst_tasks[i].tail_node][inst_tasks[j].tail_node])/4;
		}
	}

	//// dist(i,j) is the minimal distance between the vertices of the tasks
	//for (int i = 0; i <= task_num; i++)
	//{
	//	for (int j = 0; j <= task_num; j++)
	//	{
	//		task_dist[i][j] = min_cost[inst_tasks[i].head_node][inst_tasks[j].head_node];
	//		
	//		if (min_cost[inst_tasks[i].head_node][inst_tasks[j].tail_node] < task_dist[i][j])
	//		{
	//			task_dist[i][j] = min_cost[inst_tasks[i].head_node][inst_tasks[j].tail_node];
	//		}

	//		if (min_cost[inst_tasks[i].tail_node][inst_tasks[j].head_node] < task_dist[i][j])
	//		{
	//			task_dist[i][j] = min_cost[inst_tasks[i].tail_node][inst_tasks[j].head_node];
	//		}

	//		if (min_cost[inst_tasks[i].tail_node][inst_tasks[j].tail_node] < task_dist[i][j])
	//		{
	//			task_dist[i][j] = min_cost[inst_tasks[i].tail_node][inst_tasks[j].tail_node];
	//		}
	//	}
	//}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// read egl large file
void read_egl_large(FILE *fp)
{
	char dummy_string[50];

	int get_req = 0;
	req_arc_num = 0;
	nonreq_arc_num = 0;
	while (1)
	{
		fscanf(fp, "%s", dummy_string);
		//printf("dummy_string = %s\n", dummy_string);

		if (strcmp(dummy_string, "VERTICES:") == 0) // get the number of vertices
		{
			fscanf(fp, "%d", &node_num);
		}
		else if (strcmp(dummy_string, "DEPOSITO:") == 0) // get the id of depot
		{
			fscanf(fp, "%d", &DEPOT);
			DEPOT ++; // change node id starting from 0 to starting from 1
		}
		else if (strcmp(dummy_string, "REQUERIDAS:") == 0 && !get_req) // the number of required edges
		{
			fscanf(fp, "%d", &req_edge_num);
			get_req = 1;
		}
		else if (strcmp(dummy_string, "NAO") == 0) // the number of non-required edges
		{
			fscanf(fp, "%s", dummy_string); // skip the string "REQUERIDAS:"
			fscanf(fp, "%d", &nonreq_edge_num);
		}
		else if (strcmp(dummy_string, "VEICULOS:") == 0) // number of vehicles
		{
			fscanf(fp, "%d", &vehicle_num);
		}
		else if (strcmp(dummy_string, "CAPACIDADE:") == 0) // capacity
		{
			fscanf(fp, "%d", &capacity);
		}
		else if (strcmp(dummy_string, "PROCURA") == 0) // begin to scan each edge, both required and non-required
		{
			task_num = 2*req_edge_num+req_arc_num;
			total_arc_num = task_num+2*nonreq_edge_num+nonreq_arc_num;

			int req_ptr = 0; // the pointer to the current required edge id
			for (int i = 1; i <= req_edge_num+nonreq_edge_num; i++)
			{
				int tmp_head, tmp_tail, tmp_cost, tmp_demand;
				fscanf(fp, "%d", &tmp_head);
				fscanf(fp, "%d", &tmp_tail);
				fscanf(fp, "%d", &tmp_cost);
				fscanf(fp, "%d", &tmp_demand);

				tmp_head ++; // change node id starting from 0 to starting from 1
				tmp_tail ++; // change node id starting from 0 to starting from 1

				if (tmp_demand > 0) // is a task
				{
					req_ptr ++;
					inst_tasks[req_ptr].head_node = tmp_head;
					inst_tasks[req_ptr].tail_node = tmp_tail;
					inst_tasks[req_ptr].serv_cost = tmp_cost;
					inst_tasks[req_ptr].demand = tmp_demand;
					inst_tasks[req_ptr].dead_cost = inst_tasks[req_ptr].serv_cost;
					inst_tasks[req_ptr].inverse = req_ptr+req_edge_num;
					inst_tasks[req_ptr+req_edge_num].head_node = inst_tasks[req_ptr].tail_node;
					inst_tasks[req_ptr+req_edge_num].tail_node = inst_tasks[req_ptr].head_node;
					inst_tasks[req_ptr+req_edge_num].dead_cost = inst_tasks[req_ptr].dead_cost;
					inst_tasks[req_ptr+req_edge_num].serv_cost = inst_tasks[req_ptr].serv_cost;
					inst_tasks[req_ptr+req_edge_num].demand = inst_tasks[req_ptr].demand;
					inst_tasks[req_ptr+req_edge_num].inverse = req_ptr;
				}

				inst_arcs[i].head_node = tmp_head;
				inst_arcs[i].tail_node = tmp_tail;
				inst_arcs[i].trav_cost = tmp_cost;
				inst_arcs[i+req_edge_num+nonreq_edge_num].head_node = inst_arcs[i].tail_node;
				inst_arcs[i+req_edge_num+nonreq_edge_num].tail_node = inst_arcs[i].head_node;
				inst_arcs[i+req_edge_num+nonreq_edge_num].trav_cost = inst_arcs[i].trav_cost;
			}
		}
		else if (strcmp(dummy_string, "END") == 0) // finish reading
		{
			break;
		}
	}

	inst_tasks[DUMMY_CYCLE].tail_node = DEPOT;
	inst_tasks[DUMMY_CYCLE].head_node = DEPOT;
	inst_tasks[DUMMY_CYCLE].dead_cost = 0;
	inst_tasks[DUMMY_CYCLE].serv_cost = 0;
	inst_tasks[DUMMY_CYCLE].demand = 0;
	inst_tasks[DUMMY_CYCLE].inverse = DUMMY_CYCLE;
	inst_arcs[DUMMY_CYCLE].tail_node = DEPOT;
	inst_arcs[DUMMY_CYCLE].head_node = DEPOT;
	inst_arcs[DUMMY_CYCLE].trav_cost = 0;

	for (int i = 1; i <= node_num; i++)
	{
		for (int j = 1; j <= node_num; j++)
		{
			trav_cost[i][j] = INF;
			serve_cost[i][j] = 0;
		}
	}

	for (int i = 1; i <= node_num; i++)
	{
		trav_cost[i][i] = 0;
	}

	for (int i = 1; i <= total_arc_num; i++)
	{
		trav_cost[inst_arcs[i].head_node][inst_arcs[i].tail_node] = inst_arcs[i].trav_cost;
	}

	for (int i = 1; i <= task_num; i++)
	{
		serve_cost[inst_tasks[i].head_node][inst_tasks[i].tail_node] = inst_tasks[i].serv_cost;
	}

	mod_dijkstra();

	// pairwise distance matrix between tasks
	// dist(i,j) is the average distance between the vertices of the tasks
	for (int i = 0; i <= task_num; i++)
	{
		for (int j = 0; j <= task_num; j++)
		{
			task_dist[i][j] = (min_cost[inst_tasks[i].head_node][inst_tasks[j].head_node]+
				min_cost[inst_tasks[i].head_node][inst_tasks[j].tail_node]+
				min_cost[inst_tasks[i].tail_node][inst_tasks[j].head_node]+
				min_cost[inst_tasks[i].tail_node][inst_tasks[j].tail_node])/4;
		}
	}
	//// dist(i,j) is the minimal distance between the vertices of the tasks
	//for (int i = 0; i <= task_num; i++)
	//{
	//	for (int j = 0; j <= task_num; j++)
	//	{
	//		task_dist[i][j] = min_cost[inst_tasks[i].head_node][inst_tasks[j].head_node];
	//		
	//		if (min_cost[inst_tasks[i].head_node][inst_tasks[j].tail_node] < task_dist[i][j])
	//		{
	//			task_dist[i][j] = min_cost[inst_tasks[i].head_node][inst_tasks[j].tail_node];
	//		}

	//		if (min_cost[inst_tasks[i].tail_node][inst_tasks[j].head_node] < task_dist[i][j])
	//		{
	//			task_dist[i][j] = min_cost[inst_tasks[i].tail_node][inst_tasks[j].head_node];
	//		}

	//		if (min_cost[inst_tasks[i].tail_node][inst_tasks[j].tail_node] < task_dist[i][j])
	//		{
	//			task_dist[i][j] = min_cost[inst_tasks[i].tail_node][inst_tasks[j].tail_node];
	//		}
	//	}
	//}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// read egl large file
void read_beullens(FILE *fp)
{
	int total_edge_num, this_node, this_node_degree, next_node, tmp_length, tmp_demand;
	
	fscanf(fp, "%d", &node_num);
	fscanf(fp, "%d", &total_edge_num);
	fscanf(fp, "%d", &capacity);
	fscanf(fp, "%d", &DEPOT);
	
	// initialize the matrices
	for (int i = 1; i <= node_num; i++)
	{
		for (int j = 1; j <= node_num; j++)
		{
			trav_cost[i][j] = INF;
			serve_cost[i][j] = 0;
		}
	}
	for (int i = 1; i <= node_num; i++)
	{
		trav_cost[i][i] = 0;
	}
	
	// scan for each node
	req_edge_num = 0;
	req_arc_num = 0;
	nonreq_edge_num = 0;
	nonreq_arc_num = 0;
	for (int i = 1; i <= node_num; i++)
	{
		fscanf(fp, "%d", &this_node);
		fscanf(fp, "%d", &this_node_degree);
		for (int j = 1; j <= this_node_degree; j++)
		{
			fscanf(fp, "%d", &next_node);
			fscanf(fp, "%d", &tmp_length);
			fscanf(fp, "%d", &tmp_demand);
			trav_cost[this_node][next_node] = tmp_length;
			serve_cost[this_node][next_node] = tmp_length;
			if (this_node < next_node) // appear for the first time
			{
				if (tmp_demand > 0)
				{
					req_edge_num ++;
					inst_tasks[req_edge_num].head_node = this_node;
					inst_tasks[req_edge_num].tail_node = next_node;
					inst_tasks[req_edge_num].serv_cost = tmp_length;
					inst_tasks[req_edge_num].demand = tmp_demand;
					inst_tasks[req_edge_num].dead_cost = tmp_length;
				}
				else
				{
					nonreq_edge_num ++;
				}
			}
		}
	} // finish scanning the file
	
	task_num = 2*req_edge_num+req_arc_num;
	total_arc_num = task_num+2*nonreq_edge_num+nonreq_arc_num;
	
	inst_tasks[DUMMY_CYCLE].tail_node = DEPOT;
	inst_tasks[DUMMY_CYCLE].head_node = DEPOT;
	inst_tasks[DUMMY_CYCLE].dead_cost = 0;
	inst_tasks[DUMMY_CYCLE].serv_cost = 0;
	inst_tasks[DUMMY_CYCLE].demand = 0;
	inst_tasks[DUMMY_CYCLE].inverse = DUMMY_CYCLE;
	
	for (int i = 1; i <= req_edge_num; i++)
	{
		inst_tasks[i].inverse = i+req_edge_num;
	}
	for (int i = req_edge_num+1; i <= 2*req_edge_num; i++)
	{
		inst_tasks[i].head_node = inst_tasks[i-req_edge_num].tail_node;
		inst_tasks[i].tail_node = inst_tasks[i-req_edge_num].head_node;
		inst_tasks[i].serv_cost = inst_tasks[i-req_edge_num].serv_cost;
		inst_tasks[i].demand = inst_tasks[i-req_edge_num].demand;
		inst_tasks[i].dead_cost = inst_tasks[i-req_edge_num].dead_cost;
		inst_tasks[i].inverse = i-req_edge_num;
	}

	mod_dijkstra();

	// pairwise distance matrix between tasks
	// dist(i,j) is the average distance between the vertices of the tasks
	for (int i = 0; i <= task_num; i++)
	{
		for (int j = 0; j <= task_num; j++)
		{
			task_dist[i][j] = (min_cost[inst_tasks[i].head_node][inst_tasks[j].head_node]+
				min_cost[inst_tasks[i].head_node][inst_tasks[j].tail_node]+
				min_cost[inst_tasks[i].tail_node][inst_tasks[j].head_node]+
				min_cost[inst_tasks[i].tail_node][inst_tasks[j].tail_node])/4;
		}
	}
	//// dist(i,j) is the minimal distance between the vertices of the tasks
	//for (int i = 0; i <= task_num; i++)
	//{
	//	for (int j = 0; j <= task_num; j++)
	//	{
	//		task_dist[i][j] = min_cost[inst_tasks[i].head_node][inst_tasks[j].head_node];
	//		
	//		if (min_cost[inst_tasks[i].head_node][inst_tasks[j].tail_node] < task_dist[i][j])
	//		{
	//			task_dist[i][j] = min_cost[inst_tasks[i].head_node][inst_tasks[j].tail_node];
	//		}

	//		if (min_cost[inst_tasks[i].tail_node][inst_tasks[j].head_node] < task_dist[i][j])
	//		{
	//			task_dist[i][j] = min_cost[inst_tasks[i].tail_node][inst_tasks[j].head_node];
	//		}

	//		if (min_cost[inst_tasks[i].tail_node][inst_tasks[j].tail_node] < task_dist[i][j])
	//		{
	//			task_dist[i][j] = min_cost[inst_tasks[i].tail_node][inst_tasks[j].tail_node];
	//		}
	//	}
	//}
}