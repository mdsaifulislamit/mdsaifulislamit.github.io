#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "functions.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Divide the elements into k groups according to the distance matrix
void kcenter(int *group_ids, int *centers, double (*dist_mtx)[MAX_TASK_NUM], int task_num, int group_num, const task *inst_tasks)
{
	// use only one id of edge tasks
	int use[MAX_TASK_NUM];
	memset(use, 0, (task_num+1)*sizeof(int));
	use[0] = task_num;
	for (int i = 1; i <= task_num; i++)
	{
		if (use[i] == 0)
			use[inst_tasks[i].inverse] = 1;
	}

	// Initialize the group id of each element
	// (1) 1:group_num appear at least once
	// (2) centers are distributed as diversely as possible
	int iscenter[MAX_TASK_NUM];
	memset(iscenter, 0, (task_num+1)*sizeof(int));
	iscenter[0] = task_num;

	group_ids[0] = task_num;
	centers[0] = group_num;
	// for the first group
	double max_avg_dist = 0;
	for (int i = 1; i <= task_num; i++) // each task i
	{
		if (!use[i]) // task i not used
			continue;

		int tmp_num = 0;
		double tmp_avg_dist = 0;
		for (int j = 1; j <= task_num; j++) // compute avg dist to all the other tasks
		{
			if (!use[j]) // task j not used
				continue;

			tmp_avg_dist += dist_mtx[i][j];
			tmp_num ++;
		}
		tmp_avg_dist /= tmp_num;

		if (tmp_avg_dist > max_avg_dist)
		{
			max_avg_dist = tmp_avg_dist;
			centers[1] = i;
		}
	}
	iscenter[centers[1]] = 1;

	// for the remaining groups
	for (int g = 2; g <= group_num; g++) // group g
	{
		max_avg_dist = 0;
		for (int i = 1; i <= task_num; i++) // check for each task i
		{
			if (!use[i]) // not used
				continue;
			
			if (iscenter[i]) // is already a center
				continue;
			
			double tmp_avg_dist = 0;
			for (int c = 1; c < g; c++) // compute avg dist to all the existing centers
			{
				tmp_avg_dist += dist_mtx[i][centers[c]];
			}
			tmp_avg_dist /= g-1;

			if (tmp_avg_dist > max_avg_dist)
			{
				max_avg_dist = tmp_avg_dist;
				centers[g] = i;
			}
		}
		iscenter[centers[g]] = 1;
	}

	// assign group ids for the centers
	for (int c = 1; c <= group_num; c++)
	{
		group_ids[centers[c]] = c;
	}

	// Repeat modifying the centers
	int repeat = 1;
	while (repeat)
	{
		repeat = 0;
		
		// relocate the other elements
		for (int i = 1; i <= task_num; i++)
		{
			if (!use[i]) // task i not used
				continue;

			if (iscenter[i]) // is already a center
				continue;

			double min_avg_cent_dist = INF; // avg dist to the centers
			int pre_group_id = group_ids[i];
			for (int c = 1; c <= group_num; c++)
			{
				double tmp_avg_cent_dist = dist_mtx[i][centers[c]];

				if (tmp_avg_cent_dist < min_avg_cent_dist)
				{
					min_avg_cent_dist = tmp_avg_cent_dist;
					group_ids[i] = c;
				}
			}

			if (group_ids[i] != pre_group_id) // group changed, continue loop
				repeat = 1;
		}

		if (!repeat)
			break;

		// determine new centers as the one with minimal sum distance to the other elements in the same group
		memset(iscenter, 0, (task_num+1)*sizeof(int));
		iscenter[0] = task_num;
		for (int c = 1; c <= group_num; c++)
		{
			// find the group members
			int group_members[MAX_TASK_NUM];
			group_members[0] = 0;
			for (int i = 1; i <= task_num; i++)
			{
				if (!use[i]) // task i not used
					continue;

				if (group_ids[i] == c)
				{
					group_members[0] ++;
					group_members[group_members[0]] = i;
				}
			}

			// compute the sum of group distances and the minimal value
			int min_sum_group_dist = INF;
			for (int i = 1; i <= group_members[0]; i++)
			{
				int tmp_sum_group_dist = 0;
				for (int j = 1; j <= group_members[0]; j++)
				{
					tmp_sum_group_dist += dist_mtx[group_members[i]][group_members[j]];
				}

				if (tmp_sum_group_dist < min_sum_group_dist)
				{
					min_sum_group_dist = tmp_sum_group_dist;
					centers[c] = group_members[i];
				}
			}
			
			iscenter[centers[c]] = 1;
		}
	}

	// assign group ids for the unused tasks
	for (int i = 1; i <= task_num; i++)
	{
		if (!use[i])
			group_ids[i] = group_ids[inst_tasks[i].inverse];
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Divide the elements into k groups according to the distance matrix using k-medoids method
void kmedoids(int *group_ids, int *medoids, double (*dist_mtx)[MAX_TASK_NUM], int task_num, int group_num, const task *inst_tasks)
{
	// use only one id of edge tasks
	int use[MAX_TASK_NUM];
	memset(use, 0, (task_num+1)*sizeof(int));
	use[0] = task_num;
	for (int i = 1; i <= task_num; i++)
	{
		if (use[inst_tasks[i].inverse] == 0)
			use[i] = 1;
	}

	// get used task vector
	int used_tasks[MAX_TASK_NUM];
	used_tasks[0] = 0;
	for (int i = 1; i <= task_num; i++)
	{
		if (!use[i])
			continue;
		
		used_tasks[0] ++;
		used_tasks[used_tasks[0]] = i;
	}

	//// initialize the group id of each element
	//int ismedoid[MAX_TASK_NUM];
	//memset(ismedoid, 0, (task_num+1)*sizeof(int));
	//medoids[0] = group_num;
	//ismedoid[0] = task_num;
	//group_ids[0] = task_num;
	//
	//// get a random permutation from 1 to used_tasks[0]
	//int rp_vec[MAX_TASK_NUM];
	//rand_perm(rp_vec, used_tasks[0]);

	//// select medoids randomly
	//for (int g = 1; g <= group_num; g++)
	//{
	//	medoids[g] = used_tasks[rp_vec[g]];
	//	ismedoid[medoids[g]] = 1;
	//	group_ids[medoids[g]] = g;
	//}

	// Initialize the group id of each element
	// (1) 1:group_num appear at least once
	// (2) medoids are distributed as diversely as possible
	int ismedoid[MAX_TASK_NUM];
	memset(ismedoid, 0, (task_num+1)*sizeof(int));
	ismedoid[0] = task_num;

	group_ids[0] = task_num;
	medoids[0] = group_num;
	// for the first group
	double max_avg_dist = 0;
	for (int i = 1; i <= task_num; i++) // each task i
	{
		if (!use[i]) // task i not used
			continue;

		int tmp_num = 0;
		double tmp_avg_dist = 0;
		for (int j = 1; j <= task_num; j++) // compute avg dist to all the other tasks
		{
			if (!use[j]) // task j not used
				continue;

			tmp_avg_dist += dist_mtx[i][j];
			tmp_num ++;
		}
		tmp_avg_dist /= tmp_num;

		if (tmp_avg_dist > max_avg_dist)
		{
			max_avg_dist = tmp_avg_dist;
			medoids[1] = i;
		}
	}
	ismedoid[medoids[1]] = 1;

	// for the remaining groups
	for (int g = 2; g <= group_num; g++) // group g
	{
		max_avg_dist = 0;
		for (int i = 1; i <= task_num; i++) // check for each task i
		{
			if (!use[i]) // not used
				continue;
			
			if (ismedoid[i]) // is already a medoid
				continue;
			
			double tmp_avg_dist = 0;
			for (int c = 1; c < g; c++) // compute avg dist to all the existing medoids
			{
				tmp_avg_dist += dist_mtx[i][medoids[c]];
			}
			tmp_avg_dist /= g-1;

			if (tmp_avg_dist > max_avg_dist)
			{
				max_avg_dist = tmp_avg_dist;
				medoids[g] = i;
			}
		}
		ismedoid[medoids[g]] = 1;
	}

	// assign group ids for the medoids
	for (int c = 1; c <= group_num; c++)
	{
		group_ids[medoids[c]] = c;
	}



	// assign group ids according to medoids
	for (int i = 1; i <= task_num; i++)
	{
		if (!use[i]) // task i not used
			continue;

		if (ismedoid[i]) // is already a medoid
			continue;

		double min_med_dist = INF; // minimal dist to the medoids
		for (int g = 1; g <= group_num; g++)
		{
			double tmp_med_dist = dist_mtx[i][medoids[g]];

			if (tmp_med_dist < min_med_dist)
			{
				min_med_dist = tmp_med_dist;
				group_ids[i] = g;
			}
		}
	}

	// compute the current total cost
	int total_cost = 0;
	for (int i = 1; i <= task_num; i++)
	{
		if (!use[i]) // task i not used
			continue;

		if (ismedoid[i]) // is already a medoid
			continue;

		total_cost += dist_mtx[i][medoids[group_ids[i]]];
	}

	// Repeat updating
	int repeat = 1;
	while (repeat)
	{
		repeat = 0;

		// tmp medoids, tmp group ids and tmp total cost
		int best_medoids[GROUP_NUM+1];
		memcpy(best_medoids, medoids, (GROUP_NUM+1)*sizeof(int));
		int best_ismedoid[MAX_TASK_NUM];
		memcpy(best_ismedoid, ismedoid, MAX_TASK_NUM*sizeof(int));
		int best_group_ids[MAX_TASK_NUM];
		memcpy(best_group_ids, group_ids, MAX_TASK_NUM*sizeof(int));
		int best_total_cost = total_cost;

		for (int g = 1; g <= group_num; g++) // for each medoid
		{
			for (int i = 1; i <= task_num; i ++) // for each non-medoid points
			{
				if (!use[i]) // task i not used
					continue;

				if (ismedoid[i]) // is already a medoid
					continue;

				// swap i and medoid[g]
				int tmp_medoids[GROUP_NUM+1];
				memcpy(tmp_medoids, medoids, (GROUP_NUM+1)*sizeof(int));
				int tmp_ismedoid[MAX_TASK_NUM];
				memcpy(tmp_ismedoid, ismedoid, MAX_TASK_NUM*sizeof(int));

				tmp_ismedoid[medoids[g]] = 0;
				tmp_ismedoid[i] = 1;
				tmp_medoids[g] = i;

				// assign tmp group ids according to tmp medoids
				int tmp_group_ids[MAX_TASK_NUM];
				tmp_group_ids[0] = task_num;
				for (int tg = 1; tg <= group_num; tg++)
				{
					tmp_group_ids[tmp_medoids[tg]] = tg;
				}

				for (int ti = 1; ti <= task_num; ti++)
				{
					if (!use[ti]) // task i not used
						continue;

					if (tmp_ismedoid[ti]) // is already a medoid
						continue;

					double min_med_dist = INF; // minimal dist to the medoids
					for (int tg = 1; tg <= group_num; tg++)
					{
						double tmp_med_dist = dist_mtx[ti][tmp_medoids[tg]];

						if (tmp_med_dist < min_med_dist)
						{
							min_med_dist = tmp_med_dist;
							tmp_group_ids[ti] = tg;
						}
					}
				}

				// compute tmp total cost
				int tmp_total_cost = 0;
				for (int ti = 1; ti <= task_num; ti++)
				{
					if (!use[ti]) // task i not used
						continue;

					if (tmp_ismedoid[ti]) // is already a medoid
						continue;

					tmp_total_cost += dist_mtx[ti][tmp_medoids[tmp_group_ids[ti]]];
				}

				if (tmp_total_cost < best_total_cost)
				{
					memcpy(best_medoids, tmp_medoids, (GROUP_NUM+1)*sizeof(int));
					memcpy(best_ismedoid, tmp_ismedoid, MAX_TASK_NUM*sizeof(int));
					memcpy(best_group_ids, tmp_group_ids, MAX_TASK_NUM*sizeof(int));
					best_total_cost = tmp_total_cost;
				}
			}
		}

		if (best_total_cost < total_cost) // better clustering found
		{
			repeat = 1;
			memcpy(medoids, best_medoids, (GROUP_NUM+1)*sizeof(int));
			memcpy(ismedoid, best_ismedoid, MAX_TASK_NUM*sizeof(int));
			memcpy(group_ids, best_group_ids, MAX_TASK_NUM*sizeof(int));
			total_cost = best_total_cost;
		}
	}

	// assign group ids for the unused tasks
	for (int i = 1; i <= task_num; i++)
	{
		if (!use[i])
			group_ids[i] = group_ids[inst_tasks[i].inverse];
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Divide the elements into k groups according to the distance matrix and capacity constraint using k-medoids method
void kmedoids_cap(int *group_ids, int *medoids, double (*dist_mtx)[MAX_TASK_NUM], int capacity, int task_num, int group_num, const task *inst_tasks)
{
	// use only one id of edge tasks
	int use[MAX_TASK_NUM];
	memset(use, 0, (task_num+1)*sizeof(int));
	use[0] = task_num;
	for (int i = 1; i <= task_num; i++)
	{
		if (use[inst_tasks[i].inverse] == 0)
			use[i] = 1;
	}

	kmedoids(group_ids, medoids, dist_mtx, task_num, group_num, inst_tasks);

	/////////////////////////////////////////////////////////////////////////////////////////////
	// get the information of each group

	typedef struct group
	{
		int center;
		int elements[MAX_TASK_NUM];
		int demand;
		double demand_lt; // lower target group demand
		double demand_ut; // upper target group demand
		double demand_ldev; // deviation from the lower target group demand
		double demand_udev; // deviation from the upper target group demand
		double demand_target; // target of the demand
		int route_num_target; // target of number of routes
		double demand_lb; // the lower bound of the demand, used in solving the problem
		double demand_ub; // the upper bound of the demand, used in solving the problem
		int total_cent_dist; // the total distance to center
	} group;

	group kmedoids_cap_groups[GROUP_NUM+1];
	
	
	for (int g = 1; g <= group_num; g++)
	{
		kmedoids_cap_groups[g].center = medoids[g];
		kmedoids_cap_groups[g].elements[0] = 0;
		kmedoids_cap_groups[g].demand = 0;
		kmedoids_cap_groups[g].total_cent_dist = 0;
	}

	for (int i = 1; i <= task_num; i++)
	{
		if (!use[i])
			continue;

		kmedoids_cap_groups[group_ids[i]].elements[0] ++;
		kmedoids_cap_groups[group_ids[i]].elements[kmedoids_cap_groups[group_ids[i]].elements[0]] = i;
		kmedoids_cap_groups[group_ids[i]].demand += inst_tasks[i].demand;
		kmedoids_cap_groups[group_ids[i]].total_cent_dist += task_dist[i][medoids[group_ids[i]]];
	}

	/////////////////////////////////////////////////////////////////////////////////////////////
	// compute the target demand of each group by minimizing the demand to be moved
	// compute the total demand of the problem
	int total_demand = 0;
	for (int i = 1; i <= task_num; i++)
	{
		if (!use[i])
			continue;

		total_demand += inst_tasks[i].demand;
	}

	int total_route_num = ceil(1.0*total_demand/capacity); // total number of routes
	double avg_route_demand = (1.0*total_demand)/total_route_num; // the average demand of each route

	// compute the target of each group demand
	for (int g = 1; g <= group_num; g++)
	{
		kmedoids_cap_groups[g].demand_lt = (floor(1.0*kmedoids_cap_groups[g].demand/avg_route_demand))*avg_route_demand;
		kmedoids_cap_groups[g].demand_ut = (ceil(1.0*kmedoids_cap_groups[g].demand/avg_route_demand))*avg_route_demand;
	}

	for (int g = 1; g <= group_num; g++)
	{
		kmedoids_cap_groups[g].demand_ldev = kmedoids_cap_groups[g].demand-kmedoids_cap_groups[g].demand_lt;
		kmedoids_cap_groups[g].demand_udev = kmedoids_cap_groups[g].demand_ut-kmedoids_cap_groups[g].demand;
	}

	double sum_ldev = 0;
	for (int g = 1; g <= group_num; g++)
	{
		sum_ldev += kmedoids_cap_groups[g].demand_ldev;
	}
	int lt_group_num = group_num-floor(sum_ldev/avg_route_demand+0.5); // number of groups to set to lower target

	// sort the groups in the increasing order of the ldev
	for (int g1 = 1; g1 < group_num; g1++)
	{
		for (int g2 = g1+1; g2 <= group_num; g2++)
		{
			if (kmedoids_cap_groups[g1].demand_ldev > kmedoids_cap_groups[g2].demand_ldev)
			{
				// swap
				group tmp_group = kmedoids_cap_groups[g1];
				kmedoids_cap_groups[g1] = kmedoids_cap_groups[g2];
				kmedoids_cap_groups[g2] = tmp_group;
			}
		}
	}

	for (int g = 1; g <= lt_group_num; g++)
	{
		kmedoids_cap_groups[g].demand_target = kmedoids_cap_groups[g].demand_lt;
		kmedoids_cap_groups[g].route_num_target = floor(kmedoids_cap_groups[g].demand_lt/avg_route_demand+0.5);
	}
	for (int g = lt_group_num+1; g <= group_num; g++)
	{
		kmedoids_cap_groups[g].demand_target = kmedoids_cap_groups[g].demand_ut;
		kmedoids_cap_groups[g].route_num_target = floor(kmedoids_cap_groups[g].demand_ut/avg_route_demand+0.5);
	}

	// define the lower and upper bounds of the demand of the groups

	double ratio = 1; // ratio to define the range of the interval
	for (int g = 1; g <= group_num; g++)
	{
		double group_demand_dev = ratio*(capacity-avg_route_demand)*sqrt((double)kmedoids_cap_groups[g].route_num_target);
		kmedoids_cap_groups[g].demand_lb = kmedoids_cap_groups[g].demand_target-group_demand_dev;
		kmedoids_cap_groups[g].demand_ub = kmedoids_cap_groups[g].demand_target+group_demand_dev;
	}

	// re-allocate the centers and group ids due to the sorting of the groups
	for (int g = 1; g <= group_num; g++)
	{
		medoids[g] = kmedoids_cap_groups[g].center;
		for (int i = 1; i <= kmedoids_cap_groups[g].elements[0]; i++)
		{
			group_ids[kmedoids_cap_groups[g].elements[i]] = g;
		}
	}
	
	/////////////////////////////////////////////////////////////////////////////////////////////
	// solve the problem: minimize the cost subject to the constraint on lower and upper bounds of the demand of each group
	typedef struct ele_move
	{
		int ele;
		int move_demand;
		int source_group;
		int target_group;
		int demand_gain;
		int obj_loss;
	} ele_move;

	ele_move tmp_move, best_move;

	int improve = 1;
	while (improve)
	{
		improve = 0;
		best_move.demand_gain = 0;
		best_move.obj_loss = 0;

		for (int i = 1; i <= task_num; i++)
		{
			if (!use[i])
				continue;

			tmp_move.ele = i;
			tmp_move.move_demand = inst_tasks[i].demand;
			tmp_move.source_group = group_ids[i];
			
			for (int g = 1; g <= group_num; g++)
			{
				if (g == group_ids[i])
					continue;

				tmp_move.target_group = g;

				double old_demand_vio = 0;
				double old_source_group_demand = kmedoids_cap_groups[tmp_move.source_group].demand;
				double old_target_group_demand = kmedoids_cap_groups[tmp_move.target_group].demand;
				if (old_source_group_demand < kmedoids_cap_groups[tmp_move.source_group].demand_lb)
				{
					old_demand_vio += kmedoids_cap_groups[tmp_move.source_group].demand_lb-old_source_group_demand;
				}
				else if (old_source_group_demand > kmedoids_cap_groups[tmp_move.source_group].demand_ub)
				{
					old_demand_vio += old_source_group_demand-kmedoids_cap_groups[tmp_move.source_group].demand_ub;
				}
				if (old_target_group_demand < kmedoids_cap_groups[tmp_move.target_group].demand_lb)
				{
					old_demand_vio += kmedoids_cap_groups[tmp_move.target_group].demand_lb-old_target_group_demand;
				}
				else if (old_target_group_demand > kmedoids_cap_groups[tmp_move.target_group].demand_ub)
				{
					old_demand_vio += old_target_group_demand-kmedoids_cap_groups[tmp_move.target_group].demand_ub;
				}

				double new_demand_vio = 0;
				double new_source_group_demand = kmedoids_cap_groups[tmp_move.source_group].demand-tmp_move.move_demand;
				double new_target_group_demand = kmedoids_cap_groups[tmp_move.target_group].demand+tmp_move.move_demand;
				if (new_source_group_demand < kmedoids_cap_groups[tmp_move.source_group].demand_lb)
				{
					new_demand_vio += kmedoids_cap_groups[tmp_move.source_group].demand_lb-new_source_group_demand;
				}
				else if (new_source_group_demand > kmedoids_cap_groups[tmp_move.source_group].demand_ub)
				{
					new_demand_vio += new_source_group_demand-kmedoids_cap_groups[tmp_move.source_group].demand_ub;
				}
				if (new_target_group_demand < kmedoids_cap_groups[tmp_move.target_group].demand_lb)
				{
					new_demand_vio += kmedoids_cap_groups[tmp_move.target_group].demand_lb-new_target_group_demand;
				}
				else if (new_target_group_demand > kmedoids_cap_groups[tmp_move.target_group].demand_ub)
				{
					new_demand_vio += new_target_group_demand-kmedoids_cap_groups[tmp_move.target_group].demand_ub;
				}

				tmp_move.demand_gain = new_demand_vio-old_demand_vio;
				tmp_move.obj_loss = task_dist[i][medoids[tmp_move.target_group]]-task_dist[i][medoids[tmp_move.source_group]];

				if (tmp_move.demand_gain < best_move.demand_gain || (tmp_move.demand_gain == best_move.demand_gain && tmp_move.obj_loss < best_move.obj_loss))
				{
					improve = 1;
					best_move = tmp_move;
				}
			}
		}

		if (!improve)
			break;

		// perform the best move
		// for group_ids
		group_ids[best_move.ele] = best_move.target_group;
		// for source group
		for (int pos = 1; pos <= kmedoids_cap_groups[best_move.source_group].elements[0]; pos++)
		{
			if (kmedoids_cap_groups[best_move.source_group].elements[pos] == best_move.ele)
				delete_element(kmedoids_cap_groups[best_move.source_group].elements, pos);
		}
		kmedoids_cap_groups[best_move.source_group].demand -= best_move.move_demand;
		kmedoids_cap_groups[best_move.source_group].total_cent_dist -= task_dist[best_move.ele][medoids[best_move.source_group]];
		// for target group
		add_element(kmedoids_cap_groups[best_move.target_group].elements, best_move.ele, 1);
		kmedoids_cap_groups[best_move.target_group].demand += best_move.move_demand;
		kmedoids_cap_groups[best_move.target_group].total_cent_dist += task_dist[best_move.ele][medoids[best_move.target_group]];
	}

	// assign group ids for the unused tasks
	for (int i = 1; i <= task_num; i++)
	{
		if (!use[i])
			group_ids[i] = group_ids[inst_tasks[i].inverse];
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Divide the elements into k groups according to the distance matrix with nearly equal demands using k-medoids method
void kmedoids_eq_cap(int *group_ids, int *medoids, double (*dist_mtx)[MAX_TASK_NUM], int capacity, int task_num, int group_num, const task *inst_tasks, double ratio)
{
	// use only one id of edge tasks
	int use[MAX_TASK_NUM];
	memset(use, 0, (task_num+1)*sizeof(int));
	use[0] = task_num;
	for (int i = 1; i <= task_num; i++)
	{
		if (use[inst_tasks[i].inverse] == 0)
			use[i] = 1;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/* compute the lower and upper bounds for the total demand of each group based on group_num and ratio */
	// compute the total demand of the problem
	int total_demand = 0;
	for (int i = 1; i <= task_num; i++)
	{
		if (!use[i])
			continue;

		total_demand += inst_tasks[i].demand;
	}

	int total_route_num = total_demand/capacity+1; // total number of routes
	double avg_fullness = (1.0*total_demand)/(capacity*total_route_num); // the average fullness of each route

	// allocate the number of routes uniformly to each group
	int group_route_num[GROUP_NUM+1];
	group_route_num[0] = group_num;
	int residual_rn = total_route_num;
	for (int g = 1; g <= group_num; g++) // uniformly allocate the route number
	{
		group_route_num[g] = total_route_num/group_num;
		residual_rn -= group_route_num[g];
	}
	for (int g = 1; g <= residual_rn; g++) // allocate the residual routes
	{
		group_route_num[g] ++;
	}

	double group_fullness_lb[GROUP_NUM+1], group_fullness_ub[GROUP_NUM+1];
	group_fullness_lb[0] = group_num;
	group_fullness_ub[0] = group_num;
	for (int g = 1; g <= group_num; g++)
	{
		double group_fullness_dev = ratio*(1-avg_fullness)*sqrt((double)group_route_num[g]); // according to 
		double group_avg_fullness = avg_fullness*group_route_num[g];
		group_fullness_lb[g] = group_avg_fullness-group_fullness_dev;
		group_fullness_ub[g] = group_avg_fullness+group_fullness_dev;
	}

	double group_demand_lb[GROUP_NUM+1], group_demand_ub[GROUP_NUM+1];
	group_demand_lb[0] = group_num;
	group_demand_ub[0] = group_num;
	for (int g = 1; g <= group_num; g++)
	{
		group_demand_lb[g] = group_fullness_lb[g]*capacity;
		group_demand_ub[g] = group_fullness_ub[g]*capacity;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// constrained k-medroids with the lb and ub constraints

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//// initialize the group id of each element
	//int ismedoid[MAX_TASK_NUM];
	//memset(ismedoid, 0, (task_num+1)*sizeof(int));
	//medoids[0] = group_num;
	//ismedoid[0] = task_num;
	//group_ids[0] = task_num;
	//
	//// get a random permutation from 1 to used_tasks[0]
	//int rp_vec[MAX_TASK_NUM];
	//rand_perm(rp_vec, used_tasks[0]);

	//// select medoids randomly
	//for (int g = 1; g <= group_num; g++)
	//{
	//	medoids[g] = used_tasks[rp_vec[g]];
	//	ismedoid[medoids[g]] = 1;
	//	group_ids[medoids[g]] = g;
	//}

	// Initialize the group id of each element
	// (1) 1:group_num appear at least once
	// (2) medoids are distributed as dispersely as possible
	int ismedoid[MAX_TASK_NUM];
	memset(ismedoid, 0, (task_num+1)*sizeof(int));
	ismedoid[0] = task_num;

	group_ids[0] = task_num;
	medoids[0] = group_num;
	// for the first group
	double max_avg_dist = 0;
	for (int i = 1; i <= task_num; i++) // each task i
	{
		if (!use[i]) // task i not used
			continue;

		int tmp_num = 0;
		double tmp_avg_dist = 0;
		for (int j = 1; j <= task_num; j++) // compute avg dist to all the other tasks
		{
			if (!use[j]) // task j not used
				continue;

			tmp_avg_dist += dist_mtx[i][j];
			tmp_num ++;
		}
		tmp_avg_dist /= tmp_num;

		if (tmp_avg_dist > max_avg_dist)
		{
			max_avg_dist = tmp_avg_dist;
			medoids[1] = i;
		}
	}
	ismedoid[medoids[1]] = 1;

	// for the remaining groups
	for (int g = 2; g <= group_num; g++) // group g
	{
		max_avg_dist = 0;
		for (int i = 1; i <= task_num; i++) // check for each task i
		{
			if (!use[i]) // not used
				continue;
			
			if (ismedoid[i]) // is already a medoid
				continue;
			
			double tmp_avg_dist = 0;
			for (int c = 1; c < g; c++) // compute avg dist to all the existing medoids
			{
				tmp_avg_dist += dist_mtx[i][medoids[c]];
			}
			tmp_avg_dist /= g-1;

			if (tmp_avg_dist > max_avg_dist)
			{
				max_avg_dist = tmp_avg_dist;
				medoids[g] = i;
			}
		}
		ismedoid[medoids[g]] = 1;
	}

	// assign group ids for the medoids
	for (int c = 1; c <= group_num; c++)
	{
		group_ids[medoids[c]] = c;
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// assign group ids according to medoids subject to the lb and up constraints
	typedef struct choice
	{
		int id;
		int demand;
		int incr_med_dists[GROUP_NUM+1]; // distance to medoids, sorted by the increasing order
		int incr_groups[GROUP_NUM+1]; // the corresponding sorted groups
		int assigned;
	} choice;

	// get all the choices
	int choice_num = 0;
	choice sorted_choices[MAX_TASK_NUM];
	for (int i = 1; i <= task_num; i++)
	{
		if (!use[i]) // task i not used
			continue;

		if (ismedoid[i]) // is already a medoid
			continue;

		int id = i;
		int demand = inst_tasks[i].demand;
		int incr_med_dists[GROUP_NUM+1];
		int incr_groups[GROUP_NUM+1];
		incr_med_dists[0] = group_num;
		incr_groups[0] = group_num;
		for (int g = 1; g <= group_num; g++)
		{
			incr_med_dists[g] = dist_mtx[i][medoids[g]];
			incr_groups[g] = g;
		}

		// sort the distances
		for (int g1 = 1; g1 < group_num; g1++)
		{
			for (int g2 = g1+1; g2 <= group_num; g2++)
			{
				if (incr_med_dists[g1] > incr_med_dists[g2])
				{
					// swap
					int tmp_med_dist = incr_med_dists[g1];
					incr_med_dists[g1] = incr_med_dists[g2];
					incr_med_dists[g2] = tmp_med_dist;
					int tmp_group = incr_groups[g1];
					incr_groups[g1] = incr_groups[g2];
					incr_groups[g2] = tmp_group;
				}
			}
		}

		choice_num ++;
		sorted_choices[choice_num].id = id;
		sorted_choices[choice_num].demand = demand;
		memcpy(sorted_choices[choice_num].incr_med_dists, incr_med_dists, sizeof(incr_med_dists));
		memcpy(sorted_choices[choice_num].incr_groups, incr_groups, sizeof(incr_groups));
		sorted_choices[choice_num].assigned = 0;
	}

	// assign all the choices
	int group_demand[GROUP_NUM+1];
	group_demand[0] = group_num;
	for (int g = 1; g <= group_num; g++)
	{
		group_demand[g] = inst_tasks[medoids[g]].demand; // initialize the group demand
	}

	int assigned_num = 0;
	while (assigned_num < choice_num)
	{
		for (int step = 1; step < group_num; step++) // at each step, assign the choices to the current best group
		{
			// sort the choices based on the current step
			for (int i = 1; i < choice_num; i++)
			{
				if (sorted_choices[i].assigned) // already assigned
					continue;

				for (int j = i+1; j <= choice_num; j++)
				{
					if (sorted_choices[j].assigned) // already assigned
						continue;

					int gain1 = sorted_choices[i].incr_med_dists[step+1]-sorted_choices[i].incr_med_dists[step];
					int gain2 = sorted_choices[j].incr_med_dists[step+1]-sorted_choices[j].incr_med_dists[step];
					if (gain1 < gain2)
					{
						choice tmp_choice;
						tmp_choice = sorted_choices[i];
						sorted_choices[i] = sorted_choices[j];
						sorted_choices[j] = tmp_choice;
					}
				}
			}

			// assign the choices
			for (int i = 1; i <= choice_num; i++)
			{
				if (sorted_choices[i].assigned) // already assigned
					continue;

				int to_group = sorted_choices[i].incr_groups[step];
				if (group_demand[to_group]+sorted_choices[i].demand < group_demand_ub[to_group]) // constraint satisfied
				{
					group_ids[sorted_choices[i].id] = to_group;
					sorted_choices[i].assigned = 1;
					group_demand[to_group] += sorted_choices[i].demand;

					assigned_num ++;
				}
			}
		}

		// put all the rest choices in their last group
		for (int i = 1; i <= choice_num; i++)
		{
			if (sorted_choices[i].assigned) // already assigned
				continue;

			int to_group = sorted_choices[i].incr_groups[group_num];
			group_ids[sorted_choices[i].id] = to_group;
			sorted_choices[i].assigned = 1;
			group_demand[to_group] += sorted_choices[i].demand;

			assigned_num ++;
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// compute the current total cost
	int total_cost = 0;
	for (int i = 1; i <= task_num; i++)
	{
		if (!use[i]) // task i not used
			continue;

		if (ismedoid[i]) // is already a medoid
			continue;

		total_cost += dist_mtx[i][medoids[group_ids[i]]];
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Repeat updating
	int repeat = 1;
	while (repeat)
	{
		repeat = 0;

		// tmp medoids, tmp group ids and tmp total cost
		int best_medoids[GROUP_NUM+1];
		memcpy(best_medoids, medoids, (GROUP_NUM+1)*sizeof(int));
		int best_ismedoid[MAX_TASK_NUM];
		memcpy(best_ismedoid, ismedoid, MAX_TASK_NUM*sizeof(int));
		int best_group_ids[MAX_TASK_NUM];
		memcpy(best_group_ids, group_ids, MAX_TASK_NUM*sizeof(int));
		int best_total_cost = total_cost;

		for (int tg = 1; tg <= group_num; tg++) // for each medoid
		{
			for (int ti = 1; ti <= task_num; ti++) // for each non-medoid points
			{
				if (!use[ti]) // task i not used
					continue;

				if (ismedoid[ti]) // is already a medoid
					continue;

				// swap i and medoid[g]
				int tmp_medoids[GROUP_NUM+1];
				memcpy(tmp_medoids, medoids, (GROUP_NUM+1)*sizeof(int));
				int tmp_ismedoid[MAX_TASK_NUM];
				memcpy(tmp_ismedoid, ismedoid, MAX_TASK_NUM*sizeof(int));

				tmp_ismedoid[medoids[tg]] = 0;
				tmp_ismedoid[ti] = 1;
				tmp_medoids[tg] = ti;

				int tmp_group_ids[MAX_TASK_NUM];
				tmp_group_ids[0] = task_num;
				for (int g = 1; g <= group_num; g++)
				{
					tmp_group_ids[tmp_medoids[g]] = g;
				}

				///////////////////////////////////////////////////////////////////////////////////////////////////////
				// assign group ids according to tmp_medoids subject to the lb and up constraints
				typedef struct choice
				{
					int id;
					int demand;
					int incr_med_dists[GROUP_NUM+1]; // distance to medoids, sorted by the increasing order
					int incr_groups[GROUP_NUM+1]; // the corresponding sorted groups
					int assigned;
				} choice;

				// get all the choices
				int choice_num = 0;
				choice sorted_choices[MAX_TASK_NUM];
				for (int i = 1; i <= task_num; i++)
				{
					if (!use[i]) // task i not used
						continue;

					if (tmp_ismedoid[i]) // is already a medoid
						continue;

					int id = i;
					int demand = inst_tasks[i].demand;
					int incr_med_dists[GROUP_NUM+1];
					int incr_groups[GROUP_NUM+1];
					incr_med_dists[0] = group_num;
					incr_groups[0] = group_num;
					for (int g = 1; g <= group_num; g++)
					{
						incr_med_dists[g] = dist_mtx[i][tmp_medoids[g]];
						incr_groups[g] = g;
					}

					// sort the distances
					for (int g1 = 1; g1 < group_num; g1++)
					{
						for (int g2 = g1+1; g2 <= group_num; g2++)
						{
							if (incr_med_dists[g1] > incr_med_dists[g2])
							{
								// swap
								int tmp_med_dist = incr_med_dists[g1];
								incr_med_dists[g1] = incr_med_dists[g2];
								incr_med_dists[g2] = tmp_med_dist;
								int tmp_group = incr_groups[g1];
								incr_groups[g1] = incr_groups[g2];
								incr_groups[g2] = tmp_group;
							}
						}
					}

					choice_num ++;
					sorted_choices[choice_num].id = id;
					sorted_choices[choice_num].demand = demand;
					memcpy(sorted_choices[choice_num].incr_med_dists, incr_med_dists, sizeof(incr_med_dists));
					memcpy(sorted_choices[choice_num].incr_groups, incr_groups, sizeof(incr_groups));
					sorted_choices[choice_num].assigned = 0;
				}

				// assign all the choices
				int group_demand[GROUP_NUM+1];
				group_demand[0] = group_num;
				for (int g = 1; g <= group_num; g++)
				{
					group_demand[g] = inst_tasks[tmp_medoids[g]].demand; // initialize the group demand
				}

				int assigned_num = 0;
				while (assigned_num < choice_num)
				{
					for (int step = 1; step < group_num; step++) // at each step, assign the choices to the current best group
					{
						// sort the choices based on the current step
						for (int i = 1; i < choice_num; i++)
						{
							if (sorted_choices[i].assigned) // already assigned
								continue;

							for (int j = i+1; j <= choice_num; j++)
							{
								if (sorted_choices[j].assigned) // already assigned
									continue;

								int gain1 = sorted_choices[i].incr_med_dists[step+1]-sorted_choices[i].incr_med_dists[step];
								int gain2 = sorted_choices[j].incr_med_dists[step+1]-sorted_choices[j].incr_med_dists[step];
								if (gain1 < gain2)
								{
									choice tmp_choice;
									tmp_choice = sorted_choices[i];
									sorted_choices[i] = sorted_choices[j];
									sorted_choices[j] = tmp_choice;
								}
							}
						}

						// assign the choices
						for (int i = 1; i <= choice_num; i++)
						{
							if (sorted_choices[i].assigned) // already assigned
								continue;

							int to_group = sorted_choices[i].incr_groups[step];
							if (group_demand[to_group]+sorted_choices[i].demand < group_demand_ub[to_group]) // constraint satisfied
							{
								tmp_group_ids[sorted_choices[i].id] = to_group;
								sorted_choices[i].assigned = 1;
								group_demand[to_group] += sorted_choices[i].demand;

								assigned_num ++;
							}
						}
					}

					// put all the rest choices in their last group
					for (int i = 1; i <= choice_num; i++)
					{
						if (sorted_choices[i].assigned) // already assigned
							continue;

						int to_group = sorted_choices[i].incr_groups[group_num];
						tmp_group_ids[sorted_choices[i].id] = to_group;
						sorted_choices[i].assigned = 1;
						group_demand[to_group] += sorted_choices[i].demand;

						assigned_num ++;
					}
				}

				// compute tmp total cost
				int tmp_total_cost = 0;
				for (int ti = 1; ti <= task_num; ti++)
				{
					if (!use[ti]) // task i not used
						continue;

					if (tmp_ismedoid[ti]) // is already a medoid
						continue;

					tmp_total_cost += dist_mtx[ti][tmp_medoids[tmp_group_ids[ti]]];
				}

				if (tmp_total_cost < best_total_cost)
				{
					memcpy(best_medoids, tmp_medoids, (GROUP_NUM+1)*sizeof(int));
					memcpy(best_ismedoid, tmp_ismedoid, MAX_TASK_NUM*sizeof(int));
					memcpy(best_group_ids, tmp_group_ids, MAX_TASK_NUM*sizeof(int));
					best_total_cost = tmp_total_cost;
				}
			}
		}

		if (best_total_cost < total_cost) // better clustering found
		{
			repeat = 1;
			memcpy(medoids, best_medoids, (GROUP_NUM+1)*sizeof(int));
			memcpy(ismedoid, best_ismedoid, MAX_TASK_NUM*sizeof(int));
			memcpy(group_ids, best_group_ids, MAX_TASK_NUM*sizeof(int));
			total_cost = best_total_cost;
		}
	}

	// double-check the group ids of the medoids
	for (int g = 1; g <= group_num; g++)
	{
		group_ids[medoids[g]] = g;
	}

	// double-check the group demand
	memset(group_demand, 0, sizeof(group_demand));
	group_demand[0] = group_num;
	for (int i = 1; i <= task_num; i++)
	{
		if (!use[i])
			continue;

		group_demand[group_ids[i]] += inst_tasks[i].demand; // initialize the group demand
	}

	// assign group ids for the unused tasks
	for (int i = 1; i <= task_num; i++)
	{
		if (!use[i])
			group_ids[i] = group_ids[inst_tasks[i].inverse];
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Divide the elements into k groups according to the distance matrix with nearly equal demands using fuzzy k-medoids method
void fuzzy_kmedoids_eq_cap(int *group_ids, int *medoids, double (*dist_mtx)[MAX_TASK_NUM], int capacity, int task_num, int group_num, const task *inst_tasks, double ratio)
{
	// use only one id of edge tasks
	int use[MAX_TASK_NUM];
	memset(use, 0, (task_num+1)*sizeof(int));
	use[0] = task_num;
	for (int i = 1; i <= task_num; i++)
	{
		if (use[inst_tasks[i].inverse] == 0)
			use[i] = 1;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/* compute the lower and upper bounds for the total demand of each group based on group_num and ratio */
	// compute the total demand of the problem
	int total_demand = 0;
	for (int i = 1; i <= task_num; i++)
	{
		if (!use[i])
			continue;

		total_demand += inst_tasks[i].demand;
	}

	int total_route_num = total_demand/capacity+1; // total number of routes
	double avg_fullness = (1.0*total_demand)/(capacity*total_route_num); // the average fullness of each route

	// allocate the number of routes uniformly to each group
	int group_route_num[GROUP_NUM+1];
	group_route_num[0] = group_num;
	int residual_rn = total_route_num;
	for (int g = 1; g <= group_num; g++) // uniformly allocate the route number
	{
		group_route_num[g] = total_route_num/group_num;
		residual_rn -= group_route_num[g];
	}
	for (int g = 1; g <= residual_rn; g++) // allocate the residual routes
	{
		group_route_num[g] ++;
	}

	double group_fullness_lb[GROUP_NUM+1], group_fullness_ub[GROUP_NUM+1];
	group_fullness_lb[0] = group_num;
	group_fullness_ub[0] = group_num;
	for (int g = 1; g <= group_num; g++)
	{
		double group_fullness_dev = ratio*(1-avg_fullness)*sqrt((double)group_route_num[g]); // according to 
		double group_avg_fullness = avg_fullness*group_route_num[g];
		group_fullness_lb[g] = group_avg_fullness-group_fullness_dev;
		group_fullness_ub[g] = group_avg_fullness+group_fullness_dev;
	}

	double group_demand_lb[GROUP_NUM+1], group_demand_ub[GROUP_NUM+1];
	group_demand_lb[0] = group_num;
	group_demand_ub[0] = group_num;
	for (int g = 1; g <= group_num; g++)
	{
		group_demand_lb[g] = group_fullness_lb[g]*capacity;
		group_demand_ub[g] = group_fullness_ub[g]*capacity;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// constrained k-medroids with the lb and ub constraints

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//// initialize the group id of each element
	//int ismedoid[MAX_TASK_NUM];
	//memset(ismedoid, 0, (task_num+1)*sizeof(int));
	//medoids[0] = group_num;
	//ismedoid[0] = task_num;
	//group_ids[0] = task_num;
	//
	//// get a random permutation from 1 to used_tasks[0]
	//int rp_vec[MAX_TASK_NUM];
	//rand_perm(rp_vec, used_tasks[0]);

	//// select medoids randomly
	//for (int g = 1; g <= group_num; g++)
	//{
	//	medoids[g] = used_tasks[rp_vec[g]];
	//	ismedoid[medoids[g]] = 1;
	//	group_ids[medoids[g]] = g;
	//}

	// Initialize the group id of each element
	// (1) 1:group_num appear at least once
	// (2) medoids are distributed as dispersely as possible
	int ismedoid[MAX_TASK_NUM];
	memset(ismedoid, 0, (task_num+1)*sizeof(int));
	ismedoid[0] = task_num;

	group_ids[0] = task_num;
	medoids[0] = group_num;
	// for the first group
	double max_avg_dist = 0;
	for (int i = 1; i <= task_num; i++) // each task i
	{
		if (!use[i]) // task i not used
			continue;

		int tmp_num = 0;
		double tmp_avg_dist = 0;
		for (int j = 1; j <= task_num; j++) // compute avg dist to all the other tasks
		{
			if (!use[j]) // task j not used
				continue;

			tmp_avg_dist += dist_mtx[i][j];
			tmp_num ++;
		}
		tmp_avg_dist /= tmp_num;

		if (tmp_avg_dist > max_avg_dist)
		{
			max_avg_dist = tmp_avg_dist;
			medoids[1] = i;
		}
	}
	ismedoid[medoids[1]] = 1;

	// for the remaining groups
	for (int g = 2; g <= group_num; g++) // group g
	{
		max_avg_dist = 0;
		for (int i = 1; i <= task_num; i++) // check for each task i
		{
			if (!use[i]) // not used
				continue;
			
			if (ismedoid[i]) // is already a medoid
				continue;
			
			double tmp_avg_dist = 0;
			for (int c = 1; c < g; c++) // compute avg dist to all the existing medoids
			{
				tmp_avg_dist += dist_mtx[i][medoids[c]];
			}
			tmp_avg_dist /= g-1;

			if (tmp_avg_dist > max_avg_dist)
			{
				max_avg_dist = tmp_avg_dist;
				medoids[g] = i;
			}
		}
		ismedoid[medoids[g]] = 1;
	}

	// assign group ids for the medoids
	for (int c = 1; c <= group_num; c++)
	{
		group_ids[medoids[c]] = c;
	}


	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// assign group ids according to medoids subject to the lb and up constraints
	typedef struct choice
	{
		int id;
		int demand;
		int incr_med_dists[GROUP_NUM+1]; // distance to medoids, sorted by the increasing order
		double decr_membership[GROUP_NUM+1]; // membership to medoids, sorted by the decreasing order
		int incr_groups[GROUP_NUM+1]; // the corresponding sorted groups
		int assigned;
	} choice;

	// get all the choices
	int choice_num = 0;
	choice sorted_choices[MAX_TASK_NUM];
	for (int i = 1; i <= task_num; i++)
	{
		if (!use[i]) // task i not used
			continue;

		if (ismedoid[i]) // is already a medoid
			continue;

		int id = i;
		int demand = inst_tasks[i].demand;
		int incr_med_dists[GROUP_NUM+1];
		double decr_membership[GROUP_NUM+1];
		int incr_groups[GROUP_NUM+1];
		incr_med_dists[0] = group_num;
		incr_groups[0] = group_num;
		for (int g = 1; g <= group_num; g++)
		{
			incr_med_dists[g] = dist_mtx[i][medoids[g]];
			incr_groups[g] = g;
		}

		// sort the distances
		for (int g1 = 1; g1 < group_num; g1++)
		{
			for (int g2 = g1+1; g2 <= group_num; g2++)
			{
				if (incr_med_dists[g1] > incr_med_dists[g2])
				{
					// swap
					int tmp_med_dist = incr_med_dists[g1];
					incr_med_dists[g1] = incr_med_dists[g2];
					incr_med_dists[g2] = tmp_med_dist;
					int tmp_group = incr_groups[g1];
					incr_groups[g1] = incr_groups[g2];
					incr_groups[g2] = tmp_group;
				}
			}
		}

		for (int g = 1; g <= group_num; g++)
		{
			if (incr_med_dists[g] == 0)
			{
				decr_membership[g] = INF;
			}
			else
			{
				decr_membership[g] = 1.0/incr_med_dists[g];
			}
		}

		// normalization
		double sum_membership = 0;
		for (int g = 1; g <= group_num; g++)
		{
			sum_membership += decr_membership[g];
		}
		for (int g = 1; g <= group_num; g++)
		{
			decr_membership[g] /= sum_membership;
		}

		choice_num ++;
		sorted_choices[choice_num].id = id;
		sorted_choices[choice_num].demand = demand;
		memcpy(sorted_choices[choice_num].incr_med_dists, incr_med_dists, sizeof(incr_med_dists));
		memcpy(sorted_choices[choice_num].decr_membership, decr_membership, sizeof(decr_membership));
		memcpy(sorted_choices[choice_num].incr_groups, incr_groups, sizeof(incr_groups));
		sorted_choices[choice_num].assigned = 0;
	}

	// assign all the choices
	int group_demand[GROUP_NUM+1];
	group_demand[0] = group_num;
	for (int g = 1; g <= group_num; g++)
	{
		group_demand[g] = inst_tasks[medoids[g]].demand; // initialize the group demand
	}

	int assigned_num = 0;
	while (assigned_num < choice_num)
	{
		for (int step = 1; step <= group_num; step++) // at each step, assign the choices to the current best group
		{
			// sort the choices based on the current step
			for (int i = 1; i < choice_num; i++)
			{
				if (sorted_choices[i].assigned) // already assigned
					continue;

				for (int j = i+1; j <= choice_num; j++)
				{
					if (sorted_choices[j].assigned) // already assigned
						continue;

					double membership1 = sorted_choices[i].decr_membership[step];
					double membership2 = sorted_choices[j].decr_membership[step];
					if (membership1 < membership2) // membership to the current medoid: high -> low
					{
						choice tmp_choice;
						tmp_choice = sorted_choices[i];
						sorted_choices[i] = sorted_choices[j];
						sorted_choices[j] = tmp_choice;
					}
				}
			}

			// assign the choices
			for (int i = 1; i <= choice_num; i++)
			{
				if (sorted_choices[i].assigned) // already assigned
					continue;

				int to_group = sorted_choices[i].incr_groups[step];
				if (group_demand[to_group]+sorted_choices[i].demand < group_demand_ub[to_group] || step == group_num) // constraint satisfied or for the last group
				{
					if (group_demand[to_group]+sorted_choices[i].demand > group_demand_ub[to_group])
					{
						to_group = sorted_choices[i].incr_groups[1]; // if not available for the last group, just insert into the best group
					}
					group_ids[sorted_choices[i].id] = to_group;
					sorted_choices[i].assigned = 1;
					group_demand[to_group] += sorted_choices[i].demand;

					assigned_num ++;
				}
			}
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// compute the current total cost
	int total_cost = 0;
	for (int i = 1; i <= task_num; i++)
	{
		if (!use[i]) // task i not used
			continue;

		if (ismedoid[i]) // is already a medoid
			continue;

		total_cost += dist_mtx[i][medoids[group_ids[i]]];
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Repeat updating
	int repeat = 1;
	while (repeat)
	{
		repeat = 0;

		// tmp medoids, tmp group ids and tmp total cost
		int best_medoids[GROUP_NUM+1];
		memcpy(best_medoids, medoids, (GROUP_NUM+1)*sizeof(int));
		int best_ismedoid[MAX_TASK_NUM];
		memcpy(best_ismedoid, ismedoid, MAX_TASK_NUM*sizeof(int));
		int best_group_ids[MAX_TASK_NUM];
		memcpy(best_group_ids, group_ids, MAX_TASK_NUM*sizeof(int));
		int best_total_cost = total_cost;

		for (int tg = 1; tg <= group_num; tg++) // for each medoid
		{
			for (int ti = 1; ti <= task_num; ti++) // for each non-medoid points
			{
				if (!use[ti]) // task i not used
					continue;

				if (ismedoid[ti]) // is already a medoid
					continue;

				// swap i and medoid[g]
				int tmp_medoids[GROUP_NUM+1];
				memcpy(tmp_medoids, medoids, (GROUP_NUM+1)*sizeof(int));
				int tmp_ismedoid[MAX_TASK_NUM];
				memcpy(tmp_ismedoid, ismedoid, MAX_TASK_NUM*sizeof(int));

				tmp_ismedoid[medoids[tg]] = 0;
				tmp_ismedoid[ti] = 1;
				tmp_medoids[tg] = ti;

				int tmp_group_ids[MAX_TASK_NUM];
				tmp_group_ids[0] = task_num;
				for (int g = 1; g <= group_num; g++)
				{
					tmp_group_ids[tmp_medoids[g]] = g;
				}

				///////////////////////////////////////////////////////////////////////////////////////////////////////
				// assign group ids according to tmp_medoids subject to the lb and up constraints
				typedef struct choice
				{
					int id;
					int demand;
					int incr_med_dists[GROUP_NUM+1]; // distance to medoids, sorted by the increasing order
					double decr_membership[GROUP_NUM+1]; // membership to medoids, sorted by the decreasing order
					int incr_groups[GROUP_NUM+1]; // the corresponding sorted groups
					int assigned;
				} choice;

				// get all the choices
				int choice_num = 0;
				choice sorted_choices[MAX_TASK_NUM];
				for (int i = 1; i <= task_num; i++)
				{
					if (!use[i]) // task i not used
						continue;

					if (tmp_ismedoid[i]) // is already a medoid
						continue;

					int id = i;
					int demand = inst_tasks[i].demand;
					int incr_med_dists[GROUP_NUM+1];
					double decr_membership[GROUP_NUM+1];
					int incr_groups[GROUP_NUM+1];
					incr_med_dists[0] = group_num;
					incr_groups[0] = group_num;
					for (int g = 1; g <= group_num; g++)
					{
						incr_med_dists[g] = dist_mtx[i][tmp_medoids[g]];
						incr_groups[g] = g;
					}

					// sort the distances
					for (int g1 = 1; g1 < group_num; g1++)
					{
						for (int g2 = g1+1; g2 <= group_num; g2++)
						{
							if (incr_med_dists[g1] > incr_med_dists[g2])
							{
								// swap
								int tmp_med_dist = incr_med_dists[g1];
								incr_med_dists[g1] = incr_med_dists[g2];
								incr_med_dists[g2] = tmp_med_dist;
								int tmp_group = incr_groups[g1];
								incr_groups[g1] = incr_groups[g2];
								incr_groups[g2] = tmp_group;
							}
						}
					}

					for (int g = 1; g <= group_num; g++)
					{
						if (incr_med_dists[g] == 0)
						{
							decr_membership[g] = INF;
						}
						else
						{
							decr_membership[g] = 1.0/incr_med_dists[g];
						}
					}

					// normalization
					double sum_membership = 0;
					for (int g = 1; g <= group_num; g++)
					{
						sum_membership += decr_membership[g];
					}
					for (int g = 1; g <= group_num; g++)
					{
						decr_membership[g] /= sum_membership;
					}

					choice_num ++;
					sorted_choices[choice_num].id = id;
					sorted_choices[choice_num].demand = demand;
					memcpy(sorted_choices[choice_num].incr_med_dists, incr_med_dists, sizeof(incr_med_dists));
					memcpy(sorted_choices[choice_num].decr_membership, decr_membership, sizeof(decr_membership));
					memcpy(sorted_choices[choice_num].incr_groups, incr_groups, sizeof(incr_groups));
					sorted_choices[choice_num].assigned = 0;
				}

				// assign all the choices
				int group_demand[GROUP_NUM+1];
				group_demand[0] = group_num;
				for (int g = 1; g <= group_num; g++)
				{
					group_demand[g] = inst_tasks[tmp_medoids[g]].demand; // initialize the group demand
				}

				int assigned_num = 0;
				while (assigned_num < choice_num)
				{
					for (int step = 1; step <= group_num; step++) // at each step, assign the choices to the current best group
					{
						// sort the choices based on the current step
						for (int i = 1; i < choice_num; i++)
						{
							if (sorted_choices[i].assigned) // already assigned
								continue;

							for (int j = i+1; j <= choice_num; j++)
							{
								if (sorted_choices[j].assigned) // already assigned
									continue;

								double membership1 = sorted_choices[i].decr_membership[step];
								double membership2 = sorted_choices[j].decr_membership[step];
								if (membership1 < membership2) // membership to the current medoid: high -> low
								{
									choice tmp_choice;
									tmp_choice = sorted_choices[i];
									sorted_choices[i] = sorted_choices[j];
									sorted_choices[j] = tmp_choice;
								}
							}
						}

						// assign the choices
						for (int i = 1; i <= choice_num; i++)
						{
							if (sorted_choices[i].assigned) // already assigned
								continue;

							int to_group = sorted_choices[i].incr_groups[step];
							if (group_demand[to_group]+sorted_choices[i].demand < group_demand_ub[to_group] || step == group_num) // constraint satisfied or for the last group
							{
								if (group_demand[to_group]+sorted_choices[i].demand > group_demand_ub[to_group])
								{
									to_group = sorted_choices[i].incr_groups[1]; // if not available for the last group, just insert into the best group
								}
								tmp_group_ids[sorted_choices[i].id] = to_group;
								sorted_choices[i].assigned = 1;
								group_demand[to_group] += sorted_choices[i].demand;

								assigned_num ++;
							}
						}
					}

					//// put all the rest choices in their last group
					//for (int i = 1; i <= choice_num; i++)
					//{
					//	if (sorted_choices[i].assigned) // already assigned
					//		continue;

					//	int to_group = sorted_choices[i].incr_groups[group_num];
					//	tmp_group_ids[sorted_choices[i].id] = to_group;
					//	sorted_choices[i].assigned = 1;
					//	group_demand[to_group] += sorted_choices[i].demand;

					//	assigned_num ++;
					//}
				}

				// compute tmp total cost
				int tmp_total_cost = 0;
				for (int i = 1; i <= task_num; i++)
				{
					if (!use[i]) // task i not used
						continue;

					if (tmp_ismedoid[i]) // is already a medoid
						continue;

					tmp_total_cost += dist_mtx[i][tmp_medoids[tmp_group_ids[i]]];
				}

				if (tmp_total_cost < best_total_cost)
				{
					memcpy(best_medoids, tmp_medoids, (GROUP_NUM+1)*sizeof(int));
					memcpy(best_ismedoid, tmp_ismedoid, MAX_TASK_NUM*sizeof(int));
					memcpy(best_group_ids, tmp_group_ids, MAX_TASK_NUM*sizeof(int));
					best_total_cost = tmp_total_cost;
				}
			}
		}

		if (best_total_cost < total_cost) // better clustering found
		{
			repeat = 1;
			memcpy(medoids, best_medoids, (GROUP_NUM+1)*sizeof(int));
			memcpy(ismedoid, best_ismedoid, MAX_TASK_NUM*sizeof(int));
			memcpy(group_ids, best_group_ids, MAX_TASK_NUM*sizeof(int));
			total_cost = best_total_cost;
		}
	}

	// double-check the group ids of the medoids
	for (int g = 1; g <= group_num; g++)
	{
		group_ids[medoids[g]] = g;
	}

	// double-check the group demand
	memset(group_demand, 0, sizeof(group_demand));
	group_demand[0] = group_num;
	for (int i = 1; i <= task_num; i++)
	{
		if (!use[i])
			continue;

		group_demand[group_ids[i]] += inst_tasks[i].demand; // initialize the group demand
	}

	// assign group ids for the unused tasks
	for (int i = 1; i <= task_num; i++)
	{
		if (!use[i])
			group_ids[i] = group_ids[inst_tasks[i].inverse];
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Divide the elements into k groups according to the distance matrix using k-medoids method considering the depot distance and capacity constraint
void kmedoids_depot_cap(int *group_ids, int *medoids, double (*dist_mtx)[MAX_TASK_NUM], int capacity, int task_num, int group_num, const task *inst_tasks)
{
	// use only one id of edge tasks
	int use[MAX_TASK_NUM];
	memset(use, 0, (task_num+1)*sizeof(int));
	use[0] = task_num;
	for (int i = 1; i <= task_num; i++)
	{
		if (use[inst_tasks[i].inverse] == 0)
			use[i] = 1;
	}

	//// initialize the group id of each element
	//// get used task vector
	//int used_tasks[MAX_TASK_NUM];
	//used_tasks[0] = 0;
	//for (int i = 1; i <= task_num; i++)
	//{
	//	if (!use[i])
	//		continue;
	//	
	//	used_tasks[0] ++;
	//	used_tasks[used_tasks[0]] = i;
	//}

	//int ismedoid[MAX_TASK_NUM];
	//memset(ismedoid, 0, (task_num+1)*sizeof(int));
	//medoids[0] = group_num;
	//ismedoid[0] = task_num;
	//group_ids[0] = task_num;
	//
	//// get a random permutation from 1 to used_tasks[0]
	//int rp_vec[MAX_TASK_NUM];
	//rand_perm(rp_vec, used_tasks[0]);

	//// select medoids randomly
	//for (int g = 1; g <= group_num; g++)
	//{
	//	medoids[g] = used_tasks[rp_vec[g]];
	//	ismedoid[medoids[g]] = 1;
	//	group_ids[medoids[g]] = g;
	//}

	// Initialize the group id of each element
	// (1) 1:group_num appear at least once
	// (2) medoids are distributed as dispersely as possible
	int ismedoid[MAX_TASK_NUM];
	memset(ismedoid, 0, (task_num+1)*sizeof(int));
	ismedoid[0] = task_num;

	group_ids[0] = task_num;
	medoids[0] = group_num;
	// for the first group
	double max_avg_dist = 0;
	for (int i = 1; i <= task_num; i++) // each task i
	{
		if (!use[i]) // task i not used
			continue;

		int tmp_num = 0;
		double tmp_avg_dist = 0;
		for (int j = 1; j <= task_num; j++) // compute avg dist to all the other tasks
		{
			if (!use[j]) // task j not used
				continue;

			tmp_avg_dist += dist_mtx[i][j];
			tmp_num ++;
		}
		tmp_avg_dist /= tmp_num;

		if (tmp_avg_dist > max_avg_dist)
		{
			max_avg_dist = tmp_avg_dist;
			medoids[1] = i;
		}
	}
	ismedoid[medoids[1]] = 1;

	// for the remaining groups
	for (int g = 2; g <= group_num; g++) // group g
	{
		max_avg_dist = 0;
		for (int i = 1; i <= task_num; i++) // check for each task i
		{
			if (!use[i]) // not used
				continue;
			
			if (ismedoid[i]) // is already a medoid
				continue;
			
			double tmp_avg_dist = 0;
			for (int c = 1; c < g; c++) // compute avg dist to all the existing medoids
			{
				tmp_avg_dist += dist_mtx[i][medoids[c]];
			}
			tmp_avg_dist /= g-1;

			if (tmp_avg_dist > max_avg_dist)
			{
				max_avg_dist = tmp_avg_dist;
				medoids[g] = i;
			}
		}
		ismedoid[medoids[g]] = 1;
	}

	// assign group ids for the medoids
	for (int c = 1; c <= group_num; c++)
	{
		group_ids[medoids[c]] = c;
	}



	// assign group ids according to medoids
	for (int i = 1; i <= task_num; i++)
	{
		if (!use[i]) // task i not used
			continue;

		if (ismedoid[i]) // is already a medoid
			continue;

		double min_med_dist = INF; // minimal dist to the medoids
		for (int g = 1; g <= group_num; g++)
		{
			double tmp_med_dist = dist_mtx[i][medoids[g]];

			if (tmp_med_dist < min_med_dist)
			{
				min_med_dist = tmp_med_dist;
				group_ids[i] = g;
			}
		}
	}

	// obtain the information of the groups
	typedef struct group
	{
		int center;
		int elements[MAX_TASK_NUM];
		int demand;
		int route_num; // number of routes
		int total_cost; // the total cost obtained by Fredrickson's heuristic
	} group;

	group div_groups[GROUP_NUM+1];
	for (int g = 1; g <= group_num; g++)
	{
		div_groups[g].center = medoids[g];
		div_groups[g].elements[0] = 0;
		div_groups[g].demand = 0;
	}

	for (int i = 1; i <= task_num; i++)
	{
		if (!use[i])
			continue;

		div_groups[group_ids[i]].elements[0] ++;
		div_groups[group_ids[i]].elements[div_groups[group_ids[i]].elements[0]] = i;
		div_groups[group_ids[i]].demand += inst_tasks[i].demand;
	}

	for (int g = 1; g <= group_num; g++)
	{
		div_groups[g].route_num = ceil((1.0*div_groups[g].demand)/capacity);
	}

	double total_cost = 0;
	for (int g = 1; g <= group_num; g++)
	{
		int serv_mark[MAX_TASK_NUM];
		memset(serv_mark, 0, sizeof(serv_mark));
		serv_mark[0] = task_num;
		for (int i = 1; i <= div_groups[g].elements[0]; i++)
		{
			int tmp_task = div_groups[g].elements[i];
			serv_mark[tmp_task] = 1;
			serv_mark[inst_tasks[tmp_task].inverse] = 1;
		}
		individual tmp_sub_indi;
		path_scanning(&tmp_sub_indi, inst_tasks, serv_mark);

		//int fred_route[MAX_SOLUTION_LENGTH];
		//int tmp_cost = fred_heuristic(fred_route, div_groups[g].elements, div_groups[g].route_num, inst_tasks);

		total_cost += tmp_sub_indi.total_cost;
	}
	
	// Repeat updating
	int repeat = 1;
	while (repeat)
	{
		repeat = 0;

		// tmp medoids, tmp group ids and tmp total cost
		int best_medoids[GROUP_NUM+1];
		memcpy(best_medoids, medoids, (GROUP_NUM+1)*sizeof(int));
		int best_ismedoid[MAX_TASK_NUM];
		memcpy(best_ismedoid, ismedoid, MAX_TASK_NUM*sizeof(int));
		int best_group_ids[MAX_TASK_NUM];
		memcpy(best_group_ids, group_ids, MAX_TASK_NUM*sizeof(int));
		double best_total_cost = total_cost;

		for (int tg = 1; tg <= group_num; tg++) // for each medoid
		{
			for (int ti = 1; ti <= task_num; ti++) // for each non-medoid points
			{
				if (!use[ti]) // task i not used
					continue;

				if (ismedoid[ti]) // is already a medoid
					continue;

				// swap i and medoid[g]
				int tmp_medoids[GROUP_NUM+1];
				memcpy(tmp_medoids, medoids, (GROUP_NUM+1)*sizeof(int));
				int tmp_ismedoid[MAX_TASK_NUM];
				memcpy(tmp_ismedoid, ismedoid, MAX_TASK_NUM*sizeof(int));

				tmp_ismedoid[medoids[tg]] = 0;
				tmp_ismedoid[ti] = 1;
				tmp_medoids[tg] = ti;

				// assign tmp group ids according to tmp medoids
				int tmp_group_ids[MAX_TASK_NUM];
				tmp_group_ids[0] = task_num;
				for (int g = 1; g <= group_num; g++)
				{
					tmp_group_ids[tmp_medoids[g]] = g;
				}

				for (int i = 1; i <= task_num; i++)
				{
					if (!use[i]) // task i not used
						continue;

					if (tmp_ismedoid[i]) // is already a medoid
						continue;

					double min_med_dist = INF; // minimal dist to the medoids
					for (int g = 1; g <= group_num; g++)
					{
						double tmp_med_dist = dist_mtx[i][tmp_medoids[g]];

						if (tmp_med_dist < min_med_dist)
						{
							min_med_dist = tmp_med_dist;
							tmp_group_ids[i] = g;
						}
					}
				}

				group tmp_div_groups[GROUP_NUM+1];
				for (int g = 1; g <= group_num; g++)
				{
					tmp_div_groups[g].center = tmp_medoids[g];
					tmp_div_groups[g].elements[0] = 0;
					tmp_div_groups[g].demand = 0;
				}

				for (int i = 1; i <= task_num; i++)
				{
					if (!use[i])
						continue;

					tmp_div_groups[tmp_group_ids[i]].elements[0] ++;
					tmp_div_groups[tmp_group_ids[i]].elements[tmp_div_groups[tmp_group_ids[i]].elements[0]] = i;
					tmp_div_groups[tmp_group_ids[i]].demand += inst_tasks[i].demand;
				}

				for (int g = 1; g <= group_num; g++)
				{
					tmp_div_groups[g].route_num = ceil((1.0*tmp_div_groups[g].demand)/capacity);
				}

				// compute tmp total cost
				double tmp_total_cost = 0;
				for (int g = 1; g <= group_num; g++)
				{
					int serv_mark[MAX_TASK_NUM];
					memset(serv_mark, 0, sizeof(serv_mark));
					serv_mark[0] = task_num;
					for (int i = 1; i <= tmp_div_groups[g].elements[0]; i++)
					{
						int tmp_task = tmp_div_groups[g].elements[i];
						serv_mark[tmp_task] = 1;
						serv_mark[inst_tasks[tmp_task].inverse] = 1;
					}
					individual tmp_sub_indi;
					path_scanning(&tmp_sub_indi, inst_tasks, serv_mark);

					//int fred_route[MAX_SOLUTION_LENGTH];
					//int tmp_cost = fred_heuristic(fred_route, tmp_div_groups[g].elements, tmp_div_groups[g].route_num, inst_tasks);

					tmp_total_cost += tmp_sub_indi.total_cost;
				}

				if (tmp_total_cost < best_total_cost)
				{
					memcpy(best_medoids, tmp_medoids, (GROUP_NUM+1)*sizeof(int));
					memcpy(best_ismedoid, tmp_ismedoid, MAX_TASK_NUM*sizeof(int));
					memcpy(best_group_ids, tmp_group_ids, MAX_TASK_NUM*sizeof(int));
					best_total_cost = tmp_total_cost;
				}
			}
		}

		if (best_total_cost < total_cost) // better clustering found
		{
			repeat = 1;
			memcpy(medoids, best_medoids, (GROUP_NUM+1)*sizeof(int));
			memcpy(ismedoid, best_ismedoid, MAX_TASK_NUM*sizeof(int));
			memcpy(group_ids, best_group_ids, MAX_TASK_NUM*sizeof(int));
			total_cost = best_total_cost;
		}
	}

	// assign group ids for the unused tasks
	for (int i = 1; i <= task_num; i++)
	{
		if (!use[i])
			group_ids[i] = group_ids[inst_tasks[i].inverse];
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Cluster using local search
void lscluster_depot_cap(int *group_ids, double (*dist_mtx)[MAX_TASK_NUM], int capacity, int task_num, int group_num, const task *inst_tasks)
{
	// use only one id of edge tasks
	int use[MAX_TASK_NUM];
	memset(use, 0, (task_num+1)*sizeof(int));
	use[0] = task_num;
	for (int i = 1; i <= task_num; i++)
	{
		if (use[inst_tasks[i].inverse] == 0)
			use[i] = 1;
	}

	//// initialize the group id of each element
	//// get used task vector
	//int used_tasks[MAX_TASK_NUM];
	//used_tasks[0] = 0;
	//for (int i = 1; i <= task_num; i++)
	//{
	//	if (!use[i])
	//		continue;
	//	
	//	used_tasks[0] ++;
	//	used_tasks[used_tasks[0]] = i;
	//}

	//int ismedoid[MAX_TASK_NUM];
	//memset(ismedoid, 0, (task_num+1)*sizeof(int));
	//medoids[0] = group_num;
	//ismedoid[0] = task_num;
	//group_ids[0] = task_num;
	//
	//// get a random permutation from 1 to used_tasks[0]
	//int rp_vec[MAX_TASK_NUM];
	//rand_perm(rp_vec, used_tasks[0]);

	//// select medoids randomly
	//for (int g = 1; g <= group_num; g++)
	//{
	//	medoids[g] = used_tasks[rp_vec[g]];
	//	ismedoid[medoids[g]] = 1;
	//	group_ids[medoids[g]] = g;
	//}

	// Initialize the group id of each element
	// (1) 1:group_num appear at least once
	// (2) medoids are distributed as dispersely as possible
	int ismedoid[MAX_TASK_NUM];
	memset(ismedoid, 0, (task_num+1)*sizeof(int));
	ismedoid[0] = task_num;

	group_ids[0] = task_num;
	int medoids[GROUP_NUM+1];
	medoids[0] = group_num;
	// for the first group
	double max_avg_dist = 0;
	for (int i = 1; i <= task_num; i++) // each task i
	{
		if (!use[i]) // task i not used
			continue;

		int tmp_num = 0;
		double tmp_avg_dist = 0;
		for (int j = 1; j <= task_num; j++) // compute avg dist to all the other tasks
		{
			if (!use[j]) // task j not used
				continue;

			tmp_avg_dist += dist_mtx[i][j];
			tmp_num ++;
		}
		tmp_avg_dist /= tmp_num;

		if (tmp_avg_dist > max_avg_dist)
		{
			max_avg_dist = tmp_avg_dist;
			medoids[1] = i;
		}
	}
	ismedoid[medoids[1]] = 1;

	// for the remaining groups
	for (int g = 2; g <= group_num; g++) // group g
	{
		max_avg_dist = 0;
		for (int i = 1; i <= task_num; i++) // check for each task i
		{
			if (!use[i]) // not used
				continue;
			
			if (ismedoid[i]) // is already a medoid
				continue;
			
			double tmp_avg_dist = 0;
			for (int c = 1; c < g; c++) // compute avg dist to all the existing medoids
			{
				tmp_avg_dist += dist_mtx[i][medoids[c]];
			}
			tmp_avg_dist /= g-1;

			if (tmp_avg_dist > max_avg_dist)
			{
				max_avg_dist = tmp_avg_dist;
				medoids[g] = i;
			}
		}
		ismedoid[medoids[g]] = 1;
	}

	// assign group ids for the medoids
	for (int c = 1; c <= group_num; c++)
	{
		group_ids[medoids[c]] = c;
	}



	// assign group ids according to medoids
	for (int i = 1; i <= task_num; i++)
	{
		if (!use[i]) // task i not used
			continue;

		if (ismedoid[i]) // is already a medoid
			continue;

		double min_med_dist = INF; // minimal dist to the medoids
		for (int g = 1; g <= group_num; g++)
		{
			double tmp_med_dist = dist_mtx[i][medoids[g]];

			if (tmp_med_dist < min_med_dist)
			{
				min_med_dist = tmp_med_dist;
				group_ids[i] = g;
			}
		}
	}

	// obtain the information of the groups
	typedef struct group
	{
		int center;
		int elements[MAX_TASK_NUM];
		int demand;
		int route_num; // number of routes
		int total_cost; // the total cost obtained by Fredrickson's heuristic
	} group;

	group div_groups[GROUP_NUM+1];
	for (int g = 1; g <= group_num; g++)
	{
		div_groups[g].center = medoids[g];
		div_groups[g].elements[0] = 0;
		div_groups[g].demand = 0;
	}

	for (int i = 1; i <= task_num; i++)
	{
		if (!use[i])
			continue;

		div_groups[group_ids[i]].elements[0] ++;
		div_groups[group_ids[i]].elements[div_groups[group_ids[i]].elements[0]] = i;
		div_groups[group_ids[i]].demand += inst_tasks[i].demand;
	}

	for (int g = 1; g <= group_num; g++)
	{
		div_groups[g].route_num = ceil((1.0*div_groups[g].demand)/capacity);
	}

	double total_cost = 0;
	for (int g = 1; g <= group_num; g++)
	{
		int serv_mark[MAX_TASK_NUM];
		memset(serv_mark, 0, sizeof(serv_mark));
		serv_mark[0] = task_num;
		for (int i = 1; i <= div_groups[g].elements[0]; i++)
		{
			int tmp_task = div_groups[g].elements[i];
			serv_mark[tmp_task] = 1;
			serv_mark[inst_tasks[tmp_task].inverse] = 1;
		}
		individual tmp_sub_indi;
		path_scanning(&tmp_sub_indi, inst_tasks, serv_mark);

		//int fred_route[MAX_SOLUTION_LENGTH];
		//int tmp_cost = fred_heuristic(fred_route, div_groups[g].elements, div_groups[g].route_num, inst_tasks);

		total_cost += tmp_sub_indi.total_cost;
	}
	
	typedef struct single_move
	{
		int task;
		int orig_group;
		int targ_group;
		int total_cost;
	} move;

	move tmp_move, best_move;

	// Repeat updating
	int repeat = 1;
	while (repeat)
	{
		repeat = 0;
		// move one element from one group to another
		best_move.total_cost = INF;
		group best_div_groups[GROUP_NUM+1];

		for (int ti = 1; ti <= task_num; ti++) // for each task
		{
			if (!use[ti]) // task ti not used
				continue;

			tmp_move.task = ti;
			tmp_move.orig_group = group_ids[ti];
			for (int tg = 1; tg <= group_num; tg++) // for each group
			{
				if (tg == tmp_move.orig_group) // not moved
					continue;

				tmp_move.targ_group = tg;

				// initialize the tmp group information
				group tmp_div_groups[GROUP_NUM+1];
				memcpy(tmp_div_groups, div_groups, sizeof(tmp_div_groups));

				// update the group information
				int position[10];
				find_ele_positions(position, tmp_div_groups[tmp_move.orig_group].elements, tmp_move.task);
				delete_element(tmp_div_groups[tmp_move.orig_group].elements, position[1]);
				tmp_div_groups[tmp_move.orig_group].demand -= inst_tasks[tmp_move.task].demand;
				tmp_div_groups[tmp_move.orig_group].route_num = ceil((1.0*tmp_div_groups[tmp_move.orig_group].demand)/capacity);
				tmp_div_groups[tmp_move.targ_group].elements[0] ++;
				tmp_div_groups[tmp_move.targ_group].elements[tmp_div_groups[tmp_move.targ_group].elements[0]] = tmp_move.task;
				tmp_div_groups[tmp_move.targ_group].demand += inst_tasks[tmp_move.task].demand;
				tmp_div_groups[tmp_move.targ_group].route_num = ceil((1.0*tmp_div_groups[tmp_move.targ_group].demand)/capacity);

				// compute the tmp total cost
				double tmp_total_cost = 0;
				for (int g = 1; g <= group_num; g++)
				{
					int serv_mark[MAX_TASK_NUM];
					memset(serv_mark, 0, sizeof(serv_mark));
					serv_mark[0] = task_num;
					for (int i = 1; i <= tmp_div_groups[g].elements[0]; i++)
					{
						int tmp_task = tmp_div_groups[g].elements[i];
						serv_mark[tmp_task] = 1;
						serv_mark[inst_tasks[tmp_task].inverse] = 1;
					}
					individual tmp_sub_indi;
					path_scanning(&tmp_sub_indi, inst_tasks, serv_mark);

					//int fred_route[MAX_SOLUTION_LENGTH];
					//int tmp_cost = fred_heuristic(fred_route, tmp_div_groups[g].elements, tmp_div_groups[g].route_num, inst_tasks);

					tmp_total_cost += tmp_sub_indi.total_cost;
				}

				tmp_move.total_cost = tmp_total_cost;
				if (tmp_move.total_cost < best_move.total_cost)
				{
					best_move = tmp_move;
					memcpy(best_div_groups, tmp_div_groups, sizeof(tmp_div_groups));
				}
			}
		}

		if (best_move.total_cost < total_cost) // better clustering found
		{
			repeat = 1;
			// conduct the move
			group_ids[best_move.task] = best_move.targ_group;
			memcpy(div_groups, best_div_groups, sizeof(best_div_groups));
			total_cost = best_move.total_cost;
		}
	}

	// assign group ids for the unused tasks
	for (int i = 1; i <= task_num; i++)
	{
		if (!use[i])
			group_ids[i] = group_ids[inst_tasks[i].inverse];
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Change groups based on the random grouping of each route

void route_random_grouping(int *group_ids, int group_num, int *task_seq)
{
	typedef struct route_info
	{
		int tasks[MAX_ROUTE_LENGTH]; // the tasks in the route
		double membership[GROUP_NUM+1]; // the membership of each group;
	} route_info;

	// read route information from task_seq
	route_info this_route_info[MAX_ROUTE_NUM];
	int route_num = 0;
	for (int i = 1; i < task_seq[0]; i++)
	{
		if (task_seq[i] == 0)
		{
			route_num ++;
			this_route_info[route_num].tasks[0] = 0;
			continue;
		}

		this_route_info[route_num].tasks[0] ++;
		this_route_info[route_num].tasks[this_route_info[route_num].tasks[0]] = task_seq[i];
	}

	// set group sizes
	int group_size[GROUP_NUM+1];
	group_size[0] = group_num;
	int residual = route_num;
	for (int g = 1; g <= group_num; g++)
	{
		group_size[g] = (int)floor((1.0*route_num)/group_num);
		residual -= group_size[g];
	}
	for (int g = 1; g <= residual; g++)
	{
		group_size[g] ++;
	}

	// set route group ids
	int route_group_ids[MAX_ROUTE_NUM];
	route_group_ids[0] = route_num;
	
	int route_permutation[MAX_ROUTE_NUM];
	rand_perm(route_permutation, route_num); // random permutation of routes
	int curr_id = 1; // the current route group id
	int curr_ptr = 0; // scan pointer
	for (int g = 1; g <= group_num; g++)
	{
		for (int i = 1; i <= group_size[g]; i++)
		{
			curr_ptr ++;
			int curr_route = route_permutation[curr_ptr];
			route_group_ids[curr_route] = curr_id;
		}
		curr_id ++;
	}

	// decide the group ids of each task based on the route_group_ids
	for (int i = 1; i <= route_num; i++)
	{
		for (int j = 1; j <= this_route_info[i].tasks[0]; j++)
		{
			int tmp_task = this_route_info[i].tasks[j];
			group_ids[tmp_task] = route_group_ids[i];
			group_ids[inst_tasks[tmp_task].inverse] = route_group_ids[i];
		}
	}

	//// update group_ids based on route_group_ids
	//int curr_route = 0;
	//for (int i = 1; i < best_fsb_solution.sequence[0]; i++)
	//{
	//	int tmp_task = best_fsb_solution.sequence[i];
	//	if (tmp_task == 0)
	//	{
	//		curr_route ++;
	//		continue;
	//	}

	//	group_ids[tmp_task] = route_group_ids[curr_route];
	//	group_ids[inst_tasks[tmp_task].inverse] = route_group_ids[curr_route];
	//}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Change groups based on the membership of each route

void route_membership_grouping(int *group_ids, int group_num, int *task_seq)
{
	typedef struct route_info
	{
		int tasks[MAX_ROUTE_LENGTH]; // the tasks in the route
		double membership[GROUP_NUM+1]; // the membership of each group;
	} route_info;

	// read route information from task_seq
	route_info this_route_info[MAX_ROUTE_NUM];
	int route_num = 0;
	for (int i = 1; i < task_seq[0]; i++)
	{
		if (task_seq[i] == 0)
		{
			route_num ++;
			this_route_info[route_num].tasks[0] = 0;
			continue;
		}

		this_route_info[route_num].tasks[0] ++;
		this_route_info[route_num].tasks[this_route_info[route_num].tasks[0]] = task_seq[i];
	}

	for (int i = 1; i <= route_num; i++)
	{
		memset(this_route_info[i].membership, 0, sizeof(this_route_info[i].membership));
		this_route_info[i].membership[0] = group_num;
		for (int j = 1; j <= this_route_info[i].tasks[0]; j++)
		{
			int inc_group = group_ids[this_route_info[i].tasks[j]];
			this_route_info[i].membership[inc_group] ++;
		}

		for (int j = 1; j <= group_num; j++)
		{
			this_route_info[i].membership[j] /= this_route_info[i].tasks[0];
		}
	}

	int route_group_ids[MAX_ROUTE_NUM];
	route_group_ids[0] = group_num;
	// decide the group id of each route with roulette wheel of the membership
	for (int i = 1; i <= route_num; i++)
	{
		double r = (1.0*rand())/RAND_MAX;
		route_group_ids[i] = 1;
		while (r > this_route_info[i].membership[route_group_ids[i]])
		{
			r -= this_route_info[i].membership[route_group_ids[i]];
			route_group_ids[i] ++;

			if (route_group_ids[i] == group_num)
				break;
		}
	}

	// decide the group ids of each task based on the route_group_ids
	for (int i = 1; i <= route_num; i++)
	{
		for (int j = 1; j <= this_route_info[i].tasks[0]; j++)
		{
			int tmp_task = this_route_info[i].tasks[j];
			group_ids[tmp_task] = route_group_ids[i];
			group_ids[inst_tasks[tmp_task].inverse] = route_group_ids[i];
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Change groups based on the group distance matrix and combine the routes

void route_distance_grouping(int *group_ids, int group_num, int *task_seq, double (*dist_mtx)[MAX_TASK_NUM], double exp)
{
	int routes[MAX_ROUTE_NUM][MAX_ROUTE_LENGTH];
	// read the routes according to the task_seq
	routes[0][0] = 0;
	for (int i = 1; i < task_seq[0]; i++)
	{
		if (task_seq[i] == 0)
		{
			routes[0][0] ++;
			routes[routes[0][0]][0] = 0;
			continue;
		}

		routes[routes[0][0]][0] ++;
		routes[routes[0][0]][routes[routes[0][0]][0]] = task_seq[i];
	}

	// get the route distance matrix
	double route_dist_mtx[MAX_ROUTE_NUM][MAX_ROUTE_NUM];
	// compute the route distance matrix
	route_dist_mtx[0][0] = routes[0][0];
	for (int i = 1; i <= routes[0][0]; i++) // the first group
	{
		for (int j = 1; j <= routes[0][0]; j++) // the second group
		{
			route_dist_mtx[i][j] = 0;

			for (int k1 = 1; k1 <= routes[i][0]; k1++) // enumerate all the tasks in the first group
			{
				for (int k2 = 1; k2 <= routes[j][0]; k2++) // enumerate all the tasks in the second group
				{
					route_dist_mtx[i][j] += dist_mtx[routes[i][k1]][routes[j][k2]];
				}
			}

			// average by the number of distance components
			route_dist_mtx[i][j] /= (routes[i][0]*routes[j][0]);
		}
	}

	// normalize the route distance matrix
	double tmp_route_dist_mtx[MAX_ROUTE_NUM][MAX_ROUTE_NUM];
	memcpy(tmp_route_dist_mtx, route_dist_mtx, sizeof(tmp_route_dist_mtx));
	for (int i = 1; i <= routes[0][0]; i++) // the first group
	{
		for (int j = 1; j <= routes[0][0]; j++) // the second group
		{
			route_dist_mtx[i][j] = (tmp_route_dist_mtx[i][j]*tmp_route_dist_mtx[i][j])/(tmp_route_dist_mtx[i][i]*tmp_route_dist_mtx[j][j]);
		}
	}

	int route_group_ids[MAX_ROUTE_NUM];
	int route_medoids[GROUP_NUM+1];
	route_fuzzy_kmedoids(route_group_ids, route_medoids, route_dist_mtx, routes[0][0], group_num, exp);
	//route_kmedoids(route_group_ids, route_medoids, route_dist_mtx, routes[0][0], group_num);

	///////////////////////////////////////////////////////////////////////////////////////////////
	// output the route grouping results
	int route_group_members[GROUP_NUM+1][MAX_ROUTE_NUM];
	route_group_members[0][0] = routes[0][0];
	for (int g = 1; g <= group_num; g++)
	{
		route_group_members[g][0] = 0;
	}
	for (int i = 1; i <= route_group_ids[0]; i++)
	{
		int togroup = route_group_ids[i];
		route_group_members[togroup][0] ++;
		route_group_members[togroup][route_group_members[togroup][0]] = i;
	}
	FILE *fp = fopen("route_grouping_res.dat", "w");
	for (int g1 = 1; g1 <= group_num; g1++)
	{
		for (int i1 = 1; i1 <= route_group_members[g1][0]; i1++)
		{
			int id1 = route_group_members[g1][i1];
			for (int g2 = 1; g2 <= group_num; g2++)
			{
				for (int i2 = 1; i2 <= route_group_members[g2][0]; i2++)
				{
					int id2 = route_group_members[g2][i2];
					fprintf(fp, "%f\t", route_dist_mtx[id1][id2]);
				}
			}
			fprintf(fp, "\n");
		}
	}
	fclose(fp);
	//////////////////////////////////////////////////////////////////////////////////////////////

	// decide the group ids of each task based on the route_group_ids
	for (int i = 1; i <= routes[0][0]; i++)
	{
		for (int j = 1; j <= routes[i][0]; j++)
		{
			int tmp_task = routes[i][j];
			group_ids[tmp_task] = route_group_ids[i];
			group_ids[inst_tasks[tmp_task].inverse] = route_group_ids[i];
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Divide the routes into k groups of routes according to the route distance matrix using k-medoids method

void route_kmedoids(int *route_group_ids, int *route_medoids, double (*route_dist_mtx)[MAX_ROUTE_NUM], int route_num, int group_num)
{
	//// initialize the group id of each route
	//int ismedoid[MAX_ROUTE_NUM];
	//memset(ismedoid, 0, (route_num+1)*sizeof(int));
	//route_medoids[0] = group_num;
	//ismedoid[0] = route_num;
	//route_group_ids[0] = route_num;
	//
	//// get a random permutation from 1 to route_num
	//int rp_vec[MAX_ROUTE_NUM];
	//rand_perm(rp_vec, route_num);

	//// select route_medoids randomly
	//for (int g = 1; g <= group_num; g++)
	//{
	//	route_medoids[g] = rp_vec[g];
	//	ismedoid[route_medoids[g]] = 1;
	//	route_group_ids[route_medoids[g]] = g;
	//}

	// Initialize the group id of each element
	// (1) 1:group_num appear at least once
	// (2) route_medoids are distributed as diversely as possible
	int ismedoid[MAX_ROUTE_NUM];
	memset(ismedoid, 0, (route_num+1)*sizeof(int));
	ismedoid[0] = route_num;

	route_group_ids[0] = route_num;
	route_medoids[0] = group_num;
	// for the first group
	double max_avg_dist = 0;
	for (int i = 1; i <= route_num; i++)
	{
		int tmp_num = 0;
		double tmp_avg_dist = 0;
		for (int j = 1; j <= route_num; j++)
		{
			tmp_avg_dist += route_dist_mtx[i][j];
			tmp_num ++;
		}
		tmp_avg_dist /= tmp_num;

		if (tmp_avg_dist > max_avg_dist)
		{
			max_avg_dist = tmp_avg_dist;
			route_medoids[1] = i;
		}
	}
	ismedoid[route_medoids[1]] = 1;

	// for the remaining groups
	for (int g = 2; g <= group_num; g++) // group g
	{
		max_avg_dist = 0;
		for (int i = 1; i <= route_num; i++)
		{
			if (ismedoid[i]) // is already a medoid
				continue;
			
			double tmp_avg_dist = 0;
			for (int c = 1; c < g; c++) // compute avg dist to all the existing route_medoids
			{
				tmp_avg_dist += route_dist_mtx[i][route_medoids[c]];
			}
			tmp_avg_dist /= g-1;

			if (tmp_avg_dist > max_avg_dist)
			{
				max_avg_dist = tmp_avg_dist;
				route_medoids[g] = i;
			}
		}
		ismedoid[route_medoids[g]] = 1;
	}

	// assign group ids for the route_medoids
	for (int c = 1; c <= group_num; c++)
	{
		route_group_ids[route_medoids[c]] = c;
	}



	// assign group ids according to route_medoids
	for (int i = 1; i <= route_num; i++)
	{
		if (ismedoid[i]) // is already a medoid
			continue;

		double min_med_dist = INF; // minimal dist to the route_medoids
		for (int g = 1; g <= group_num; g++)
		{
			double tmp_med_dist = route_dist_mtx[i][route_medoids[g]];

			if (tmp_med_dist < min_med_dist)
			{
				min_med_dist = tmp_med_dist;
				route_group_ids[i] = g;
			}
		}
	}

	// compute the current total cost
	int total_cost = 0;
	for (int i = 1; i <= route_num; i++)
	{
		if (ismedoid[i]) // is already a medoid
			continue;

		total_cost += route_dist_mtx[i][route_medoids[route_group_ids[i]]];
	}

	// Repeat updating
	int repeat = 1;
	while (repeat)
	{
		repeat = 0;

		// tmp route_medoids, tmp group ids and tmp total cost
		int best_medoids[GROUP_NUM+1];
		memcpy(best_medoids, route_medoids, (GROUP_NUM+1)*sizeof(int));
		int best_ismedoid[MAX_ROUTE_NUM];
		memcpy(best_ismedoid, ismedoid, MAX_ROUTE_NUM*sizeof(int));
		int best_group_ids[MAX_ROUTE_NUM];
		memcpy(best_group_ids, route_group_ids, MAX_ROUTE_NUM*sizeof(int));
		int best_total_cost = total_cost;

		for (int tg = 1; tg <= group_num; tg++) // for each medoid
		{
			for (int ti = 1; ti <= route_num; ti++) // for each non-medoid points
			{
				if (ismedoid[ti]) // is already a medoid
					continue;

				// swap i and route_medoids[g]
				int tmp_medoids[GROUP_NUM+1];
				memcpy(tmp_medoids, route_medoids, (GROUP_NUM+1)*sizeof(int));
				int tmp_ismedoid[MAX_ROUTE_NUM];
				memcpy(tmp_ismedoid, ismedoid, MAX_ROUTE_NUM*sizeof(int));

				tmp_ismedoid[route_medoids[tg]] = 0;
				tmp_ismedoid[ti] = 1;
				tmp_medoids[tg] = ti;

				// assign tmp group ids according to tmp route_medoids
				int tmp_group_ids[MAX_ROUTE_NUM];
				tmp_group_ids[0] = route_num;
				for (int g = 1; g <= group_num; g++)
				{
					tmp_group_ids[tmp_medoids[g]] = g;
				}

				for (int i = 1; i <= route_num; i++)
				{
					if (tmp_ismedoid[i]) // is already a medoid
						continue;

					double min_med_dist = INF; // minimal dist to the route_medoids
					for (int g = 1; g <= group_num; g++)
					{
						double tmp_med_dist = route_dist_mtx[i][tmp_medoids[g]];

						if (tmp_med_dist < min_med_dist)
						{
							min_med_dist = tmp_med_dist;
							tmp_group_ids[i] = g;
						}
					}
				}

				// compute tmp total cost
				int tmp_total_cost = 0;
				for (int i = 1; i <= route_num; i++)
				{
					if (tmp_ismedoid[i]) // is already a medoid
						continue;

					tmp_total_cost += route_dist_mtx[i][tmp_medoids[tmp_group_ids[i]]];
				}

				if (tmp_total_cost < best_total_cost)
				{
					memcpy(best_medoids, tmp_medoids, (GROUP_NUM+1)*sizeof(int));
					memcpy(best_ismedoid, tmp_ismedoid, MAX_ROUTE_NUM*sizeof(int));
					memcpy(best_group_ids, tmp_group_ids, MAX_ROUTE_NUM*sizeof(int));
					best_total_cost = tmp_total_cost;
				}
			}
		}

		if (best_total_cost < total_cost) // better clustering found
		{
			repeat = 1;
			memcpy(route_medoids, best_medoids, (GROUP_NUM+1)*sizeof(int));
			memcpy(ismedoid, best_ismedoid, MAX_ROUTE_NUM*sizeof(int));
			memcpy(route_group_ids, best_group_ids, MAX_ROUTE_NUM*sizeof(int));
			total_cost = best_total_cost;
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Divide the routes into k groups of routes according to the route distance matrix using k-medoids method

void route_fuzzy_kmedoids(int *route_group_ids, int *route_medoids, double (*route_dist_mtx)[MAX_ROUTE_NUM], int route_num, int group_num, double exp)
{
	// initialize the group id of each route randomly
	int ismedoid[MAX_ROUTE_NUM];
	memset(ismedoid, 0, (route_num+1)*sizeof(int));
	route_medoids[0] = group_num;
	ismedoid[0] = route_num;
	route_group_ids[0] = route_num;
	
	// get a random permutation from 1 to route_num
	int rp_vec[MAX_ROUTE_NUM];
	rand_perm(rp_vec, route_num);

	// select route_medoids randomly
	for (int g = 1; g <= group_num; g++)
	{
		route_medoids[g] = rp_vec[g];
		ismedoid[route_medoids[g]] = 1;
		route_group_ids[route_medoids[g]] = g;
	}

	//// Initialize the group id of each element
	//// (1) 1:group_num appear at least once
	//// (2) route_medoids are distributed as diversely as possible
	//int ismedoid[MAX_ROUTE_NUM];
	//memset(ismedoid, 0, (route_num+1)*sizeof(int));
	//ismedoid[0] = route_num;

	//route_group_ids[0] = route_num;
	//route_medoids[0] = group_num;
	//// for the first group
	//double max_avg_dist = 0;
	//for (int i = 1; i <= route_num; i++)
	//{
	//	int tmp_num = 0;
	//	double tmp_avg_dist = 0;
	//	for (int j = 1; j <= route_num; j++)
	//	{
	//		tmp_avg_dist += route_dist_mtx[i][j];
	//		tmp_num ++;
	//	}
	//	tmp_avg_dist /= tmp_num;

	//	if (tmp_avg_dist > max_avg_dist)
	//	{
	//		max_avg_dist = tmp_avg_dist;
	//		route_medoids[1] = i;
	//	}
	//}
	//ismedoid[route_medoids[1]] = 1;

	//// for the remaining groups
	//for (int g = 2; g <= group_num; g++) // group g
	//{
	//	max_avg_dist = 0;
	//	for (int i = 1; i <= route_num; i++)
	//	{
	//		if (ismedoid[i]) // is already a medoid
	//			continue;
	//		
	//		double tmp_avg_dist = 0;
	//		for (int c = 1; c < g; c++) // compute avg dist to all the existing route_medoids
	//		{
	//			tmp_avg_dist += route_dist_mtx[i][route_medoids[c]];
	//		}
	//		tmp_avg_dist /= g-1;

	//		if (tmp_avg_dist > max_avg_dist)
	//		{
	//			max_avg_dist = tmp_avg_dist;
	//			route_medoids[g] = i;
	//		}
	//	}
	//	ismedoid[route_medoids[g]] = 1;
	//}

	//// assign group ids for the route_medoids
	//for (int c = 1; c <= group_num; c++)
	//{
	//	route_group_ids[route_medoids[c]] = c;
	//}



	// compute the membership of each other routes to the medoids
	typedef struct assign
	{
		int ele;
		double med_dist[GROUP_NUM+1];
		double prob[GROUP_NUM+1];
	} assign;

	assign cand_assign[MAX_ROUTE_NUM];
	int cand_assign_num = 0;
	for (int i = 1; i <= route_num; i++)
	{
		if (ismedoid[i]) // is already a medoid
			continue;

		cand_assign_num ++;
		cand_assign[cand_assign_num].ele = i;
		cand_assign[cand_assign_num].med_dist[0] = group_num;
		for (int g = 1; g <= group_num; g++)
		{
			cand_assign[cand_assign_num].med_dist[g] = route_dist_mtx[i][route_medoids[g]];
		}
		
		double norm_factor = 0;
		for (int g = 1; g <= group_num; g++)
		{
			norm_factor += 1.0/pow(cand_assign[cand_assign_num].med_dist[g], exp);
		}
		for (int g = 1; g <= group_num; g++)
		{
			cand_assign[cand_assign_num].prob[g] = (1.0/pow(cand_assign[cand_assign_num].med_dist[g], exp))/norm_factor;
		}
	}

	// compute the current total cost according to the membership and dist to the medoids
	double total_cost = 0;
	for (int i = 1; i <= cand_assign_num; i++)
	{
		for (int g = 1; g <= group_num; g++)
		{
			total_cost += cand_assign[i].prob[g]*cand_assign[i].med_dist[g];
		}
	}

	// Repeat updating
	int repeat = 1;
	while (repeat)
	{
		repeat = 0;

		// tmp route_medoids, tmp group ids and tmp total cost
		int best_medoids[GROUP_NUM+1];
		memcpy(best_medoids, route_medoids, (GROUP_NUM+1)*sizeof(int));
		int best_ismedoid[MAX_ROUTE_NUM];
		memcpy(best_ismedoid, ismedoid, MAX_ROUTE_NUM*sizeof(int));
		int best_group_ids[MAX_ROUTE_NUM];
		memcpy(best_group_ids, route_group_ids, MAX_ROUTE_NUM*sizeof(int));
		double best_total_cost = total_cost;

		for (int tg = 1; tg <= group_num; tg++) // for each medoid
		{
			for (int ti = 1; ti <= route_num; ti++) // for each non-medoid points
			{
				if (ismedoid[ti]) // is already a medoid
					continue;

				// swap i and route_medoids[g]
				int tmp_medoids[GROUP_NUM+1];
				memcpy(tmp_medoids, route_medoids, (GROUP_NUM+1)*sizeof(int));
				int tmp_ismedoid[MAX_ROUTE_NUM];
				memcpy(tmp_ismedoid, ismedoid, MAX_ROUTE_NUM*sizeof(int));

				tmp_ismedoid[route_medoids[tg]] = 0;
				tmp_ismedoid[ti] = 1;
				tmp_medoids[tg] = ti;

				// assign tmp group ids according to tmp route_medoids
				int tmp_group_ids[MAX_ROUTE_NUM];
				tmp_group_ids[0] = route_num;
				for (int g = 1; g <= group_num; g++)
				{
					tmp_group_ids[tmp_medoids[g]] = g;
				}

				int cand_assign_num = 0;
				for (int i = 1; i <= route_num; i++)
				{
					if (tmp_ismedoid[i]) // is already a medoid
						continue;

					cand_assign_num ++;
					cand_assign[cand_assign_num].ele = i;
					cand_assign[cand_assign_num].med_dist[0] = group_num;
					for (int g = 1; g <= group_num; g++)
					{
						cand_assign[cand_assign_num].med_dist[g] = route_dist_mtx[i][tmp_medoids[g]];
					}
					double norm_factor = 0;
					for (int g = 1; g <= group_num; g++)
					{
						norm_factor += 1.0/pow(cand_assign[cand_assign_num].med_dist[g], exp);
					}
					for (int g = 1; g <= group_num; g++)
					{
						cand_assign[cand_assign_num].prob[g] = (1.0/pow(cand_assign[cand_assign_num].med_dist[g], exp))/norm_factor;
					}
				}

				// compute the current total cost according to the membership and dist to the tmp_medoids
				double tmp_total_cost = 0;
				for (int i = 1; i <= cand_assign_num; i++)
				{
					for (int g = 1; g <= group_num; g++)
					{
						tmp_total_cost += cand_assign[i].prob[g]*cand_assign[i].med_dist[g];
					}
				}

				if (tmp_total_cost < best_total_cost)
				{
					memcpy(best_medoids, tmp_medoids, (GROUP_NUM+1)*sizeof(int));
					memcpy(best_ismedoid, tmp_ismedoid, MAX_ROUTE_NUM*sizeof(int));
					memcpy(best_group_ids, tmp_group_ids, MAX_ROUTE_NUM*sizeof(int));
					best_total_cost = tmp_total_cost;
				}
			}
		}

		if (best_total_cost < total_cost) // better clustering found
		{
			repeat = 1;
			memcpy(route_medoids, best_medoids, (GROUP_NUM+1)*sizeof(int));
			memcpy(ismedoid, best_ismedoid, MAX_ROUTE_NUM*sizeof(int));
			memcpy(route_group_ids, best_group_ids, MAX_ROUTE_NUM*sizeof(int));
			total_cost = best_total_cost;
		}
	}

	// compute the membership based on the final medoids
	cand_assign_num = 0;
	for (int i = 1; i <= route_num; i++)
	{
		if (ismedoid[i]) // is already a medoid
			continue;

		cand_assign_num ++;
		cand_assign[cand_assign_num].ele = i;
		cand_assign[cand_assign_num].med_dist[0] = group_num;
		for (int g = 1; g <= group_num; g++)
		{
			cand_assign[cand_assign_num].med_dist[g] = route_dist_mtx[i][route_medoids[g]];
		}
		double norm_factor = 0;
		for (int g = 1; g <= group_num; g++)
		{
			norm_factor += 1.0/pow(cand_assign[cand_assign_num].med_dist[g], exp);
		}
		for (int g = 1; g <= group_num; g++)
		{
			cand_assign[cand_assign_num].prob[g] = (1.0/pow(cand_assign[cand_assign_num].med_dist[g], exp))/norm_factor;
		}
	}

	// assign the group ids based on the memberships
	for (int i = 1; i <= cand_assign_num; i++)
	{
		int ele = cand_assign[i].ele;
		double r = (1.0*rand())/RAND_MAX;
		route_group_ids[ele] = 1;
		while (r > cand_assign[i].prob[route_group_ids[ele]])
		{
			r -= cand_assign[i].prob[route_group_ids[ele]];
			route_group_ids[ele] ++;

			if (route_group_ids[ele] == group_num)
				break;
		}

		printf("%d in group %d, prob = %f\n", ele, route_group_ids[ele], cand_assign[i].prob[route_group_ids[ele]]);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Divide the population to sub-populations according to the group ids and current id

void pop2subpop(population *subpop, population *pop, int *group_ids, int subpop_id, const task *inst_tasks)
{
	subpop->popsize = pop->popsize;
	for (int p = 0; p < subpop->popsize; p++)
	{
		indi_copy(&subpop->indi[p], &pop->indi[p]);
	}
	
	for (int p = 0; p < subpop->popsize; p++)
	{
		// for the pth individual
		for (int i = subpop->indi[p].sequence[0]; i > 0; i--)
		{
			if (subpop->indi[p].sequence[i] == 0)
				continue;

			if (group_ids[subpop->indi[p].sequence[i]] != subpop_id) // not in the current group, delete
				delete_element(subpop->indi[p].sequence, i);
		}

		// update the new information based on the new sequence
		get_route_load(subpop->indi[p].route_load, subpop->indi[p].sequence, inst_tasks);
		subpop->indi[p].total_vio_load = get_total_vio_load(subpop->indi[p].route_load);
		subpop->indi[p].total_cost = get_task_seq_total_cost(subpop->indi[p].sequence, inst_tasks);

		// remove empty routes
		for (int i = subpop->indi[p].sequence[0]; i > 1; i--)
		{
			if (subpop->indi[p].sequence[i] == 0 && subpop->indi[p].sequence[i-1] == 0) // empty route with consecutive depot
				delete_element(subpop->indi[p].sequence, i);
		}
		for (int i = subpop->indi[p].route_load[0]; i > 0; i--)
		{
			if (subpop->indi[p].route_load[i] == 0) // empty route with zero load
				delete_element(subpop->indi[p].route_load, i);
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Divide the individual to sub-individual according to the group ids and current id

void indi2subindi(individual *indi, individual *subindi, int *group_ids, int subpop_id, const task *inst_tasks)
{
	indi_copy(subindi, indi);
	for (int i = subindi->sequence[0]; i > 0; i--)
	{
		if (subindi->sequence[i] == 0)
			continue;

		if (group_ids[subindi->sequence[i]] != subpop_id) // not in the current group, delete
			delete_element(subindi->sequence, i);
	}

	// update the new information based on the new sequence
	get_route_load(subindi->route_load, subindi->sequence, inst_tasks);
	subindi->total_vio_load = get_total_vio_load(subindi->route_load);
	subindi->total_cost = get_task_seq_total_cost(subindi->sequence, inst_tasks);

	// remove empty routes
	for (int i = subindi->sequence[0]; i > 1; i--)
	{
		if (subindi->sequence[i] == 0 && subindi->sequence[i-1] == 0) // empty route with consecutive depot
			delete_element(subindi->sequence, i);
	}
	for (int i = subindi->route_load[0]; i > 0; i--)
	{
		if (subindi->route_load[i] == 0) // empty route with zero load
			delete_element(subindi->route_load, i);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Combine all the sub-populations to the population

void subpop2pop(population *pop, population *subpop, const task *inst_tasks)
{
	for (int p = 0; p < pop->popsize; p++)
	{
		// combine the pth individuals together
		for (int g = 1; g <= GROUP_NUM; g++)
		{
			pop->indi[p].sequence[0] = 1;
			pop->indi[p].route_load[0] = 0;
			pop->indi[p].total_cost = 0;
			for (int g = 1; g <= GROUP_NUM; g++)
			{
				pop->indi[p].sequence[0] --;
				link_array(pop->indi[p].sequence, subpop[g-1].indi[p].sequence);
				link_array(pop->indi[p].route_load, subpop[g-1].indi[p].route_load);
				pop->indi[p].total_cost += subpop[g-1].indi[p].total_cost;
			}
		}
	}
}