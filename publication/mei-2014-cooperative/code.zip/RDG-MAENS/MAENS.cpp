// Edited in 29/08/2012 by Yi Mei

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "functions.h"

void MAENS(individual *output_indi, int *sub_tasks, const task *inst_tasks)
{

	/* initialization */

	MAENS_initialization(output_indi, &pop1, sub_tasks, inst_tasks);
	//MAENS_initialization(output_indi, pop, popsize, sub_tasks, inst_tasks);

	/* searching phase */

	int ite = 0, wite = 0;

	while (ite < MAX_GEN)
	{
		//for (int i = 0; i < popsize; i++)
		//{
		//	printf("%d ", pop[i].total_cost);
		//}
		//printf("\n");
		ite ++;
		wite ++;

		//if (ite%25 == 0)
		//{
		//	printf("ite = %d, best cost = %d\n", ite, output_indi->total_cost);
		//}

		MAENS_loop(output_indi, &pop1, wite, inst_tasks);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//void MAENS_initialization(individual *output_indi, individual *pop, int &popsize, int *sub_tasks, const task *inst_tasks)
//{
//	output_indi->total_cost = INF; // the best feasible solution obtained by MAENS on the sub-problem
//
//	int used;
//
//	int tmp_popsize = 0;
//	while (tmp_popsize < popsize)
//	{
//		int trial = 0;
//		individual init_indi;
//		while (trial < MAX_TRIAL)
//		{
//			trial ++;
//			int serve_mark[MAX_TASK_NUM];
//			memset(serve_mark, 0, sizeof(serve_mark));
//			serve_mark[0] = task_num;
//			for (int i = 1; i <= sub_tasks[0]; i++)
//			{
//				serve_mark[sub_tasks[i]] = 1; // only serve the tasks in sub_tasks
//			}
//
//			//path_scanning(&init_indi, inst_tasks, serve_mark);
//			rand_scanning(&init_indi, inst_tasks, serve_mark);
//
//			used = 0;
//			for (int i = 0; i < tmp_popsize; i++)
//			{
//				if (init_indi.total_cost == pop[i].total_cost && init_indi.total_vio_load == pop[i].total_vio_load)
//				{
//					used = 1;
//					break;
//				}
//			}
//
//			if (!used)
//				break;
//		}
//
//		if (trial == MAX_TRIAL && used)
//			break;
//
//		indi_copy(&pop[tmp_popsize], &init_indi);
//		tmp_popsize ++;			
//
//		if (init_indi.total_vio_load == 0 && init_indi.total_cost < output_indi->total_cost)
//		{
//			indi_copy(output_indi, &init_indi);
//		}
//	}
//	popsize = tmp_popsize;
//}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void MAENS_initialization(individual *output_indi, population *pop, int *sub_tasks, const task *inst_tasks)
{
	output_indi->total_cost = INF; // the best feasible solution obtained by MAENS on the sub-problem

	int used;

	pop->popsize = MAX_POPSIZE;
	int tmp_popsize = 0;
	while (tmp_popsize < pop->popsize)
	{
		int trial = 0;
		individual init_indi;
		while (trial < MAX_TRIAL)
		{
			trial ++;
			int serve_mark[MAX_TASK_NUM];
			memset(serve_mark, 0, sizeof(serve_mark));
			serve_mark[0] = task_num;
			for (int i = 1; i <= sub_tasks[0]; i++)
			{
				serve_mark[sub_tasks[i]] = 1; // only serve the tasks in sub_tasks
			}

			//path_scanning(&init_indi, inst_tasks, serve_mark);
			rand_scanning(&init_indi, inst_tasks, serve_mark);

			used = 0;
			for (int i = 0; i < tmp_popsize; i++)
			{
				if (init_indi.total_cost == pop->indi[i].total_cost && init_indi.total_vio_load == pop->indi[i].total_vio_load)
				{
					used = 1;
					break;
				}
			}

			if (!used)
				break;
		}

		if (trial == MAX_TRIAL && used)
			break;

		indi_copy(&pop->indi[tmp_popsize], &init_indi);
		tmp_popsize ++;			

		if (init_indi.total_vio_load == 0 && init_indi.total_cost < output_indi->total_cost)
		{
			indi_copy(output_indi, &init_indi);
		}
	}
	pop->popsize = tmp_popsize;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void MAENS_loop(individual *output_indi, population *pop, int &wite, const task *inst_tasks)
{
	int offsize = 6*pop->popsize; // the number of the generated offsprings
	int totalsize = pop->popsize+offsize; // the number of the sum of the current population and the offsprings

	individual parent1, parent2, xed_child, mted_child, child;

	int ptr = pop->popsize;
	int trial = 0;
	while (ptr < totalsize)
	{
		trial ++;
		if (trial > MAX_OFFSPRING_TRIAL)
			break;

		child.total_cost = 0; // child does not exist

		int par_id1, par_id2;
		//tour_selection(par_id1, par_id2, pop); // parent selection
		rand_selection(par_id1, par_id2, pop);
		indi_copy(&parent1, &pop->indi[par_id1]);
		indi_copy(&parent2, &pop->indi[par_id2]);

		SBX(&xed_child, &parent1, &parent2, inst_tasks); // crossover

		if (xed_child.total_vio_load == 0 && xed_child.total_cost < output_indi->total_cost)
		{
			indi_copy(output_indi, &xed_child);
			wite = 0;

			printf("new tc = %d\n", output_indi->total_cost);

			//fp = fopen(output_file, "a");

			//fprintf(fp, "crossover of ite = %d\n", ite);
			//fprintf(fp, "sequence\n");
			//for (int i = 1; i <= output_indi->sequence[0]; i++)
			//{
			//	fprintf(fp, "%d  ", output_indi->sequence[i]);
			//}
			//fprintf(fp, "\ntotal_cost = %d\n\n", output_indi->total_cost);

			//fclose(fp);
		}

		int used = 0;
		for (int i = 0; i < ptr; i++)
		{
			if (i == par_id1 || i == par_id2)
				continue;

			if (xed_child.total_cost == pop->indi[i].total_cost && xed_child.total_vio_load == pop->indi[i].total_vio_load)
			{
				used = 1;
				break;
			}
		}

		if (!used)
		{
			indi_copy(&child, &xed_child);
		}

		/* mutation with probability MUTATION_PROB */

		double random = 1.0*rand()/RAND_MAX;
		if (random < MUTATION_PROB)
		{
			/*
			int tmp_tc = output_indi->total_cost;
			*/
			lns_mut(&mted_child, &xed_child, output_indi, inst_tasks);

			//if (mted_child.total_vio_load == 0 && mted_child.total_cost < output_indi->total_cost)
			//{
			//	indi_copy(output_indi, &mted_child);
			//	printf("new tc = %d\n", output_indi->total_cost);
			//}
			/*
			if (output_indi->total_cost < tmp_tc)
			{
			wite = 0;

			fp = fopen(output_file, "a");

			fprintf(fp, "local search of ite = %d\n", ite);
			fprintf(fp, "sequence\n");
			for (int i = 1; i <= output_indi->sequence[0]; i++)
			{
			fprintf(fp, "%d  ", output_indi->sequence[i]);
			}
			fprintf(fp, "\ntotal_cost = %d\n\n", output_indi->total_cost);

			fclose(fp);
			}
			*/
			used = 0;
			for (int i = 0; i < ptr; i++)
			{
				if (i == par_id1 || i == par_id2)
					continue;

				if (mted_child.total_cost == pop->indi[i].total_cost && mted_child.total_vio_load == pop->indi[i].total_vio_load)
				{
					used = 1;
					break;
				}
			}

			if (!used)
			{
				indi_copy(&child, &mted_child);
			}
		}

		if (child.total_cost == parent1.total_cost && child.total_vio_load == parent1.total_vio_load)
		{
			indi_copy(&pop->indi[par_id1], &child);
		}
		else if (child.total_cost == parent2.total_cost && child.total_vio_load == parent2.total_vio_load)
		{
			indi_copy(&pop->indi[par_id2], &child);
		}
		else if (child.total_cost > 0)
		{
			indi_copy(&pop->indi[ptr], &child);
			ptr ++;
		}
	}

	if (ptr < totalsize)
		totalsize = ptr;

	// stochastic ranking

	double Pf = 0.45;
	individual tmp_indi;

	//for (int i = 0; i < totalsize; i++)
	for (int i = totalsize-1; i >= 0; i--)
	{
		for (int j = 0; j < totalsize-1; j++)
		{
			double random = 1.0*rand()/RAND_MAX;
			if ((pop->indi[j].total_vio_load == 0 && pop->indi[j+1].total_vio_load == 0) || random < Pf)
			{
				if (pop->indi[j].total_cost > pop->indi[j+1].total_cost)
				{
					indi_copy(&tmp_indi, &pop->indi[j]);
					indi_copy(&pop->indi[j], &pop->indi[j+1]);
					indi_copy(&pop->indi[j+1], &tmp_indi);
				}
			}
			else
			{
				if (pop->indi[j].total_vio_load > pop->indi[j+1].total_vio_load)
				{
					indi_copy(&tmp_indi, &pop->indi[j]);
					indi_copy(&pop->indi[j], &pop->indi[j+1]);
					indi_copy(&pop->indi[j+1], &tmp_indi);
				}
			}
		}
	}
}
