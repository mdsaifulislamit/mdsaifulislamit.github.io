/* The Route Distance Grouping (RDG) MAENS for LSCARP */

The source codes include the following files:

main.cpp
MAENS.cpp
preprocessing.cpp
initialization.cpp
searchoperators.cpp
arrayoperations.cpp
decompositions.cpp
functions.h

The input instances can be downloaded from "CARP Benchmark Sets" of the following website:
http://goanna.cs.rmit.edu.au/~e04499/

For each instance, the output files will be placed in the directory with the same name as the instance.