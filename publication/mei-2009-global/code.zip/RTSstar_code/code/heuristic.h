struct BlossomInMatch
{
	int PNode;
	int BNode;
	int Route[50];
	int NodeSet[50];
};

struct Task;

extern int NO_Vertices;
extern int NO_ReqEdge;
extern int NO_ReqArc;

void FredericksonHeuristic(int *FHRoute, int *Route, const struct Task *ARPTask, int (*MinCost)[141], int NO_Task);

void GetConnectivePiece(int Root, int CurrentPiece, int *PieceMark, int (*Neighbors)[250]);

void GetMinCostTree(int (*CPMCTree)[141], int (*CPMinCost)[141]);

void GetEulerRoute(int *EulerRoute, int (*AdMatrix)[250], int *Nodes);

void FindCircuit(int *EulerRoute, int CurrentNode, int (*AdMatrix)[250], int *Nodes);

int SwitchDecimal(int *Binary);

void SwitchBinary(int *Binary, int Decimal);

void EvenAllOddNodes(int (*AdMatrix)[250], int *OddNodes, int (*MinCost)[141]);
