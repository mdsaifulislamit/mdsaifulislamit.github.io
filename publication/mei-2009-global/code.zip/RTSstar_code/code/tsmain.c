
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include "arrayoperations.h"
#include "initialization.h"
#include "sidiswap.h"
#include "heuristic.h"

#define INF 2100000000

int NO_Vertices;
int NO_ReqEdge;
int NO_ReqArc;
int NO_Tasks;
int NO_NonReqEdge;
int NO_NonReqArc;
int NO_Arcs;
int NO_Vehicles;
int Capacity;

int DEPOT;

int Cost[141][141];
int ServCostMatr[141][141];
int ShortestPath[141][141][141];
int MinCost[141][141];

int val[60000];
int val1[60000];
int rep[60000];
int FitCost[40000][3];
int TotalFitEval;
int FitEval;

struct Task ARPTask[1001];
struct Arc ARPArc[1001];

char DummyString[50];

char InputFile[100] = "instance/example.dat"; // the instance can be changed here
int LowerBound = 3548; // the lower bound of the instance can be set here

int main(void)
{
	int i, j, k, m;

	/* input and preprocessing */

	FILE *fp;

	NO_ReqArc = 0;
	NO_NonReqArc = 0;

	fp = fopen(InputFile, "r");

	while (1)
	{
		fscanf(fp, "%s", DummyString); // get the instance name
		//printf("DummyString = %s\n", DummyString);

		if (strcmp(DummyString, "VERTICES") == 0)
		{
			fscanf(fp, "%s", DummyString);
			fscanf(fp, "%d", &NO_Vertices);
		}
		else if (strcmp(DummyString, "ARISTAS_REQ") == 0)
		{
			fscanf(fp, "%s", DummyString);
			fscanf(fp, "%d", &NO_ReqEdge);
		}
		else if (strcmp(DummyString, "ARISTAS_NOREQ") == 0)
		{
			fscanf(fp, "%s", DummyString);
			fscanf(fp, "%d", &NO_NonReqEdge);
		}
		else if (strcmp(DummyString, "VEHICULOS") == 0)
		{
			fscanf(fp, "%s", DummyString);
			fscanf(fp, "%d", &NO_Vehicles);
		}
		else if (strcmp(DummyString, "CAPACIDAD") == 0)
		{
			fscanf(fp, "%s", DummyString);
			fscanf(fp, "%d", &Capacity);
		}
		else if (strcmp(DummyString, "LISTA_ARISTAS_REQ") == 0)
		{
			NO_Tasks = 2*NO_ReqEdge+NO_ReqArc;
			NO_Arcs = NO_Tasks+2*NO_NonReqEdge;

			fscanf(fp, "%s", DummyString);

			for (i = 1; i <= NO_ReqEdge; i++)
			{
				fscanf(fp, "%s", DummyString); // get the left parenthesis "("
				fscanf(fp, "%d,", &ARPTask[i].Tail);
				fscanf(fp, "%d)", &ARPTask[i].Head);
				fscanf(fp, "%s", DummyString); // get the right parenthesis ")" and the string "coste"
				fscanf(fp, "%d", &ARPTask[i].ServCost);
				fscanf(fp, "%s", DummyString); // get the string "demanda"
				fscanf(fp, "%d", &ARPTask[i].Demand);
				ARPTask[i].DeadCost = ARPTask[i].ServCost;
				ARPTask[i].Inv = i+NO_ReqEdge;

				ARPTask[i+NO_ReqEdge].Head = ARPTask[i].Tail;
				ARPTask[i+NO_ReqEdge].Tail = ARPTask[i].Head;
				ARPTask[i+NO_ReqEdge].DeadCost = ARPTask[i].DeadCost;
				ARPTask[i+NO_ReqEdge].ServCost = ARPTask[i].ServCost;
				ARPTask[i+NO_ReqEdge].Demand = ARPTask[i].Demand;
				ARPTask[i+NO_ReqEdge].Inv = i;

				ARPArc[i].Head = ARPTask[i].Head;
				ARPArc[i].Tail = ARPTask[i].Tail;
				ARPArc[i].TravCost = ARPTask[i].DeadCost;
				ARPArc[i+NO_ReqEdge].Head = ARPArc[i].Tail;
				ARPArc[i+NO_ReqEdge].Tail = ARPArc[i].Head;
				ARPArc[i+NO_ReqEdge].TravCost = ARPArc[i].TravCost;
			}
		}
		else if (strcmp(DummyString, "LISTA_ARISTAS_NOREQ") == 0)
		{
			fscanf(fp, "%s", DummyString);

			for (i = NO_Tasks+1; i <= NO_Tasks+NO_NonReqEdge; i++)
			{
				fscanf(fp, "%s", DummyString); // get the left parenthesis "("
				fscanf(fp, "%d,", &ARPArc[i].Tail);
				fscanf(fp, "%d)", &ARPArc[i].Head);
				fscanf(fp, "%s", DummyString); // get the right parenthesis ")" and the string "coste"
				fscanf(fp, "%d", &ARPArc[i].TravCost);

				ARPArc[i+NO_NonReqEdge].Head = ARPArc[i].Tail;
				ARPArc[i+NO_NonReqEdge].Tail = ARPArc[i].Head;
				ARPArc[i+NO_NonReqEdge].TravCost = ARPArc[i].TravCost;
			}
		}
		else if (strcmp(DummyString, "DEPOSITO") == 0)
		{
			fscanf(fp, "%s", DummyString);
			fscanf(fp, "%d", &DEPOT);
			break;
		}
	}

	fclose(fp);

	ARPTask[0].Tail = DEPOT;
	ARPTask[0].Head = DEPOT;
	ARPTask[0].DeadCost = 0;
	ARPTask[0].ServCost = 0;
	ARPTask[0].Demand = 0;
	ARPTask[0].Inv = 0;
	ARPArc[0].Tail = DEPOT;
	ARPArc[0].Head = DEPOT;
	ARPArc[0].TravCost = 0;

	for (i = 0; i <= NO_Vertices; i++)
	{
		for (j = 0; j <= NO_Vertices; j++)
		{
			Cost[i][j] = INF;
			ServCostMatr[i][j] = 0;
		}
	}

	Cost[1][0] = 0;
	Cost[0][1] = 0;

	for (i = 1; i <= NO_Arcs; i++)
	{
		Cost[ARPArc[i].Tail][ARPArc[i].Head] = ARPArc[i].TravCost;
	}

	for (i = 1; i <= NO_Tasks; i++)
	{
		ServCostMatr[ARPTask[i].Tail][ARPTask[i].Head] = ARPTask[i].ServCost;
	}

	int NVer, NRE, NRA, NNR, NVeh, Cap, LLB;
	NVer = NO_Vertices;
	NRE = NO_ReqEdge;
	NRA = NO_ReqArc;
	NNR = 2*NO_NonReqEdge+NO_NonReqArc;
	NVeh = NO_Vehicles;
	Cap = Capacity;
	LLB = LowerBound;

	ModifiedDijkstra(MinCost, Cost, NVer);

	val[0] = 0;
	rep[0] = 0;
	FitCost[0][0] = 0;
	TotalFitEval = 0;

	/* get output_file */

	char OutputFile[100] = "output.dat"; // the name of the output file can be set here

	/* random seed */

	clock_t start = clock();

	int tm;
	tm = time(NULL);
	//tm = 1239002157;
	srand(tm);

	//printf("tm = %d\n", tm);

	fp = fopen(OutputFile, "w");

	fprintf(fp, "The random seed is %d.\n", tm);
	fprintf(fp, "There are %d vertices, %d tasks, and the capacities of vehicles is %d.\n\n", NO_Vertices, NO_ReqEdge+NO_ReqArc, Capacity);

	fclose(fp);

	// Initialization

	int flag;

	double PenPrmt = 1;
	int ConstFsb, ConstInFsb;

	int FSI, FDI, FSWAP;

	struct Individual InitSolution;
	int ServMark[2*NRE+NRA+1];

	for (i = 1; i <= 2*NRE+NRA; i++)
	{
		ServMark[i] = 1;
	}

	PathScanning(&InitSolution, ARPTask, ServMark, MinCost, NRE, NRA, NVeh, Cap);
	InitSolution.Fitness = InitSolution.TotalCost;

	//printf("ok\n");

	int Route[250], FHRoute[250], Positions[50], TmpSeq[250], Cost1, Cost2;

	TmpSeq[0] = 1;
	InitSolution.TotalCost = 0;

	FindPositions(InitSolution.Sequence, 0, Positions);
	for(i = 1; i < Positions[0]; i++)
	{
		AssignSubArray(InitSolution.Sequence, Positions[i], Positions[i+1], Route);
		FredericksonHeuristic(FHRoute, Route, ARPTask, MinCost, NO_Tasks);
		Cost1 = CalcTaskSeqTotalCost(Route, ARPTask, MinCost);
		Cost2 = CalcTaskSeqTotalCost(FHRoute, ARPTask, MinCost);

		TmpSeq[0] --;
		if (Cost1 < Cost2)
		{
			JoinArray(TmpSeq, Route);
			InitSolution.TotalCost += Cost1;
		}
		else
		{
			JoinArray(TmpSeq, FHRoute);
			InitSolution.TotalCost += Cost2;
		}
	}

	InitSolution.Fitness = InitSolution.TotalCost;
	AssignArray(TmpSeq, InitSolution.Sequence);

	InitSolution.Assignment[0] = NO_ReqEdge+NO_ReqArc;
	j = 1;
	for (i = 2; i < InitSolution.Sequence[0]; i++)
	{
		if (InitSolution.Sequence[i] == 0)
		{
			j ++;
			continue;
		}

		int tmp = InitSolution.Sequence[i];
		if (tmp > NO_ReqEdge)
			tmp -= NO_ReqEdge;

		InitSolution.Assignment[tmp] = j;
	}

	/*printf("seq\n");
	for (i = 1; i <= InitSolution.Sequence[0]; i++)
	{
	printf("%d ", InitSolution.Sequence[i]);
	}
	printf("\n");
	printf("assignment\n");
	for (i = 1; i <= InitSolution.Assignment[0]; i++)
	{
	printf("%d ", InitSolution.Assignment[i]);
	}
	printf("\n");*/

	//printf("init totalcost = %d, fitness = %lf\n", InitSolution.TotalCost, InitSolution.Fitness);
	/*printf("%d\n", Legal(InitSolution.Sequence, ARPTask, NRE, NRA));
	printf("loads\n");
	for (i = 1; i <= InitSolution.Loads[0]; i++)
	{
	printf("%d ", InitSolution.Loads[i]);
	}
	printf("\n");*/

	// TSA

	struct Individual CurrSolution, BestSolution, BestFsbSolution, NextSolution, TmpSolution;
	struct Individual BestSINeighbor, BestDINeighbor, BestSWAPNeighbor;

	int ChangedRoutesID[2], MovedTasks[3], BestMovedTasks[3], RID1, RID2;
	int TabuList[2*NRE+NRA+1][50];
	memset(TabuList, 0, sizeof(TabuList));
	int TabuTenure = (NRE+NRA)/2;

	CurrSolution = InitSolution;
	BestSolution = InitSolution;
	BestFsbSolution.TotalCost = INF;
	if (InitSolution.TotalVioLoad == 0)
	{
		BestFsbSolution = InitSolution;
	}

	ConstFsb = 0;
	ConstInFsb = 0;
	FSI = 1;
	FDI = 1;
	FSWAP = 1;

	int npi, mnpi, nti, mnti;
	//mnpi = 30000;
	//mnti = 10000;
	mnpi = 900*sqrt(NRE+NRA);

	npi = 0;
	nti = 0;

	val[0] ++;
	val[val[0]] = npi;
	val[0] ++;
	val[val[0]] = BestFsbSolution.TotalCost;

	while (BestFsbSolution.TotalCost > LowerBound)
	{
		NextSolution.Fitness = INF;
		int Improved = 0;
		//if (npi%10 == 0)
		//{
		//  printf("PenPrmt = %lf\n", PenPrmt);
		//}
		//printf("current total cost = %d, vioload = %d, penprmt = %lf, fitness = %lf\n", CurrSolution.TotalCost,
		//CurrSolution.TotalVioLoad, PenPrmt, CurrSolution.Fitness);
		/*printf("loads\n");
		for (i = 1; i <= CurrSolution.Loads[0]; i++)
		{
		printf("%d ", CurrSolution.Loads[i]);
		}
		printf("\n");
		printf("PenPrmt = %lf\n", PenPrmt);*/

		if (npi%FSI == 0)
		{
			//printf("1\n");
			FitEval = SingleInsertion(ChangedRoutesID, MovedTasks, &BestSINeighbor, &CurrSolution, TabuList, TabuTenure, ARPTask,
				PenPrmt, BestSolution.Fitness, BestFsbSolution.Fitness, MinCost, NRE, NRA, Cap, NVeh);
			//printf("ends\n");

			TotalFitEval += FitEval;

			if (BestSINeighbor.TotalVioLoad == 0 && BestSINeighbor.TotalCost < BestFsbSolution.TotalCost)
			{
				Improved = 1;
				BestFsbSolution = BestSINeighbor;
				FitCost[0][0] ++;
				FitCost[FitCost[0][0]][0] = npi;
				FitCost[FitCost[0][0]][1] = TotalFitEval;
				FitCost[FitCost[0][0]][2] = BestFsbSolution.TotalCost;
			}

			if (BestSINeighbor.Fitness < NextSolution.Fitness)
			{
				flag = 1;
				NextSolution = BestSINeighbor;
				RID1 = ChangedRoutesID[0];
				RID2 = ChangedRoutesID[1];
				AssignArray(MovedTasks, BestMovedTasks);
			}
		}

		if (npi%FDI == 0)
		{
			//printf("2\n");
			FitEval = DoubleInsertion(ChangedRoutesID, MovedTasks, &BestDINeighbor, &CurrSolution, TabuList, TabuTenure, ARPTask,
				PenPrmt, BestSolution.Fitness, BestFsbSolution.Fitness, MinCost, NRE, NRA, Cap, NVeh);
			//printf("ends\n");

			TotalFitEval += FitEval;

			if (BestDINeighbor.TotalVioLoad == 0 && BestDINeighbor.TotalCost < BestFsbSolution.TotalCost)
			{
				Improved = 1;
				BestFsbSolution = BestDINeighbor;
				FitCost[0][0] ++;
				FitCost[FitCost[0][0]][0] = npi;
				FitCost[FitCost[0][0]][1] = TotalFitEval;
				FitCost[FitCost[0][0]][2] = BestFsbSolution.TotalCost;
			}

			if (BestDINeighbor.Fitness < NextSolution.Fitness)
			{
				flag = 2;
				NextSolution = BestDINeighbor;
				RID1 = ChangedRoutesID[0];
				RID2 = ChangedRoutesID[1];
				AssignArray(MovedTasks, BestMovedTasks);
			}
		}

		if (npi%FSWAP == 0)
		{
			//printf("3\n");
			FitEval = SWAP(ChangedRoutesID, MovedTasks, &BestSWAPNeighbor, &CurrSolution, TabuList, TabuTenure, ARPTask,
				PenPrmt, BestSolution.Fitness, BestFsbSolution.Fitness, MinCost, NRE, NRA, Cap);
			//printf("ends\n");

			TotalFitEval += FitEval;

			if (BestSWAPNeighbor.TotalVioLoad == 0 && BestSWAPNeighbor.TotalCost < BestFsbSolution.TotalCost)
			{
				Improved = 1;
				BestFsbSolution = BestSWAPNeighbor;
				FitCost[0][0] ++;
				FitCost[FitCost[0][0]][0] = npi;
				FitCost[FitCost[0][0]][1] = TotalFitEval;
				FitCost[FitCost[0][0]][2] = BestFsbSolution.TotalCost;
			}

			if (BestSWAPNeighbor.Fitness < NextSolution.Fitness)
			{
				flag = 3;
				NextSolution = BestSWAPNeighbor;
				RID1 = ChangedRoutesID[0];
				RID2 = ChangedRoutesID[1];
				AssignArray(MovedTasks, BestMovedTasks);
			}
		}

		npi ++;
		nti ++;

		if (NextSolution.TotalVioLoad == 0)
		{
			ConstFsb ++;
		}
		else
		{
			ConstInFsb ++;
		}

		if (NextSolution.TotalCost < BestFsbSolution.TotalCost && NextSolution.TotalVioLoad > 0)
		{
			/*printf("curr seq\n");
			for (i = 1; i <= CurrSolution.Sequence[0]; i++)
			{
			printf("%d ", CurrSolution.Sequence[i]);
			}
			printf("\n");
			printf("before seq\n");
			for (i = 1; i <= NextSolution.Sequence[0]; i++)
			{
			printf("%d ", NextSolution.Sequence[i]);
			}
			printf("\n");
			printf("before total cost = %d, total vioload = %d\n", NextSolution.TotalCost, NextSolution.TotalVioLoad);*/
			TmpSolution = NextSolution;
			RepairInfeasibility(&TmpSolution, ARPTask, MinCost, NRE, NRA, Cap);
			TotalFitEval ++;

			if (TmpSolution.TotalVioLoad < NextSolution.TotalVioLoad ||
				(TmpSolution.TotalVioLoad == NextSolution.TotalVioLoad && TmpSolution.TotalCost < NextSolution.TotalCost))
			{
				NextSolution = TmpSolution;

				rep[0] ++;
				rep[rep[0]] = npi;
			}

			if (NextSolution.TotalVioLoad == 0 && NextSolution.TotalCost < BestFsbSolution.TotalCost)
			{
				Improved = 1;
				BestFsbSolution = NextSolution;
				FitCost[0][0] ++;
				FitCost[FitCost[0][0]][0] = npi;
				FitCost[FitCost[0][0]][1] = TotalFitEval;
				FitCost[FitCost[0][0]][2] = BestFsbSolution.TotalCost;
			}

			/*printf("after seq\n");
			for (i = 1; i <= NextSolution.Sequence[0]; i++)
			{
			printf("%d ", NextSolution.Sequence[i]);
			}
			printf("\n");
			printf("after total cost = %d, total vioload = %d\n", NextSolution.TotalCost, NextSolution.TotalVioLoad);*/
		}

		if (NextSolution.TotalVioLoad == 0/* && NextSolution.TotalCost < BestFsbSolution.TotalCost*/)
		{
			TmpSeq[0] = 1;
			NextSolution.TotalCost = 0;

			FindPositions(NextSolution.Sequence, 0, Positions);
			for(i = 1; i < Positions[0]; i++)
			{
				AssignSubArray(NextSolution.Sequence, Positions[i], Positions[i+1], Route);
				FredericksonHeuristic(FHRoute, Route, ARPTask, MinCost, NO_Tasks);
				Cost1 = CalcTaskSeqTotalCost(Route, ARPTask, MinCost);
				Cost2 = CalcTaskSeqTotalCost(FHRoute, ARPTask, MinCost);

				TmpSeq[0] --;
				if (Cost1 < Cost2)
				{
					JoinArray(TmpSeq, Route);
					NextSolution.TotalCost += Cost1;
				}
				else
				{
					JoinArray(TmpSeq, FHRoute);
					NextSolution.TotalCost += Cost2;
				}
			}

			NextSolution.Fitness = NextSolution.TotalCost;
			AssignArray(TmpSeq, NextSolution.Sequence);
		}

		if (Improved && NextSolution.TotalVioLoad == 0)
		{
			BestFsbSolution = NextSolution;
			nti = 0;

			printf("new best totalcost = %d\n", BestFsbSolution.TotalCost);

			/*val[0] ++;
			val[val[0]] = npi;
			val[0] ++;
			val[val[0]] = BestFsbSolution.TotalCost;*/
		}

		/*if (NextSolution.TotalVioLoad == 0 && NextSolution.TotalCost < BestFsbSolution.TotalCost)
		{
		BestFsbSolution = NextSolution;
		nti = 0;

		printf("new best totalcost = %d\n", BestFsbSolution.TotalCost);

		val[0] ++;
		val[val[0]] = npi;
		val[0] ++;
		val[val[0]] = BestFsbSolution.TotalCost;
		}*/

		NextSolution.Assignment[0] = NO_ReqEdge+NO_ReqArc;
		j = 1;
		for (i = 2; i < NextSolution.Sequence[0]; i++)
		{
			if (NextSolution.Sequence[i] == 0)
			{
				j ++;
				continue;
			}

			int tmp = NextSolution.Sequence[i];
			if (tmp > NO_ReqEdge)
				tmp -= NO_ReqEdge;

			NextSolution.Assignment[tmp] = j;
		}

		/*printf("flag = %d\n", flag);
		printf("assignment 1\n");
		for (i = 1; i <= CurrSolution.Assignment[0]; i++)
		{
		printf("%d ", CurrSolution.Assignment[i]);
		}
		printf("\n");

		printf("assignment 2\n");
		for (i = 1; i <= NextSolution.Assignment[0]; i++)
		{
		printf("%d ", NextSolution.Assignment[i]);
		}
		printf("\n");*/

		for (i = 1; i <= 2*NRE+NRA; i++)
		{
			for (j = 0; j <= NVeh; j++)
			{
				if (TabuList[i][j] > 0)
				{
					//printf("task %d is tabu to move to route %d for %d iterations\n", i, j, TabuList[i][j]);
					TabuList[i][j] --;
				}
			}
		}

		for (i = 1; i <= NextSolution.Assignment[0]; i++)
		{
			if (NextSolution.Assignment[i] == CurrSolution.Assignment[i])
				continue;

			int tmp = i;
			if (tmp > NO_ReqEdge)
				tmp += NO_ReqEdge;

			TabuList[tmp][CurrSolution.Assignment[i]] = TabuTenure;
			if (i <= NO_ReqEdge)
			{
				TabuList[i+NO_ReqEdge][CurrSolution.Assignment[i]] = TabuTenure;
			}
		}

		/*switch (flag)
		{
		case 1:
		{
		TabuList[BestMovedTasks[1]][RID1] = TabuTenure;
		if (ARPTask[BestMovedTasks[1]].Inv > 0)
		{
		TabuList[ARPTask[BestMovedTasks[1]].Inv][RID1] = TabuTenure;
		}
		break;
		}

		case 2:
		{
		TabuList[BestMovedTasks[1]][RID1] = TabuTenure;
		TabuList[BestMovedTasks[2]][RID1] = TabuTenure;
		if (ARPTask[BestMovedTasks[1]].Inv > 0)
		{
		TabuList[ARPTask[BestMovedTasks[1]].Inv][RID1] = TabuTenure;
		}
		if (ARPTask[BestMovedTasks[2]].Inv > 0)
		{
		TabuList[ARPTask[BestMovedTasks[2]].Inv][RID1] = TabuTenure;
		}
		break;
		}

		case 3:
		{
		TabuList[BestMovedTasks[1]][RID1] = TabuTenure;
		TabuList[BestMovedTasks[2]][RID2] = TabuTenure;
		if (ARPTask[BestMovedTasks[1]].Inv > 0)
		{
		TabuList[ARPTask[BestMovedTasks[1]].Inv][RID1] = TabuTenure;
		}
		if (ARPTask[BestMovedTasks[2]].Inv > 0)
		{
		TabuList[ARPTask[BestMovedTasks[2]].Inv][RID2] = TabuTenure;
		}
		break;
		}
		}*/

		if (NextSolution.Fitness < BestSolution.Fitness)
		{
			BestSolution = NextSolution;
		}

		CurrSolution = NextSolution;

		if (npi%10 == 0)
		{
			if (ConstFsb == 10)
			{
				PenPrmt /= 2;
				BestSolution.Fitness = BestSolution.TotalCost+PenPrmt*BestSolution.TotalVioLoad;
				CurrSolution.Fitness = CurrSolution.TotalCost+PenPrmt*CurrSolution.TotalVioLoad;
			}
			else if (ConstInFsb == 10)
			{
				PenPrmt *= 2;
				BestSolution.Fitness = BestSolution.TotalCost+PenPrmt*BestSolution.TotalVioLoad;
				CurrSolution.Fitness = CurrSolution.TotalCost+PenPrmt*CurrSolution.TotalVioLoad;
			}

			ConstFsb = 0;
			ConstInFsb = 0;
		}

		if (npi == mnpi /*|| nti == mnti*/)
			break;
	}

	clock_t finish = clock();

	double duration = (double)(finish-start)/CLOCKS_PER_SEC;

	/*printf("BestFsbSeq is\n");
	for (i = 1; i <= BestFsbSolution.Sequence[0]; i++)
	{
	printf("%d  ", BestFsbSolution.Sequence[i]);
	}
	printf("\n");

	printf("BestFsbCost = %d\n", BestFsbSolution.TotalCost);
	printf("BestFsbLoads\n");
	for (i = 1; i <= BestFsbSolution.Loads[0]; i++)
	{
	printf("%d  ", BestFsbSolution.Loads[i]);
	}
	printf("\n");
	printf("BestFsbTotalvioload = %d\n", BestFsbSolution.TotalVioLoad);
	printf("BestFsbFitness = %f\n", BestFsbSolution.Fitness);
	printf("\n\n");*/
	/*
	k = 0;

	for (i = 1; i < (BestFsbSolution.Sequence)[0]; i++)
	{
	for (j = 1; j <= ShortestPath[ARPTask[(BestFsbSolution.Sequence)[i]].Head][ARPTask[(BestFsbSolution.Sequence)[i+1]].Tail][0]; j++)
	{
	k ++;
	val1[k] = ShortestPath[ARPTask[(BestFsbSolution.Sequence)[i]].Head][ARPTask[(BestFsbSolution.Sequence)[i+1]].Tail][j];
	}
	k ++;
	val1[k] = 1000;
	}

	k--;
	*/

	fp = fopen(OutputFile, "a");

	fprintf(fp, "The best sequence is:\n");
	for (i = 1; i <= BestFsbSolution.Sequence[0]; i++)
	{
		fprintf(fp, "%d ", BestFsbSolution.Sequence[i]);
	}
	fprintf(fp, "\nThe best total cost is %d.\n", BestFsbSolution.TotalCost);
	fprintf(fp, "The duration time is %f seconds.\n", duration);
	fprintf(fp, "The number of iterations is %d.\n", npi);

	fclose(fp);
	/*
	fp = fopen(OutputFile, "w");

	for (i = 1; i <= FitCost[0][0]; i++)
	{
	fprintf(fp, "%d  %d  %d\n", FitCost[i][0], FitCost[i][1], FitCost[i][2]);
	}
	*/
	/*for (i = 1; i <= val[0]/2; i++)
	{
	fprintf(fp, "%d  %d\n", val[2*i-1], val[2*i]);
	}*/
	//fprintf(fp, "%d\n", val[val[0]]);
	/*
	for (i = 1; i <= k; i++)
	{
	fprintf(fp, "%d ", val1[i]);
	}

	fprintf(fp, "\n\nloads\n");
	for (i = 1; i <= BestFsbSolution.Loads[0]; i++)
	{
	fprintf(fp, " %d ", BestFsbSolution.Loads[i]);
	}

	fprintf(fp, "\nduration time = %f seconds\n\n", duration);

	fprintf(fp, "npi = %d, TotalFitEval = %d\n", npi, TotalFitEval);

	fprintf(fp, "\n\nrep\n");
	for (i = 1; i <= rep[0]; i++)
	{
	fprintf(fp, "%d\n", rep[i]);
	}

	fclose(fp);
	*/
}
