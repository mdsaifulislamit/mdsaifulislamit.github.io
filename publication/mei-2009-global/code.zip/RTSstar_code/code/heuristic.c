
#include <math.h>
#include "arrayoperations.h"
#include "initialization.h"
#include "heuristic.h"

#define INF 2100000000

void FredericksonHeuristic(int *FHRoute, int *Route, const struct Task *ARPTask, int (*MinCost)[141], int NO_Task)
// for undirected rural postman problem
{
	int i, j, k, u, v;
	
	int EulerRoute[3*(Route[0]-1)];
	
	int Degree[141];
	int OddNodes[141];
	
	int Nodes[2*Route[0]+2];
	Nodes[0] = 1;
	Nodes[1] = 1;
	
	int flag[141];
	memset(flag, 0, sizeof(flag));
	flag[1] = 1;
	
	int AdMatrix[250][250]; // edges induced by tasks
	int TaskMatrix[250][250]; // task adjacent matrix
	memset(AdMatrix, 0, sizeof(AdMatrix));
	memset(TaskMatrix, 0, sizeof(TaskMatrix));
	
	int Neighbors[250][250];
	for (i = 1; i <= NO_Vertices; i++)
	{
		Neighbors[i][0] = 0;
	}
	
	int ConnectivePieceNodes[2*Route[0]+2][2*Route[0]+2];
	ConnectivePieceNodes[0][0] = 0;
	
	int PieceMark[141];
	memset(PieceMark, 0, sizeof(PieceMark));
	PieceMark[0] = NO_Vertices;
	
	int CPMinCost[141][141];
	for (i = 1; i <= NO_Vertices; i++)
	{
		for (j = 1; j <= NO_Vertices; j++)
		{
			CPMinCost[i][j] = INF;
		}
	}
	
	int CPMCTree[141][141];
	
	int CurrentPiece = 0;
	
	for (i = 2; i < Route[0]; i++)
	{
		Neighbors[ARPTask[Route[i]].Tail][0] ++;
		Neighbors[ARPTask[Route[i]].Tail][Neighbors[ARPTask[Route[i]].Tail][0]] = ARPTask[Route[i]].Head;
		Neighbors[ARPTask[Route[i]].Head][0] ++;
		Neighbors[ARPTask[Route[i]].Head][Neighbors[ARPTask[Route[i]].Head][0]] = ARPTask[Route[i]].Tail;
		
		if (!flag[ARPTask[Route[i]].Tail])
		{
			Nodes[0] ++;
			Nodes[Nodes[0]] = ARPTask[Route[i]].Tail;
			flag[ARPTask[Route[i]].Tail] = 1;
		}
		
		if (!flag[ARPTask[Route[i]].Head])
		{
			Nodes[0] ++;
			Nodes[Nodes[0]] = ARPTask[Route[i]].Head;
			flag[ARPTask[Route[i]].Head] = 1;
		}

		AdMatrix[ARPTask[Route[i]].Tail][ARPTask[Route[i]].Head] ++;
		AdMatrix[ARPTask[Route[i]].Head][ARPTask[Route[i]].Tail] ++;
		TaskMatrix[ARPTask[Route[i]].Tail][ARPTask[Route[i]].Head] ++;
		TaskMatrix[ARPTask[Route[i]].Head][ARPTask[Route[i]].Tail] ++;
	}
	
	for (i = 1; i <= Nodes[0]; i++)
	{
		if (PieceMark[Nodes[i]] > 0)
			continue;
		
		CurrentPiece ++;
		GetConnectivePiece(Nodes[i], CurrentPiece, PieceMark, Neighbors);
	}
	
	ConnectivePieceNodes[0][0] = max(PieceMark);
	for (i = 1; i <= ConnectivePieceNodes[0][0]; i++)
	{
		ConnectivePieceNodes[i][0] = 0;
	}
	
	for (i = 1; i <= Nodes[0]; i++)
	{
		ConnectivePieceNodes[PieceMark[Nodes[i]]][0] ++;
		ConnectivePieceNodes[PieceMark[Nodes[i]]][ConnectivePieceNodes[PieceMark[Nodes[i]]][0]] = Nodes[i];
	}
	
	/*for (i = 1; i <= ConnectivePieceNodes[0][0]; i++)
	{
		printf("ConnectivePiece[%d]\n", i);
		for (j = 1; j <= ConnectivePieceNodes[i][0]; j++)
		{
			printf("%d  ", ConnectivePieceNodes[i][j]);
		}
		printf("\n");
	}*/
  
	// make graph connective
	
	if (ConnectivePieceNodes[0][0] > 1)
	{
		CPMinCost[0][0] = ConnectivePieceNodes[0][0];
		CPMCTree[0][0] = ConnectivePieceNodes[0][0];
		
	  int BNode[ConnectivePieceNodes[0][0]+1][ConnectivePieceNodes[0][0]+1];
	  int ENode[ConnectivePieceNodes[0][0]+1][ConnectivePieceNodes[0][0]+1];
	  
	  for (i = 1; i < ConnectivePieceNodes[0][0]; i++)
	  {
	  	for (j = i+1; j <= ConnectivePieceNodes[0][0]; j++)
	  	{
	  		if (j == i)
	  			continue;
	  		
	  		for (u = 1; u <= ConnectivePieceNodes[i][0]; u++)
	  		{
	  			for (v = 1; v <= ConnectivePieceNodes[j][0]; v++)
	  			{
	  				if (MinCost[ConnectivePieceNodes[i][u]][ConnectivePieceNodes[j][v]] < CPMinCost[i][j])
	  				{
	  					CPMinCost[i][j] = MinCost[ConnectivePieceNodes[i][u]][ConnectivePieceNodes[j][v]];
	  					CPMinCost[j][i] = CPMinCost[i][j];
	  					BNode[i][j] = ConnectivePieceNodes[i][u];
	  					ENode[i][j] = ConnectivePieceNodes[j][v];
	  					BNode[j][i] = ENode[i][j];
	  					ENode[j][i] = BNode[i][j];
	  				}
	  			}
	  		}
	  	}
	  }
	  
	  GetMinCostTree(CPMCTree, CPMinCost);
	  
	  for (i = 1; i < CPMCTree[0][0]; i++)
	  {
	  	for (j = i+1; j <= CPMCTree[0][0]; j++)
	  	{
	  		if (CPMCTree[i][j])
	  		{
	  			//printf("add edge is (%d, %d)\n", BNode[i][j], ENode[i][j]);
	  			AdMatrix[BNode[i][j]][ENode[i][j]] ++;
	  			AdMatrix[ENode[i][j]][BNode[i][j]] ++;
	  			
	  			if (CPMinCost[i][j] == INF)
	  			{
	  				CPMinCost[i][j] = MinCost[BNode[i][j]][ENode[i][j]];
	  				CPMinCost[j][i] = CPMinCost[i][j];
	  			}
	  		}
	  	}
	  }
	}
	
	memset(Degree, 0, sizeof(Degree));
	OddNodes[0] = 0;
	 
	for (i = 1; i <= Nodes[0]; i++)
  {
  	for (j = 1; j <= Nodes[0]; j++)
  	{
  		Degree[Nodes[i]] += AdMatrix[Nodes[i]][Nodes[j]];
  	}
  	
  	if (Degree[Nodes[i]]%2 == 1)
  	{
  		OddNodes[0] ++;
  		OddNodes[OddNodes[0]] = Nodes[i];
  	}
  }
  
  /*printf("OddNodes\n");
  for (i = 1; i <= OddNodes[0]; i++)
  {
  	printf("%d  ", OddNodes[i]);
  }
  printf("\n");*/
  
  EvenAllOddNodes(AdMatrix, OddNodes, MinCost);
  
  //GetMinCostMatching(AdMatrix, OddNodes);
  
  GetEulerRoute(EulerRoute, AdMatrix, Nodes);
  
  FHRoute[0] = 1;
  FHRoute[1] = 0;
  
  for (i = 1; i < EulerRoute[0]; i++)
  {
  	if (TaskMatrix[EulerRoute[i]][EulerRoute[i+1]])
  	{
  		TaskMatrix[EulerRoute[i]][EulerRoute[i+1]] --;
  		TaskMatrix[EulerRoute[i+1]][EulerRoute[i]] --;
  		
  		FHRoute[0] ++;
  		FHRoute[FHRoute[0]] = FindTask(EulerRoute[i], EulerRoute[i+1], ARPTask, NO_Task);
  	}
  }
  
  FHRoute[0] ++;
  FHRoute[FHRoute[0]] = 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void GetConnectivePiece(int Root, int CurrentPiece, int *PieceMark, int (*Neighbors)[250])
{
	int i, j;
	
	PieceMark[Root] = CurrentPiece;
	
	for (i = 1; i <= Neighbors[Root][0]; i++)
	{
		if (PieceMark[Neighbors[Root][i]] > 0)
			continue;
		
		GetConnectivePiece(Neighbors[Root][i], CurrentPiece, PieceMark, Neighbors);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void GetMinCostTree(int (*CPMCTree)[141], int (*CPMinCost)[141])
{
	int i, j, k;
	int u, v;
	int MCost;
	
	for (i = 1; i <= NO_Vertices; i++)
	{
		for (j = 1; j <= NO_Vertices; j++)
		{
			CPMCTree[i][j] = 0;
		}
	}
	
	int ColoredArcs[CPMinCost[0][0]+1][CPMinCost[0][0]+1];
	int Visited[CPMinCost[0][0]+1];
	
	memset(ColoredArcs, 0, sizeof(ColoredArcs));
	memset(Visited, 0, sizeof(Visited));
	
	Visited[1] = 1;
	
	for (i = 1; i <= CPMinCost[0][0]; i++)
	{
		if (CPMinCost[1][i] < INF)
		{
			ColoredArcs[1][i] = 1;
		}
		
		if (CPMinCost[i][1] < INF)
		{
			ColoredArcs[i][1] = 1;
		}
	}
	
	for (k = 1; k < CPMinCost[0][0]; k++)
	{
		MCost = INF;
		
		for (i = 1; i <= CPMinCost[0][0]; i++)
		{
			for (j = 1; j <= CPMinCost[0][0]; j++)
			{
				if (ColoredArcs[i][j] == 1)
				{
		  		if (CPMinCost[i][j] < MCost)
		  		{
		  			MCost = CPMinCost[i][j];
		  			u = i;
		  			v = j;
		  		}
		  	}
		  }
		}
		
		if (!Visited[u])
		{
			Visited[u] = 1;
			
			for (i = 1; i <= CPMinCost[0][0]; i++)
			{
				if (CPMinCost[u][i] < INF && !Visited[i])
				{
					ColoredArcs[u][i] = 1;
				}
				
				if (CPMinCost[i][u] < INF && !Visited[i])
				{
					ColoredArcs[i][u] = 1;
				}
			}
		}
		else
		{
			Visited[v] = 1;
			
			for (i = 1; i <= CPMinCost[0][0]; i++)
			{
				if (CPMinCost[v][i] < INF && !Visited[i])
				{
					ColoredArcs[v][i] = 1;
				}
				
				if (CPMinCost[i][v] < INF && !Visited[i])
				{
					ColoredArcs[i][v] = 1;
				}
			}
		}
		
		CPMCTree[u][v] = 1;
		CPMCTree[v][u] = 1;
		ColoredArcs[u][v] = 2;
		ColoredArcs[v][u] = 2;
		
		for (i = 1; i <= CPMinCost[0][0]; i++)
		{
			if (Visited[i])
				continue;
			
			MCost = INF;
			
			for (j = 1; j <= CPMinCost[0][0]; j++)
			{
				if (CPMinCost[i][j] < INF && Visited[j])
				{
					ColoredArcs[i][j] = 0;
					
					if (CPMinCost[i][j] < MCost)
					{
						MCost = CPMinCost[i][j];
						u = i;
						v = j;
					}
				}
			}
			
			for (j = 1; j <= CPMinCost[0][0]; j++)
			{
				if (CPMinCost[j][i] < INF && Visited[j])
				{
					ColoredArcs[j][i] = 0;
					
					if (CPMinCost[j][i] < MCost)
					{
						MCost = CPMinCost[j][i];
						u = j;
						v = i;
					}
				}
			}
			
			ColoredArcs[u][v] = 1;
			ColoredArcs[v][u] = 1;
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void GetEulerRoute(int *EulerRoute, int (*AdMatrix)[250], int *Nodes)
{
	int i, j;
	int backplace;
	
	EulerRoute[0] = 0;
	
	FindCircuit(EulerRoute, 1, AdMatrix, Nodes);
	
	for (backplace = 1; backplace <= EulerRoute[0]; backplace++)
	{
		if (EulerRoute[backplace] == 1)
			break;
	}
	
	backplace --;
	
	int TmpER[EulerRoute[0]+1];
	AssignArray(EulerRoute, TmpER);
	
	for (i = 1; i <= EulerRoute[0]-backplace; i++)
	{
		EulerRoute[i] = TmpER[i+backplace];
	}
	
	for (i = 1; i <= backplace; i++)
	{
		EulerRoute[EulerRoute[0]-backplace+i] = TmpER[i+1];
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void FindCircuit(int *EulerRoute, int CurrentNode, int (*AdMatrix)[250], int *Nodes)
{
	int i, j, k;
	int Neighbors[Nodes[0]];
	Neighbors[0] = 0;
	
	for (i = 1; i <= Nodes[0]; i++)
	{
		if (AdMatrix[CurrentNode][Nodes[i]])
		{
			Neighbors[0] ++;
			Neighbors[Neighbors[0]] = Nodes[i];
		}
	}
	
	if (Neighbors[0] == 0)
	{
		EulerRoute[0] ++;
		EulerRoute[EulerRoute[0]] = CurrentNode;
	}
	else
	{
		while(Neighbors[0] > 0)
		{
			k = RandChoose(Neighbors[0]);
			
			AdMatrix[CurrentNode][Neighbors[k]] --;
			AdMatrix[Neighbors[k]][CurrentNode] --;
			
			FindCircuit(EulerRoute, Neighbors[k], AdMatrix, Nodes);
			
			Neighbors[0] = 0;
			for (i = 1; i <= Nodes[0]; i++)
			{
				if (AdMatrix[CurrentNode][Nodes[i]])
				{
					Neighbors[0] ++;
					Neighbors[Neighbors[0]] = Nodes[i];
				}
			}
		}
		
		EulerRoute[0] ++;
		EulerRoute[EulerRoute[0]] = CurrentNode;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int SwitchDecimal(int *Binary)
{
	int i;
	int Decimal = 0;
	
	for (i = 1; i <= Binary[0]; i++)
	{
		Decimal += Binary[i]*pow(2, Binary[0]-i);
	}
	
	return Decimal;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void SwitchBinary(int *Binary, int Decimal)
{
	int i, k;
	int TmpDecimal;
	
	for (i = 1; i <= Binary[0]; i++)
	{
		Binary[i] = 0;
	}
	
	k = Binary[0];
	TmpDecimal = Decimal;
	while (TmpDecimal > 0)
	{
		if (TmpDecimal%2 == 1)
		{
			Binary[k] = 1;
		}
		
		TmpDecimal /= 2;
		k --;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void EvenAllOddNodes(int (*AdMatrix)[250], int *OddNodes, int (*MinCost)[141])
{
	int i, j, k;
	int LeftNodes[NO_Vertices+1];
	AssignArray(OddNodes, LeftNodes);
	
	struct Link
	{
		int LinkNode1Pos;
		int LinkNode2Pos;
		int LinkCost;
	};
	
	struct Link TmpLink, BestLink;
	
	/*printf("OddNodes\n");
	for (i = 1; i <= OddNodes[0]; i++)
	{
		printf("%d  ", OddNodes[i]);
	}
	printf("\n");*/
	
	for (i = 1; i <= OddNodes[0]/2; i++)
	{
		BestLink.LinkCost = INF;
		for (j = 1; j < LeftNodes[0]; j++)
		{
			for (k = j+1; k <= LeftNodes[0]; k++)
			{
				TmpLink.LinkNode1Pos = j;
				TmpLink.LinkNode2Pos = k;
				TmpLink.LinkCost = MinCost[LeftNodes[j]][LeftNodes[k]];
				
				if (TmpLink.LinkCost < BestLink.LinkCost)
					BestLink = TmpLink;
			}
		}
		
		//printf("Link %d and %d\n", LeftNodes[BestLink.LinkNode1Pos], LeftNodes[BestLink.LinkNode2Pos]);
		
		AdMatrix[LeftNodes[BestLink.LinkNode1Pos]][LeftNodes[BestLink.LinkNode2Pos]] ++;
		AdMatrix[LeftNodes[BestLink.LinkNode2Pos]][LeftNodes[BestLink.LinkNode1Pos]] ++;
		
		if (BestLink.LinkNode1Pos < BestLink.LinkNode2Pos)
		{
			DeleteElement(LeftNodes, BestLink.LinkNode2Pos);
			DeleteElement(LeftNodes, BestLink.LinkNode1Pos);
		}
		else
		{
			DeleteElement(LeftNodes, BestLink.LinkNode1Pos);
			DeleteElement(LeftNodes, BestLink.LinkNode2Pos);
		}
	}
}
