
#include <stdlib.h>
#include "initialization.h"
#include "arrayoperations.h"
#include "heuristic.h"

#define INF 2100000000

extern int ShortestPath[141][141][141];

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void RandScanningInit(struct Individual *Indi, const struct Task *ARPTask, int (*MinCost)[141], int NRE, int NRA, int Cap,
int NVeh)
{
	int i, j, k;
	
	int TrialLength = NRE+NRA;
	int NO_Task = 2*NRE+NRA;
	int load, trial, mindist;
	int Positions[NO_Task+1];
	int NRoutes = 0;
	
	int UnservedArc[NO_Task+1];
	int CandTask[NO_Task+1];
	int MinTask[NO_Task+1];
	int CurrentTask;
	int NextTask;
	
	Indi->Sequence[0] = 1;
	Indi->Sequence[1] = 0;
	
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	UnservedArc[0] = 0;
	for(i = 1; i <= NO_Task; i++)
	{
		UnservedArc[0] ++;
		UnservedArc[UnservedArc[0]] = i;
	}
	Indi->Loads[0] = 0;
	
	load = 0;
	trial = 0;
	while (trial < TrialLength)
	{
		/*if (NRoutes == NVeh)
		{
			struct Insertion
			{
				int InsertedTask;
				int InsertedPos;
				int InsertedRoute;
				int InsertCost;
				int InsertVioLoad;
			};
			
			struct Insertion CandInsertions[100], TmpInsertion, NextInsertion;
			int NO_CandInsertions = 0;
			CandInsertions[1].InsertCost = INF;
			CandInsertions[1].InsertVioLoad = INF;
			
			for (i = 1; i <= UnservedArc[0]; i++)
			{
				int CurrRoute = 0;
				for (j = 2; j <= Indi->Sequence[0]; j++)
				{
					if (Indi->Sequence[j-1] == 0)
						CurrRoute ++;
					
					TmpInsertion.InsertedTask = UnservedArc[i];
					TmpInsertion.InsertedPos = j;
					TmpInsertion.InsertedRoute = CurrRoute;
					TmpInsertion.InsertCost = MinCost[ARPTask[Indi->Sequence[j-1]].Head][ARPTask[UnservedArc[i]].Tail]
					+MinCost[ARPTask[UnservedArc[i]].Head][ARPTask[Indi->Sequence[j]].Tail]
					-MinCost[ARPTask[Indi->Sequence[j-1]].Head][ARPTask[Indi->Sequence[j]].Tail];
					if (Indi->Loads[CurrRoute] >= Cap)
					{
						TmpInsertion.InsertVioLoad = ARPTask[UnservedArc[i]].Demand;
					}
					else
					{
						TmpInsertion.InsertVioLoad = Indi->Loads[CurrRoute]+ARPTask[UnservedArc[i]].Demand-Cap;
					}
					
					if (TmpInsertion.InsertVioLoad < CandInsertions[1].InsertVioLoad ||
						(TmpInsertion.InsertVioLoad == CandInsertions[1].InsertVioLoad &&
						TmpInsertion.InsertCost < CandInsertions[1].InsertCost))
					{
						NO_CandInsertions = 1;
						CandInsertions[NO_CandInsertions] = TmpInsertion;
					}
					else if (TmpInsertion.InsertVioLoad == CandInsertions[1].InsertVioLoad &&
						TmpInsertion.InsertCost == CandInsertions[1].InsertCost)
					{
						NO_CandInsertions ++;
						CandInsertions[NO_CandInsertions] = TmpInsertion;
				  }
				}
			}
			
			k = RandChoose(NO_CandInsertions);
			NextInsertion = CandInsertions[k];
			
			AddElement(Indi->Sequence, NextInsertion.InsertedTask, NextInsertion.InsertedPos);
			Indi->Loads[NextInsertion.InsertedRoute] += ARPTask[NextInsertion.InsertedTask].Demand;
			
			FindPositions(UnservedArc, NextInsertion.InsertedTask, Positions);
	  	DeleteElement(UnservedArc, Positions[1]);
		  
  		if (ARPTask[NextInsertion.InsertedTask].Inv > 0)
	  	{
		  	FindPositions(UnservedArc, ARPTask[NextInsertion.InsertedTask].Inv, Positions);
			  DeleteElement(UnservedArc, Positions[1]);
		  }
		  
		  trial ++;
		  
			continue;
		}*/
		
		CurrentTask = Indi->Sequence[Indi->Sequence[0]];
		
		CandTask[0] = 0;
		MinTask[0] = 0;
		
		for (i = 1; i <= UnservedArc[0]; i++)
		{
			if (ARPTask[UnservedArc[i]].Demand <= Cap-load)
			{
				CandTask[0] ++;
				CandTask[CandTask[0]] = UnservedArc[i];
			}
		}
		
		if (CandTask[0] == 0)
		{
			Indi->Sequence[0] ++;
			Indi->Sequence[Indi->Sequence[0]] = 0;
			Indi->Loads[0] ++;
			Indi->Loads[Indi->Loads[0]] = load;
			load = 0;
			NRoutes ++;
			continue;
		}
		
		mindist = INF;
		
		for (i = 1; i <= CandTask[0]; i++)
		{
			if (MinCost[ARPTask[CurrentTask].Head][ARPTask[CandTask[i]].Tail] < mindist)
			{
				mindist = MinCost[ARPTask[CurrentTask].Head][ARPTask[CandTask[i]].Tail];
				MinTask[0] = 1;
				MinTask[MinTask[0]] = CandTask[i];
			}
			else if (MinCost[ARPTask[CurrentTask].Head][ARPTask[CandTask[i]].Tail] == mindist)
			{
				MinTask[0] ++;
				MinTask[MinTask[0]] = CandTask[i];
			}
		}
		
		k = RandChoose(MinTask[0]);
		NextTask = MinTask[k];
		
		Indi->Sequence[0] ++;
		Indi->Sequence[Indi->Sequence[0]] = NextTask;
		load += ARPTask[NextTask].Demand;
		FindPositions(UnservedArc, NextTask, Positions);
		DeleteElement(UnservedArc, Positions[1]);
		
		if (ARPTask[NextTask].Inv > 0)
		{
			FindPositions(UnservedArc, ARPTask[NextTask].Inv, Positions);
			DeleteElement(UnservedArc, Positions[1]);
		}
		
		trial ++;
	}
	
	if (Indi->Sequence[Indi->Sequence[0]] != 0)
	{
		Indi->Sequence[0] ++;
		Indi->Sequence[Indi->Sequence[0]] = 0;
		Indi->Loads[0] ++;
		Indi->Loads[Indi->Loads[0]] = load;
	}
	
	Indi->TotalCost = CalcTaskSeqTotalCost(Indi->Sequence, ARPTask, MinCost);
	Indi->TotalVioLoad = GetTotalVioLoad(Indi->Loads, Cap);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void RandAssignInit(struct Individual *Indi, const struct Task *ARPTask, int (*MinCost)[141], int NRE, int NRA, int Cap,
int NVeh)
{
	int i, j, k;
	int InRoutes[NRE+NRA+1][50], CheckMark[NRE+NRA+1];
	int NO_Task = 2*NRE+NRA;
	
	//printf("indi total cost = %d, total vioload = %d\n", Indi->TotalCost, Indi->TotalVioLoad);
	
	for (i = 1; i <= NRE+NRA; i++)
	{
		InRoutes[i][0] = NVeh;
		
		for (j = 1; j <= NVeh; j++)
		{
			InRoutes[i][j] = j;
		}
	}
	
	int FreeTasks[NRE+NRA+1];
	FreeTasks[0] = NRE+NRA;
	
	for (i = 1; i <= NRE+NRA; i++)
	{
		FreeTasks[i] = i;
	}
	
	struct TaskAssignment
	{
		int Assignment[NRE+NRA+1];
		int Loads[NVeh+1];
		int TotalVioLoad;
	};
	
	struct TaskAssignment CurrTA, NeighTA, NextTA, BestTA;
	
	memset(CurrTA.Assignment, 0, sizeof(CurrTA.Assignment));
	memset(CurrTA.Loads, 0, sizeof(CurrTA.Loads));
	CurrTA.Loads[0] = NVeh;
	
	for (i = 1; i <= NRE+NRA; i++)
	{
		if (InRoutes[i][0] == 1)
		{
			CurrTA.Assignment[i] = InRoutes[i][1];
			CurrTA.Loads[InRoutes[i][1]] += ARPTask[i].Demand;
		}
	}
	
	int LeftTasks[NRE+NRA+1], RouteCandDemands[NVeh+1], CandRoutes[NRE+NRA+1][50];
	AssignArray(FreeTasks, LeftTasks);
	memset(RouteCandDemands, 0, sizeof(RouteCandDemands));
	for (i = 1; i <= NRE+NRA; i++)
	{
		CandRoutes[i][0] = 0;
		for (j = 1; j <= InRoutes[i][0]; j++)
		{
			if (CurrTA.Loads[InRoutes[i][j]] >= Cap)
				continue;
			
			CandRoutes[i][0] ++;
			CandRoutes[i][CandRoutes[i][0]] = InRoutes[i][j];
		}
	}
	
	for (i = 1; i <= LeftTasks[0]; i++)
	{
		for (j = 1; j <= InRoutes[LeftTasks[i]][0]; j++)
		{
			RouteCandDemands[InRoutes[LeftTasks[i]][j]] += ARPTask[LeftTasks[i]].Demand;
		}
	}
	
	int SelID, AssignedRouteID;
	int n;
	for (n = 1; n <= FreeTasks[0]; n++)
	{
		/*printf("assignment\n");
  	for (i = 1; i <= NRE+NRA; i++)
	  {
  		printf("%d ", CurrTA.Assignment[i]);
	  }
  	printf("\n");
	  printf("Loads\n");
  	for (i = 1; i <= RoutesNum; i++)
  	{
  		printf("%d ", CurrTA.Loads[i]);
  	}
  	printf("\n");*/
  	
		SelID = 0;
		for (i = 1; i <= LeftTasks[0]; i++)
		{
			if (SelID == 0)
			{
				SelID = i;
			}
			else if (CandRoutes[LeftTasks[i]][0] < CandRoutes[LeftTasks[SelID]][0])
			{
				SelID = i;
			}
			else if (CandRoutes[LeftTasks[i]][0] == CandRoutes[LeftTasks[SelID]][0])
			{
				if (ARPTask[LeftTasks[i]].Demand > ARPTask[LeftTasks[SelID]].Demand)
				{
					SelID = i;
				}
			}
		}
		
		AssignedRouteID = 0;
		for (i = 1; i <= InRoutes[LeftTasks[SelID]][0]; i++)
		{
			if (AssignedRouteID == 0)
			{
				AssignedRouteID = i;
			}
			else if (CurrTA.Loads[InRoutes[LeftTasks[SelID]][i]]+ARPTask[LeftTasks[SelID]].Demand <
				CurrTA.Loads[InRoutes[LeftTasks[SelID]][AssignedRouteID]]+ARPTask[LeftTasks[SelID]].Demand)
			{
				AssignedRouteID = i;
			}
			else if (CurrTA.Loads[InRoutes[LeftTasks[SelID]][i]]+ARPTask[LeftTasks[SelID]].Demand ==
				CurrTA.Loads[InRoutes[LeftTasks[SelID]][AssignedRouteID]]+ARPTask[LeftTasks[SelID]].Demand)
			{
				if (RouteCandDemands[InRoutes[LeftTasks[SelID]][i]]+CurrTA.Loads[InRoutes[LeftTasks[SelID]][i]] >
					RouteCandDemands[InRoutes[LeftTasks[SelID]][AssignedRouteID]]+
					CurrTA.Loads[InRoutes[LeftTasks[SelID]][AssignedRouteID]])
				{
					AssignedRouteID = i;
				}
			}
		}
		
		CurrTA.Assignment[LeftTasks[SelID]] = InRoutes[LeftTasks[SelID]][AssignedRouteID];
		CurrTA.Loads[CurrTA.Assignment[LeftTasks[SelID]]] += ARPTask[LeftTasks[SelID]].Demand;
		for (i = 1; i <= InRoutes[LeftTasks[SelID]][0]; i++)
		{
			RouteCandDemands[InRoutes[LeftTasks[SelID]][i]] -= ARPTask[LeftTasks[SelID]].Demand;
		}
		
		if (CurrTA.Loads[CurrTA.Assignment[LeftTasks[SelID]]] >= Cap)
		{
			for (i = 1; i <= NRE+NRA; i++)
    	{
    		for (j = 1; j <= CandRoutes[i][0]; j++)
    		{
    			if (CandRoutes[i][j] == CurrTA.Assignment[LeftTasks[SelID]])
    			{
    				DeleteElement(CandRoutes[i], j);
    				break;
    			}
    		}
    	}
		}
		
		DeleteElement(LeftTasks, SelID);
	}
	
	CurrTA.TotalVioLoad = 0;
	for (i = 1; i <= NVeh; i++)
	{
		if (CurrTA.Loads[i] > Cap)
			CurrTA.TotalVioLoad += CurrTA.Loads[i]-Cap;
	}
	
	BestTA = CurrTA;
	
	printf("initial assignment\n");
	for (i = 1; i <= NRE+NRA; i++)
	{
		printf("%d ", CurrTA.Assignment[i]);
	}
	printf("\n");
	printf("initial Loads\n");
	for (i = 1; i <= NVeh; i++)
	{
		printf("%d ", CurrTA.Loads[i]);
	}
	printf("\n");
	printf("initial total vioload = %d\n", CurrTA.TotalVioLoad);
	
	struct AssignmentMove
	{
		int ChangedTask;
		int TargetRoute;
		int TotalVioLoad;
	};
	
	struct AssignmentMove CandMoves[100], NextMove;
	int NO_CandMoves;
	
	int TabuList[NRE+NRA+1];
	int TabuTenure = FreeTasks[0]/2;
	int TabuTask, Tabu;
	
	memset(TabuList, 0, sizeof(TabuList));
	
	int count = 0;
	while (BestTA.TotalVioLoad > 0)
	{
		count ++;
		NO_CandMoves = 0;
		CandMoves[1].TotalVioLoad = INF;
		//NextTA.TotalVioLoad = INF;
		
		if (count%10 == 0)
			printf("current = %d, best = %d\n", CurrTA.TotalVioLoad, BestTA.TotalVioLoad);
		
		for (i = 1; i <= FreeTasks[0]; i++)
		{
			for (j = 1; j <= InRoutes[FreeTasks[i]][0]; j++)
			{
				if (InRoutes[FreeTasks[i]][j] == CurrTA.Assignment[FreeTasks[i]])
					continue;
				
				NeighTA = CurrTA;
				NeighTA.Assignment[FreeTasks[i]] = InRoutes[FreeTasks[i]][j];
				NeighTA.Loads[CurrTA.Assignment[FreeTasks[i]]] -= ARPTask[FreeTasks[i]].Demand;
				NeighTA.Loads[NeighTA.Assignment[FreeTasks[i]]] += ARPTask[FreeTasks[i]].Demand;
				
				if (CurrTA.Loads[NeighTA.Assignment[FreeTasks[i]]] >= Cap)
				{
					NeighTA.TotalVioLoad += ARPTask[FreeTasks[i]].Demand;
				}
				else if (NeighTA.Loads[NeighTA.Assignment[FreeTasks[i]]] > Cap)
				{
					NeighTA.TotalVioLoad += NeighTA.Loads[NeighTA.Assignment[FreeTasks[i]]]-Cap;
				}
				
				if (NeighTA.Loads[CurrTA.Assignment[FreeTasks[i]]] >= Cap)
				{
					NeighTA.TotalVioLoad -= ARPTask[FreeTasks[i]].Demand;
				}
				else if (CurrTA.Loads[CurrTA.Assignment[FreeTasks[i]]] > Cap)
				{
					NeighTA.TotalVioLoad -= CurrTA.Loads[CurrTA.Assignment[FreeTasks[i]]]-Cap;
				}
				
				Tabu = 0;
				if (TabuList[FreeTasks[i]] > 0 && NeighTA.TotalVioLoad >= BestTA.TotalVioLoad)
					Tabu = 1;
				
				if (Tabu)
					continue;
				
				/*if (NeighTA.TotalVioLoad < NextTA.TotalVioLoad)
				{
					NextTA = NeighTA;
					TabuTask = FreeTasks[i];
				}*/
				if (NeighTA.TotalVioLoad < CandMoves[1].TotalVioLoad)
				{
					NO_CandMoves = 1;
					CandMoves[NO_CandMoves].ChangedTask = FreeTasks[i];
					CandMoves[NO_CandMoves].TargetRoute = InRoutes[FreeTasks[i]][j];
					CandMoves[NO_CandMoves].TotalVioLoad = NeighTA.TotalVioLoad;
				}
				else if (NeighTA.TotalVioLoad == CandMoves[1].TotalVioLoad)
				{
					NO_CandMoves ++;
					CandMoves[NO_CandMoves].ChangedTask = FreeTasks[i];
					CandMoves[NO_CandMoves].TargetRoute = InRoutes[FreeTasks[i]][j];
					CandMoves[NO_CandMoves].TotalVioLoad = NeighTA.TotalVioLoad;
				}
			}
		}
		
		//printf("NO_CandMoves = %d\n", NO_CandMoves);
		
		//k = RandChoose(NO_CandMoves);
		k = 1;
		TabuTask = CandMoves[k].ChangedTask;
		NextTA = CurrTA;
		NextTA.Assignment[TabuTask] = CandMoves[k].TargetRoute;
		NextTA.Loads[CurrTA.Assignment[TabuTask]] -= ARPTask[TabuTask].Demand;
		NextTA.Loads[NextTA.Assignment[TabuTask]] += ARPTask[TabuTask].Demand;
		NextTA.TotalVioLoad = CandMoves[k].TotalVioLoad;
		
		for (i = 1; i <= NRE+NRA; i++)
		{
			if (TabuList[i] > 0)
				TabuList[i] --;
		}
		
		TabuList[TabuTask] = TabuTenure;
		CurrTA = NextTA;
		
		if (CurrTA.TotalVioLoad < BestTA.TotalVioLoad)
			BestTA = CurrTA;
		
		if (count == 8000)
			break;
	}
	
	Indi->Sequence[0] = 1;
	Indi->Sequence[1] = 0;
	for (i = 1; i <= NVeh; i++)
	{
		for (j = 1; j <= NRE+NRA; j++)
		{
			int TID = j;
			if (j > NRE)
				TID = j+NRE;
			
			if (BestTA.Assignment[j] == i)
			{
				Indi->Sequence[0] ++;
				Indi->Sequence[Indi->Sequence[0]] = TID;
			}
		}
		
		Indi->Sequence[0] ++;
		Indi->Sequence[Indi->Sequence[0]] = 0;
	}
	
	Indi->TotalCost = CalcTaskSeqTotalCost(Indi->Sequence, ARPTask, MinCost);
	AssignArray(BestTA.Loads, Indi->Loads);
	Indi->TotalVioLoad = BestTA.TotalVioLoad;
	
	/*int Served[NRE+NRA+1];
	memset(Served, 0, sizeof(Served));
	
	Indi->Sequence[0] = 1;
	Indi->Sequence[1] = 0;
	
	for (i = 1; i <= RoutesNum; i++)
	{
		for (j = 1; j < NodeRoutes[i][0]; j++)
		{
  		int TID = FindTask(NodeRoutes[i][j], NodeRoutes[i][j+1], ARPTask, NO_Task);
  		int TmpTID = TID;
  		
  		if (TmpTID > NRE)
			{
				TmpTID -= NRE;
			}
			
			if (TmpTID == 0)
				continue;
			
			if (BestTA.Assignment[TmpTID] == i && !Served[TmpTID])
			{
				Served[TmpTID] = 1;
				Indi->Sequence[0] ++;
				Indi->Sequence[Indi->Sequence[0]] = TID;
			}
  	}
  	
  	if (Indi->Sequence[0] != 0)
  	{
  		Indi->Sequence[0] ++;
			Indi->Sequence[Indi->Sequence[0]] = 0;
  	}
	}
	
	for (i = BestTA.Loads[0]; i > 0; i--)
	{
		if (BestTA.Loads[i] == 0)
			DeleteElement(BestTA.Loads, i);
	}*/
	
	//GetLoads(Indi->Loads, Indi->Sequence, ARPTask);
	//Indi->TotalCost = CalcTaskSeqTotalCost(Indi->Sequence, ARPTask, MinCost);
	//AssignArray(BestTA.Loads, Indi->Loads);
	//Indi->TotalVioLoad = BestTA.TotalVioLoad;
	
	if (!Legal(Indi->Sequence, ARPTask, NRE, NRA))
	{
		printf("ERROR\n");
		exit(0);
	}
	
	printf("final assignment\n");
	for (i = 1; i <= NRE+NRA; i++)
	{
		printf("%d ", BestTA.Assignment[i]);
	}
	printf("\n");
	printf("final Loads\n");
	for (i = 1; i <= NVeh; i++)
	{
		printf("%d ", BestTA.Loads[i]);
	}
	printf("\n");
	printf("final total vioload = %d\n", BestTA.TotalVioLoad);
	
	printf("indi sequence\n");
	for (i = 1; i <= Indi->Sequence[0]; i++)
	{
		printf("%d ", Indi->Sequence[i]);
	}
	printf("\n");
	printf("indi loads\n");
	for (i = 1; i <= Indi->Loads[0]; i++)
	{
		printf("%d ", Indi->Loads[i]);
	}
	printf("\n");
	printf("indi total cost = %d, total vioload = %d\n", Indi->TotalCost, Indi->TotalVioLoad);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void PathScanning(struct Individual *PSSolution, const struct Task *ARPTask, int *ServMark, int (*MinCost)[141],
int NRE, int NRA, int NVeh, int Cap)
{
	int i, j, k;
	int NO_ServedTasks = 0;
	for (i = NRE+1; i <= 2*NRE+NRA; i++)
	{
		if (ServMark[i])
			NO_ServedTasks ++;
	}
	
	int NO_Task = 2*NRE+NRA;
	int load, trial, mindist;
	int Positions[NO_Task+1];
	
	int UnservedArc[NO_Task+1];
	int CandTask[NO_Task+1];
	int MinTask[NO_Task+1];
	int MinIsolTask[NO_Task+1];
	int MinInciTask[NO_Task+1];
	int FinalTask[NO_Task+1];
	int CurrentTask;
	int NextTask;
	
	struct Individual TmpS1, TmpS2, TmpS3, TmpS4, TmpS5, BestS;
	BestS.TotalCost = INF;
	
	int DepotDist[NO_Task+1], MaxDepotDist, MinDepotDist;
	double Yield[NO_Task+1], MaxYield, MinYield;
	
	for (i = 1; i <= NO_Task; i++)
	{
		if (!ServMark[i])
			continue;
		
		DepotDist[i] = MinCost[ARPTask[i].Head][1];
		Yield[i] = 1.0*ARPTask[i].Demand/ARPTask[i].ServCost;
	}
	
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  TmpS1.Sequence[0] = 1;
	TmpS1.Sequence[1] = 0;
	TmpS1.Loads[0] = 0;
	
	UnservedArc[0] = 0;
	for(i = 1; i <= NO_Task; i++)
	{
		if (!ServMark[i])
			continue;
		
		UnservedArc[0] ++;
		UnservedArc[UnservedArc[0]] = i;
	}
	
	load = 0;
	trial = 0;
	while (trial < NO_ServedTasks)
	{
		CurrentTask = TmpS1.Sequence[TmpS1.Sequence[0]];
		
		CandTask[0] = 0;
		
		for (i = 1; i <= UnservedArc[0]; i++)
		{
			if (ARPTask[UnservedArc[i]].Demand <= Cap-load)
			{
				CandTask[0] ++;
				CandTask[CandTask[0]] = UnservedArc[i];
			}
		}
		
		if (CandTask[0] == 0)
		{
			if (TmpS1.Loads[0] < NVeh)
			{
  			TmpS1.Sequence[0] ++;
	  		TmpS1.Sequence[TmpS1.Sequence[0]] = 0;
		  	TmpS1.Loads[0] ++;
			  TmpS1.Loads[TmpS1.Loads[0]] = load;
			  load = 0;
			  continue;
			}
			else
			{
				AssignArray(UnservedArc, CandTask);
			}
		}
		
		mindist = INF;
		MinTask[0] = 0;
		
		for (i = 1; i <= CandTask[0]; i++)
		{
			if (MinCost[ARPTask[CurrentTask].Head][ARPTask[CandTask[i]].Tail] < mindist)
			{
				mindist = MinCost[ARPTask[CurrentTask].Head][ARPTask[CandTask[i]].Tail];
				MinTask[0] = 1;
				MinTask[MinTask[0]] = CandTask[i];
			}
			else if (MinCost[ARPTask[CurrentTask].Head][ARPTask[CandTask[i]].Tail] == mindist)
			{
				MinTask[0] ++;
				MinTask[MinTask[0]] = CandTask[i];
			}
		}
		
		MinIsolTask[0] = 0;
		MinInciTask[0] = 0;
		
		for (i = 1; i <= MinTask[0]; i++)
		{
			if (ARPTask[MinTask[i]].Head == 1)
			{
				MinInciTask[0] ++;
				MinInciTask[MinInciTask[0]] = MinTask[i];
			}
			else
			{
				MinIsolTask[0] ++;
				MinIsolTask[MinIsolTask[0]] = MinTask[i];
			}
		}
		
		if (MinIsolTask[0] == 0)
		{
			AssignArray(MinInciTask, MinIsolTask);
		}
		
		MaxDepotDist = -1;
		FinalTask[0] = 0;
		for (i = 1; i <= MinIsolTask[0]; i++)
		{
			if (DepotDist[MinIsolTask[i]] > MaxDepotDist)
			{
				MaxDepotDist = DepotDist[MinIsolTask[i]];
				FinalTask[0] = 1;
				FinalTask[FinalTask[0]] = MinIsolTask[i];
			}
			else if (DepotDist[MinIsolTask[i]] == MaxDepotDist)
			{
				FinalTask[0] ++;
				FinalTask[FinalTask[0]] = MinIsolTask[i];
			}
		}
		
		k = RandChoose(FinalTask[0]);
		NextTask = FinalTask[k];
		
		trial ++;
		TmpS1.Sequence[0] ++;
		TmpS1.Sequence[TmpS1.Sequence[0]] = NextTask;
		load += ARPTask[NextTask].Demand;
		FindPositions(UnservedArc, NextTask, Positions);
		DeleteElement(UnservedArc, Positions[1]);
		
		if (ARPTask[NextTask].Inv > 0)
		{
			FindPositions(UnservedArc, ARPTask[NextTask].Inv, Positions);
			DeleteElement(UnservedArc, Positions[1]);
		}
	}
	
	//if (TmpS1.Sequence[TmpS1.Sequence[0]] != 0)
	//{
		TmpS1.Sequence[0] ++;
		TmpS1.Sequence[TmpS1.Sequence[0]] = 0;
		TmpS1.Loads[0] ++;
		TmpS1.Loads[TmpS1.Loads[0]] = load;
	//}
		
	TmpS1.TotalCost = CalcTaskSeqTotalCost(TmpS1.Sequence, ARPTask, MinCost);
	TmpS1.TotalVioLoad = GetTotalVioLoad(TmpS1.Loads, Cap);
	
	if (TmpS1.TotalCost < BestS.TotalCost)
	{
		BestS = TmpS1;
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////////
	
	TmpS2.Sequence[0] = 1;
	TmpS2.Sequence[1] = 0;
	TmpS2.Loads[0] = 0;
	
	UnservedArc[0] = 0;
	for(i = 1; i <= NO_Task; i++)
	{
		if (!ServMark[i])
			continue;
		
		UnservedArc[0] ++;
		UnservedArc[UnservedArc[0]] = i;
	}
	
	load = 0;
	trial = 0;
	while (trial < NO_ServedTasks)
	{
		CurrentTask = TmpS2.Sequence[TmpS2.Sequence[0]];
		
		CandTask[0] = 0;
		
		for (i = 1; i <= UnservedArc[0]; i++)
		{
			if (ARPTask[UnservedArc[i]].Demand <= Cap-load)
			{
				CandTask[0] ++;
				CandTask[CandTask[0]] = UnservedArc[i];
			}
		}
		
		if (CandTask[0] == 0)
		{
			if (TmpS2.Loads[0] < NVeh)
			{
  			TmpS2.Sequence[0] ++;
	  		TmpS2.Sequence[TmpS2.Sequence[0]] = 0;
		  	TmpS2.Loads[0] ++;
			  TmpS2.Loads[TmpS2.Loads[0]] = load;
			  load = 0;
			  continue;
			}
			else
			{
				AssignArray(UnservedArc, CandTask);
			}
		}
		
		mindist = INF;
		MinTask[0] = 0;
		
		for (i = 1; i <= CandTask[0]; i++)
		{
			if (MinCost[ARPTask[CurrentTask].Head][ARPTask[CandTask[i]].Tail] < mindist)
			{
				mindist = MinCost[ARPTask[CurrentTask].Head][ARPTask[CandTask[i]].Tail];
				MinTask[0] = 1;
				MinTask[MinTask[0]] = CandTask[i];
			}
			else if (MinCost[ARPTask[CurrentTask].Head][ARPTask[CandTask[i]].Tail] == mindist)
			{
				MinTask[0] ++;
				MinTask[MinTask[0]] = CandTask[i];
			}
		}
		
		MinIsolTask[0] = 0;
		MinInciTask[0] = 0;
		
		for (i = 1; i <= MinTask[0]; i++)
		{
			if (ARPTask[MinTask[i]].Head == 1)
			{
				MinInciTask[0] ++;
				MinInciTask[MinInciTask[0]] = MinTask[i];
			}
			else
			{
				MinIsolTask[0] ++;
				MinIsolTask[MinIsolTask[0]] = MinTask[i];
			}
		}
		
		if (MinIsolTask[0] == 0)
		{
			AssignArray(MinInciTask, MinIsolTask);
		}
		
		MinDepotDist = INF;
		FinalTask[0] = 0;
		for (i = 1; i <= MinIsolTask[0]; i++)
		{
			if (DepotDist[MinIsolTask[i]] < MinDepotDist)
			{
				MinDepotDist = DepotDist[MinIsolTask[i]];
				FinalTask[0] = 1;
				FinalTask[FinalTask[0]] = MinIsolTask[i];
			}
			else if (DepotDist[MinIsolTask[i]] == MinDepotDist)
			{
				FinalTask[0] ++;
				FinalTask[FinalTask[0]] = MinIsolTask[i];
			}
		}
		
		k = RandChoose(FinalTask[0]);
		NextTask = FinalTask[k];
		
		trial ++;
		TmpS2.Sequence[0] ++;
		TmpS2.Sequence[TmpS2.Sequence[0]] = NextTask;
		load += ARPTask[NextTask].Demand;
		FindPositions(UnservedArc, NextTask, Positions);
		DeleteElement(UnservedArc, Positions[1]);
		
		if (ARPTask[NextTask].Inv > 0)
		{
			FindPositions(UnservedArc, ARPTask[NextTask].Inv, Positions);
			DeleteElement(UnservedArc, Positions[1]);
		}
	}
	
	//if (TmpS2.Sequence[TmpS2.Sequence[0]] != 0)
	//{
		TmpS2.Sequence[0] ++;
		TmpS2.Sequence[TmpS2.Sequence[0]] = 0;
		TmpS2.Loads[0] ++;
		TmpS2.Loads[TmpS2.Loads[0]] = load;
	//}
		
	TmpS2.TotalCost = CalcTaskSeqTotalCost(TmpS2.Sequence, ARPTask, MinCost);
	TmpS2.TotalVioLoad = GetTotalVioLoad(TmpS2.Loads, Cap);
	
	if (TmpS2.TotalCost < BestS.TotalCost)
	{
		BestS = TmpS2;
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////////
	
	TmpS3.Sequence[0] = 1;
	TmpS3.Sequence[1] = 0;
	TmpS3.Loads[0] = 0;
	
	UnservedArc[0] = 0;
	for(i = 1; i <= NO_Task; i++)
	{
		if (!ServMark[i])
			continue;
		
		UnservedArc[0] ++;
		UnservedArc[UnservedArc[0]] = i;
	}
	
	load = 0;
	trial = 0;
	while (trial < NO_ServedTasks)
	{
		CurrentTask = TmpS3.Sequence[TmpS3.Sequence[0]];
		
		CandTask[0] = 0;
		
		for (i = 1; i <= UnservedArc[0]; i++)
		{
			if (ARPTask[UnservedArc[i]].Demand <= Cap-load)
			{
				CandTask[0] ++;
				CandTask[CandTask[0]] = UnservedArc[i];
			}
		}
		
		if (CandTask[0] == 0)
		{
			if (TmpS3.Loads[0] < NVeh)
			{
  			TmpS3.Sequence[0] ++;
	  		TmpS3.Sequence[TmpS3.Sequence[0]] = 0;
		  	TmpS3.Loads[0] ++;
			  TmpS3.Loads[TmpS3.Loads[0]] = load;
			  load = 0;
			  continue;
			}
			else
			{
				AssignArray(UnservedArc, CandTask);
			}
		}
		
		mindist = INF;
		MinTask[0] = 0;
		
		for (i = 1; i <= CandTask[0]; i++)
		{
			if (MinCost[ARPTask[CurrentTask].Head][ARPTask[CandTask[i]].Tail] < mindist)
			{
				mindist = MinCost[ARPTask[CurrentTask].Head][ARPTask[CandTask[i]].Tail];
				MinTask[0] = 1;
				MinTask[MinTask[0]] = CandTask[i];
			}
			else if (MinCost[ARPTask[CurrentTask].Head][ARPTask[CandTask[i]].Tail] == mindist)
			{
				MinTask[0] ++;
				MinTask[MinTask[0]] = CandTask[i];
			}
		}
		
		MinIsolTask[0] = 0;
		MinInciTask[0] = 0;
		
		for (i = 1; i <= MinTask[0]; i++)
		{
			if (ARPTask[MinTask[i]].Head == 1)
			{
				MinInciTask[0] ++;
				MinInciTask[MinInciTask[0]] = MinTask[i];
			}
			else
			{
				MinIsolTask[0] ++;
				MinIsolTask[MinIsolTask[0]] = MinTask[i];
			}
		}
		
		if (MinIsolTask[0] == 0)
		{
			AssignArray(MinInciTask, MinIsolTask);
		}
		
		MaxYield = -1;
		FinalTask[0] = 0;
		for (i = 1; i <= MinIsolTask[0]; i++)
		{
			if (Yield[MinIsolTask[i]] > MaxYield)
			{
				MaxYield = Yield[MinIsolTask[i]];
				FinalTask[0] = 1;
				FinalTask[FinalTask[0]] = MinIsolTask[i];
			}
			else if (Yield[MinIsolTask[i]] == MaxYield)
			{
				FinalTask[0] ++;
				FinalTask[FinalTask[0]] = MinIsolTask[i];
			}
		}
		
		k = RandChoose(FinalTask[0]);
		NextTask = FinalTask[k];
		
		trial ++;
		TmpS3.Sequence[0] ++;
		TmpS3.Sequence[TmpS3.Sequence[0]] = NextTask;
		load += ARPTask[NextTask].Demand;
		FindPositions(UnservedArc, NextTask, Positions);
		DeleteElement(UnservedArc, Positions[1]);
		
		if (ARPTask[NextTask].Inv > 0)
		{
			FindPositions(UnservedArc, ARPTask[NextTask].Inv, Positions);
			DeleteElement(UnservedArc, Positions[1]);
		}
	}
	
	//if (TmpS3.Sequence[TmpS3.Sequence[0]] != 0)
	//{
		TmpS3.Sequence[0] ++;
		TmpS3.Sequence[TmpS3.Sequence[0]] = 0;
		TmpS3.Loads[0] ++;
		TmpS3.Loads[TmpS3.Loads[0]] = load;
	//}
		
	TmpS3.TotalCost = CalcTaskSeqTotalCost(TmpS3.Sequence, ARPTask, MinCost);
	TmpS3.TotalVioLoad = GetTotalVioLoad(TmpS3.Loads, Cap);
	
	if (TmpS3.TotalCost < BestS.TotalCost)
	{
		BestS = TmpS3;
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////////
	
	TmpS4.Sequence[0] = 1;
	TmpS4.Sequence[1] = 0;
	TmpS4.Loads[0] = 0;
	
	UnservedArc[0] = 0;
	for(i = 1; i <= NO_Task; i++)
	{
		if (!ServMark[i])
			continue;
		
		UnservedArc[0] ++;
		UnservedArc[UnservedArc[0]] = i;
	}
	
	load = 0;
	trial = 0;
	while (trial < NO_ServedTasks)
	{
		CurrentTask = TmpS4.Sequence[TmpS4.Sequence[0]];
		
		CandTask[0] = 0;
		
		for (i = 1; i <= UnservedArc[0]; i++)
		{
			if (ARPTask[UnservedArc[i]].Demand <= Cap-load)
			{
				CandTask[0] ++;
				CandTask[CandTask[0]] = UnservedArc[i];
			}
		}
		
		if (CandTask[0] == 0)
		{
			if (TmpS4.Loads[0] < NVeh)
			{
  			TmpS4.Sequence[0] ++;
	  		TmpS4.Sequence[TmpS4.Sequence[0]] = 0;
		  	TmpS4.Loads[0] ++;
			  TmpS4.Loads[TmpS4.Loads[0]] = load;
			  load = 0;
			  continue;
			}
			else
			{
				AssignArray(UnservedArc, CandTask);
			}
		}
		
		mindist = INF;
		MinTask[0] = 0;
		
		for (i = 1; i <= CandTask[0]; i++)
		{
			if (MinCost[ARPTask[CurrentTask].Head][ARPTask[CandTask[i]].Tail] < mindist)
			{
				mindist = MinCost[ARPTask[CurrentTask].Head][ARPTask[CandTask[i]].Tail];
				MinTask[0] = 1;
				MinTask[MinTask[0]] = CandTask[i];
			}
			else if (MinCost[ARPTask[CurrentTask].Head][ARPTask[CandTask[i]].Tail] == mindist)
			{
				MinTask[0] ++;
				MinTask[MinTask[0]] = CandTask[i];
			}
		}
		
		MinIsolTask[0] = 0;
		MinInciTask[0] = 0;
		
		for (i = 1; i <= MinTask[0]; i++)
		{
			if (ARPTask[MinTask[i]].Head == 1)
			{
				MinInciTask[0] ++;
				MinInciTask[MinInciTask[0]] = MinTask[i];
			}
			else
			{
				MinIsolTask[0] ++;
				MinIsolTask[MinIsolTask[0]] = MinTask[i];
			}
		}
		
		if (MinIsolTask[0] == 0)
		{
			AssignArray(MinInciTask, MinIsolTask);
		}
		
		MaxYield = -1;
		FinalTask[0] = 0;
		for (i = 1; i <= MinIsolTask[0]; i++)
		{
			if (Yield[MinIsolTask[i]] > MaxYield)
			{
				MaxYield = Yield[MinIsolTask[i]];
				FinalTask[0] = 1;
				FinalTask[FinalTask[0]] = MinIsolTask[i];
			}
			else if (Yield[MinIsolTask[i]] == MaxYield)
			{
				FinalTask[0] ++;
				FinalTask[FinalTask[0]] = MinIsolTask[i];
			}
		}
		
		k = RandChoose(FinalTask[0]);
		NextTask = FinalTask[k];
		
		trial ++;
		TmpS4.Sequence[0] ++;
		TmpS4.Sequence[TmpS4.Sequence[0]] = NextTask;
		load += ARPTask[NextTask].Demand;
		FindPositions(UnservedArc, NextTask, Positions);
		DeleteElement(UnservedArc, Positions[1]);
		
		if (ARPTask[NextTask].Inv > 0)
		{
			FindPositions(UnservedArc, ARPTask[NextTask].Inv, Positions);
			DeleteElement(UnservedArc, Positions[1]);
		}
	}
	
	//if (TmpS4.Sequence[TmpS4.Sequence[0]] != 0)
	//{
		TmpS4.Sequence[0] ++;
		TmpS4.Sequence[TmpS4.Sequence[0]] = 0;
		TmpS4.Loads[0] ++;
		TmpS4.Loads[TmpS4.Loads[0]] = load;
	//}
		
	TmpS4.TotalCost = CalcTaskSeqTotalCost(TmpS4.Sequence, ARPTask, MinCost);
	TmpS4.TotalVioLoad = GetTotalVioLoad(TmpS4.Loads, Cap);
	
	if (TmpS4.TotalCost < BestS.TotalCost)
	{
		BestS = TmpS4;
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  TmpS5.Sequence[0] = 1;
	TmpS5.Sequence[1] = 0;
	TmpS5.Loads[0] = 0;
	
	UnservedArc[0] = 0;
	for(i = 1; i <= NO_Task; i++)
	{
		if (!ServMark[i])
			continue;
		
		UnservedArc[0] ++;
		UnservedArc[UnservedArc[0]] = i;
	}
	
	load = 0;
	trial = 0;
	while (trial < NO_ServedTasks)
	{
		CurrentTask = TmpS5.Sequence[TmpS5.Sequence[0]];
		
		CandTask[0] = 0;
		
		for (i = 1; i <= UnservedArc[0]; i++)
		{
			if (ARPTask[UnservedArc[i]].Demand <= Cap-load)
			{
				CandTask[0] ++;
				CandTask[CandTask[0]] = UnservedArc[i];
			}
		}
		
		if (CandTask[0] == 0)
		{
			if (TmpS5.Loads[0] < NVeh)
			{
  			TmpS5.Sequence[0] ++;
	  		TmpS5.Sequence[TmpS5.Sequence[0]] = 0;
		  	TmpS5.Loads[0] ++;
			  TmpS5.Loads[TmpS5.Loads[0]] = load;
			  load = 0;
			  continue;
			}
			else
			{
				AssignArray(UnservedArc, CandTask);
			}
		}
		
		mindist = INF;
		MinTask[0] = 0;
		
		for (i = 1; i <= CandTask[0]; i++)
		{
			if (MinCost[ARPTask[CurrentTask].Head][ARPTask[CandTask[i]].Tail] < mindist)
			{
				mindist = MinCost[ARPTask[CurrentTask].Head][ARPTask[CandTask[i]].Tail];
				MinTask[0] = 1;
				MinTask[MinTask[0]] = CandTask[i];
			}
			else if (MinCost[ARPTask[CurrentTask].Head][ARPTask[CandTask[i]].Tail] == mindist)
			{
				MinTask[0] ++;
				MinTask[MinTask[0]] = CandTask[i];
			}
		}
		
		MinIsolTask[0] = 0;
		MinInciTask[0] = 0;
		
		for (i = 1; i <= MinTask[0]; i++)
		{
			if (ARPTask[MinTask[i]].Head == 1)
			{
				MinInciTask[0] ++;
				MinInciTask[MinInciTask[0]] = MinTask[i];
			}
			else
			{
				MinIsolTask[0] ++;
				MinIsolTask[MinIsolTask[0]] = MinTask[i];
			}
		}
		
		if (MinIsolTask[0] == 0)
		{
			AssignArray(MinInciTask, MinIsolTask);
		}
		
		if (load < Cap/2)
		{
  		MaxDepotDist = -1;
	  	FinalTask[0] = 0;
		  for (i = 1; i <= MinIsolTask[0]; i++)
		  {
  			if (DepotDist[MinIsolTask[i]] > MaxDepotDist)
	  		{
		  		MaxDepotDist = DepotDist[MinIsolTask[i]];
			  	FinalTask[0] = 1;
				  FinalTask[FinalTask[0]] = MinIsolTask[i];
			  }
  			else if (DepotDist[MinIsolTask[i]] == MaxDepotDist)
	  		{
		  		FinalTask[0] ++;
			  	FinalTask[FinalTask[0]] = MinIsolTask[i];
			  }
			}
		}
		else
		{
			MinDepotDist = INF;
  		FinalTask[0] = 0;
	  	for (i = 1; i <= MinIsolTask[0]; i++)
		  {
  			if (DepotDist[MinIsolTask[i]] < MinDepotDist)
	  		{
		  		MinDepotDist = DepotDist[MinIsolTask[i]];
			  	FinalTask[0] = 1;
				  FinalTask[FinalTask[0]] = MinIsolTask[i];
			  }
  			else if (DepotDist[MinIsolTask[i]] == MinDepotDist)
	  		{
		  		FinalTask[0] ++;
			  	FinalTask[FinalTask[0]] = MinIsolTask[i];
			  }
		  }
		}
		
		k = RandChoose(FinalTask[0]);
		NextTask = FinalTask[k];
		
		trial ++;
		TmpS5.Sequence[0] ++;
		TmpS5.Sequence[TmpS5.Sequence[0]] = NextTask;
		load += ARPTask[NextTask].Demand;
		FindPositions(UnservedArc, NextTask, Positions);
		DeleteElement(UnservedArc, Positions[1]);
		
		if (ARPTask[NextTask].Inv > 0)
		{
			FindPositions(UnservedArc, ARPTask[NextTask].Inv, Positions);
			DeleteElement(UnservedArc, Positions[1]);
		}
	}
	
	//if (TmpS5.Sequence[TmpS5.Sequence[0]] != 0)
	//{
		TmpS5.Sequence[0] ++;
		TmpS5.Sequence[TmpS5.Sequence[0]] = 0;
		TmpS5.Loads[0] ++;
		TmpS5.Loads[TmpS5.Loads[0]] = load;
	//}
		
	TmpS5.TotalCost = CalcTaskSeqTotalCost(TmpS5.Sequence, ARPTask, MinCost);
	TmpS5.TotalVioLoad = GetTotalVioLoad(TmpS5.Loads, Cap);
	
	if (TmpS5.TotalCost < BestS.TotalCost)
	{
		BestS = TmpS5;
	}
	
	AssignArray(BestS.Sequence, PSSolution->Sequence);
	AssignArray(BestS.Loads, PSSolution->Loads);
	PSSolution->TotalCost = BestS.TotalCost;
	PSSolution->TotalVioLoad = BestS.TotalVioLoad;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void RandPermInit(int *RPIndi, const struct Task *ARPTask, int NRE, int NRA)
{
	int IndiLength = NRE+NRA;
	int i;
	double k;
	RandPerm(RPIndi, IndiLength);
	for (i = 1; i <= IndiLength; i++)
	{
		if (ARPTask[RPIndi[i]].Inv > 0)
		{
			k = 1.0*rand()/RAND_MAX;
			if (k < 0.5)
			{
				RPIndi[i] = ARPTask[RPIndi[i]].Inv;
			}
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void ModifiedDijkstra(int (*MinCost)[141], int (*Cost)[141], int NVer)
{
	int i, j, k, m, minimum;
	
	for (i = 0; i <= NVer; i++)
	{
		for (j = 0; j <= NVer; j++)
		{
			if (j == i)
				continue;
			
			ShortestPath[i][j][0] = 1;
			ShortestPath[i][j][1] = i;
			MinCost[i][j] = INF;
		}
	}
	
	int mark[NVer+1];
	
	int dist[NVer+1];
	int dist1[NVer+1];
	int NearestNeighbor[NVer+1];
	int UpdatedNode[NVer+1];
	
	for (i = 0; i <= NVer; i++)
	{
		mark[i] = 1;
		
		for (j = 0; j <= NVer; j++)
		{
			if (j == i)
				continue;
			
			mark[j] = 0;
			dist[j] = Cost[i][j];
			dist1[j] = dist[j];
		}
		
		for (k = 0; k < NVer; k++)
		{
			minimum = INF;
			NearestNeighbor[0] = 0;
			UpdatedNode[0] = 0;
			
			for (j = 0; j <= NVer; j++)
			{
				if (mark[j])
					continue;
					
				if (dist1[j] == INF)
					continue;
					
				if (dist1[j] < minimum)
					minimum = dist1[j];
			}
			
			if (minimum == INF)
				continue;
			
			for (j = 0; j <= NVer; j++)
			{
				if (mark[j])
					continue;
					
				if (dist1[j] == minimum)
				{
					NearestNeighbor[0] ++;
					NearestNeighbor[NearestNeighbor[0]] = j;
				}
			}
			
			int v = NearestNeighbor[1];
			dist1[v] = INF;
			mark[v] = 1;
			
			if (ShortestPath[i][v][0] == 0 || (ShortestPath[i][v][0] > 0 && ShortestPath[i][v][ShortestPath[i][v][0]] != v))
			{
				ShortestPath[i][v][0] ++;
				ShortestPath[i][v][ShortestPath[i][v][0]] = v;
			}
				
			for (j = 0; j <= NVer; j++)
			{
				if (mark[j])
					continue;
					
				if (minimum+Cost[v][j] < dist[j])
				{
					dist[j] = minimum+Cost[v][j];
					dist1[j] = minimum+Cost[v][j];
					for (m = 0; m <= ShortestPath[i][v][0]; m++)
					{
						ShortestPath[i][j][m] = ShortestPath[i][v][m];
					}
				}
			}
			
			for (j = 0; j <= NVer; j++)
			{
				if (j == i)
					continue;
				
				MinCost[i][j] = dist[j];
			}
		}		
	}
	
	for (i = 0; i <= NVer; i++)
	{
		for (j = 0; j <= NVer; j++)
		{
			if (ShortestPath[i][j][0] == 1)
				ShortestPath[i][j][0] = 0;
		}
	}
	
	for (i = 0; i <= NVer; i++)
	{
		ShortestPath[i][i][0] = 1;
		ShortestPath[i][i][1] = i;
		MinCost[i][i] = 0;
	}
}

