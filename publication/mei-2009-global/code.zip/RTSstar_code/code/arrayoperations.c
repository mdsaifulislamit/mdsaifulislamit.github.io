
#include <stdlib.h>
#include "initialization.h"
#include "arrayoperations.h"

#define INF 2100000000

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void DeleteElement(int *Array, int k)
// delete the kth element from array[1:n]
{
	int i;
	int Length = Array[0];
		
	for (i = k; i < Length; i++)
	{
		Array[i] = Array[i+1];
	}
	Array[0] --;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void AddElement(int *Array, int a, int k)
// add element 'a' to the kth position of array[1:n]
{
	int i;
	int Length = Array[0];
	
	Array[0] ++;
	for (i = Array[0]; i > k; i--)
	{
		Array[i]=  Array[i-1];
	}
	Array[k] = a;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void PMultiply(int *MultiArray, int *Array1, int *Array2)
{
	int i;
	MultiArray[0] = Array1[0];
	
	for (i = 1; i <= Array1[0]; i++)
	{
		MultiArray[i] = Array1[i]*Array2[i];
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void ReverseDirection(int *Array, int k1, int k2)
// reverse the subarray of Array[1:n] from the position k1 to position k2
{
	int i, k, tmp;
	double m = (k2-k1+1)/2;
	k = (int)m;

	for (i = k1; i < k1+k; i++)
	{
		tmp = Array[i];
		Array[i] = Array[k1+k2-i];
		Array[k1+k2-i] = tmp;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void FindPositions(int *Array, int a, int *Positions)
// find the positions of 'a' in Array[1:n]
{
	int i;
	int Length = Array[0];
	Positions[0] = 0;
	for (i = 1; i <= Length; i++)
	{
		if (Array[i] == a)
			{
				Positions[0] ++;
				Positions[Positions[0]] = i;
			}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int FindArc(int Tail, int Head, const struct Task *ARPTask, int NO_Task)
// find the task no. with Tail and Head as its tail and head
{
	int i;
	for (i = 1; i <= NO_Task; i++)
	{
		if (ARPTask[i].Tail == Tail && ARPTask[i].Head == Head)
		{
			return i;
		}
	}
	return 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int CalcTaskSeqTotalCost(int *Array, const struct Task *ARPTask, int (*MinCost)[141])
// get total cost of task sequense Array[1:n]
{
	int TotalCost = 0;
	int i;
	int Length = Array[0];
	for (i = 1; i < Length; i++)
	{
		TotalCost += MinCost[ARPTask[Array[i]].Head][ARPTask[Array[i+1]].Tail]+ARPTask[Array[i]].ServCost;
	}
	return TotalCost;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void RemoveDelimiter(int *Array)
// remove delimiters '0' of Array[1:n]
{
	int i;
	int Length = Array[0];
	int Positions[Length];
	FindPositions(Array, 0, Positions);
	for (i = Positions[0]; i > 0; i--)
	{
		DeleteElement(Array, Positions[i]);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int Split(int *SplittedArray, int *Array, const struct Task *ARPTask, int (*MinCost)[141], int Cap)
{
	int Length = Array[0];
	int i, j, k, OptCost;
	int load, cost, VNew;
	int V[Length+1];
	int P[Length+1];
	
	V[0] = 0;
	P[0] = 0;
	for (i = 1; i <= Length; i++)
	{
		V[i] = INF;
	}
	
	for (i = 1; i <= Length; i++)
	{
		load = 0;
		cost = 0;
		j = i;
		
		while (j <= Length && load <= Cap)
		{
			load += ARPTask[Array[j]].Demand;
			
			if (j == i)
			{
				cost = MinCost[1][ARPTask[Array[j]].Tail]+ARPTask[Array[j]].ServCost+MinCost[ARPTask[Array[j]].Head][1];
			}
			else
			{
				cost = cost-MinCost[ARPTask[Array[j-1]].Head][1]+MinCost[ARPTask[Array[j-1]].Head][ARPTask[Array[j]].Tail]
				+ARPTask[Array[j]].ServCost+MinCost[ARPTask[Array[j]].Head][1];
			}
			
			if (load <= Cap)
			{
				VNew = V[i-1]+cost;
				
				if (VNew < V[j])
				{
					V[j] = VNew;
					P[j] = i-1;
				}
				j++;
			}
		}
	}
	
	SplittedArray[0] = 1;
	SplittedArray[1] = 0;
	j = Length;
	i = P[j];
	while (i > 0)
	{
		for (k = i+1; k <= j; k++)
		{
			SplittedArray[0] ++;
			SplittedArray[SplittedArray[0]] = Array[k];
		}
		SplittedArray[0] ++;
		SplittedArray[SplittedArray[0]] = 0;
		
		j = i;
		i = P[j];
	}
	
	for (k = 1; k <= j; k++)
	{
		SplittedArray[0] ++;
		SplittedArray[SplittedArray[0]] = Array[k];
	}
	SplittedArray[0] ++;
	SplittedArray[SplittedArray[0]] = 0;
	
	OptCost = V[Length];
	return OptCost;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int FleetLimitedSplit(int *SplittedArray, int *Array, const struct Task *ARPTask, int (*MinCost)[141], int Cap)
{
	int i, j, k, u;
	int load, cost;
	int MaxFleet = NO_Vehicles+NO_Vehicles*0.15;
	
	int AuxiCost[Array[0]+1][Array[0]+1];
	int OptCost[Array[0]+1][MaxFleet+1], Pred[Array[0]+1][MaxFleet+1];
	int TmpArray[Array[0]+1];
	
	for (i = 0; i <= Array[0]; i++)
	{
		for (j = 0; j <= Array[0]; j++)
		{
			AuxiCost[i][j] = INF;
		}
	}
	
	for (i = 0; i <= Array[0]; i++)
	{
		for (j = 0; j <= MaxFleet; j++)
		{
			OptCost[i][j] = INF;
		}
	}
	OptCost[0][0] = 0;
	
	for (i = 0; i <= Array[0]; i++)
	{
		load = 0;
		j = i;
		
		while (j <= Array[0])
		{
			load += ARPTask[Array[j]].Demand;
			
			if (load > Cap)
				break;
			
			if (j == i)
			{
				cost = MinCost[1][ARPTask[Array[j]].Tail]+ARPTask[Array[j]].ServCost+MinCost[ARPTask[Array[j]].Head][1];
			}
			else
			{
				cost = cost-MinCost[ARPTask[Array[j-1]].Head][1]+MinCost[ARPTask[Array[j-1]].Head][ARPTask[Array[j]].Tail]
				+ARPTask[Array[j]].ServCost+MinCost[ARPTask[Array[j]].Head][1];
			}
			
			AuxiCost[i][j] = cost;
			
			j ++;
		}
	}
	
	for (i = 1; i <= MaxFleet; i++)
	{
		for (j = 1; j <= Array[0]; j++)
		{
			for (k = 0; k < j; k++)
			{
				if (OptCost[k][i-1] < INF && OptCost[k][i-1]+AuxiCost[k+1][j] < OptCost[j][i])
				{
					OptCost[j][i] = OptCost[k][i-1]+AuxiCost[k+1][j];
					Pred[j][i] = k;
				}
			}
		}
	}
	
	cost = INF;
	for (i = 1; i <= MaxFleet; i++)
	{
		if (OptCost[Array[0]][i] < cost)
		{
			cost = OptCost[Array[0]][i];
			u = i;
		}
	}
	
	if (cost == INF)
	{
		SplittedArray[0] = 0;
		return cost;
	}
	
	TmpArray[0] = 1;
	TmpArray[TmpArray[0]] = Array[0];
	while (1)
	{
		TmpArray[0] ++;
		TmpArray[TmpArray[0]] = Pred[TmpArray[TmpArray[0]-1]][u];
		u --;
		
		if (TmpArray[TmpArray[0]] == 0)
			break;
	}
	
	SplittedArray[0] = 1;
	SplittedArray[1] = 0;
	
	for (i = TmpArray[0]; i > 1; i--)
	{
		for (j = TmpArray[i]+1; j <= TmpArray[i-1]; j++)
		{
			SplittedArray[0] ++;
			SplittedArray[SplittedArray[0]] = Array[j];
		}
		
		SplittedArray[0] ++;
		SplittedArray[SplittedArray[0]] = 0;
	}
	
	return cost;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void RandPerm(int *Array, int n)
// make random permutation from 1 to n
{
	int i, k;
	int Left[n+1];
	Left[0] = n;
	for (i = 1; i <= n; i++)
	{
		Left[i] = i;
	}
	Array[0] = n;
	for (i = 1; i <= n; i++)
	{
		k = RandChoose(Left[0]);
		Array[i] = Left[k];
		DeleteElement(Left, k);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void RemoveRedundantElements(int *Array)
// remove elements that appear more than once in array[1:n]
{
	int i, j;
	int Length = Array[0];
	int Positions[Length+1];
	
	for (i = 1; i < Length; i++)
	{
		if (i == 0)
			continue;
		
		for (j = i+1; j <= Length; j++)
		{
			if (j == 0)
				continue;
			
			if (Array[j] == Array[i])
				Array[j] = 0;
		}
		
		FindPositions(Array, 0, Positions);
		
		for (i = Positions[0]; i > 0; i--)
		{
			DeleteElement(Array, Positions[i]);
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void AssignArray(int *Array1, int *Array2)
// assign array1 to array2
{
	int i;
	
	for (i = 0; i <= Array1[0]; i++)
	{
		Array2[i] = Array1[i];
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void AssignSubArray(int *Array1, int k1, int k2, int *Array2)
// assign array1[k1:k2] to array2
{
	int i;
	
	Array2[0] = k2-k1+1;
	
	for (i = k1; i <= k2; i++)
	{
		Array2[i-k1+1] = Array1[i];
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int min(int *Array)
{
	int Length = Array[0];
	int i, minimum;
	
	minimum = INF;
	for (i = 1; i <= Length; i++)
	{
		if (Array[i] < minimum)
		{
			minimum = Array[i];
		}
	}
	
	return minimum;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int max(int *Array)
{
	int Length = Array[0];
	int i, maximum;
	
	maximum = 0;
	for (i = 1; i <= Length; i++)
	{
		if (Array[i] > maximum)
		{
			maximum = Array[i];
		}
	}
	
	return maximum;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void JoinArray(int *JointArray, int *Array)
{
	int i;
	for (i = 1; i <= Array[0]; i++)
	{
		JointArray[0] ++;
		JointArray[JointArray[0]] = Array[i];
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int Legal(int *Solution, const struct Task *ARPTask, int NRE, int NRA)
{
	int i;
	int Positions[Solution[0]+1];
	int Appearance;
	int TmpSeq[Solution[0]+1];
	
	for (i = 1; i < Solution[0]; i++)
	{
		if (Solution[i] == 0 && Solution[i+1] == 0)
			return 0;
	}
	
	AssignArray(Solution, TmpSeq);
	
	RemoveDelimiter(TmpSeq);
	
	if (TmpSeq[0] < NO_ReqEdge+NO_ReqArc)
		return 0;
	
	for (i = 1; i <= TmpSeq[0]; i++)
	{
		FindPositions(TmpSeq, TmpSeq[i], Positions);
		Appearance = Positions[0];
		if (ARPTask[TmpSeq[i]].Inv > 0)
		{
			FindPositions(TmpSeq, ARPTask[TmpSeq[i]].Inv, Positions);
			Appearance += Positions[0];
		}
		
		if (Appearance > 1)
			return 0;
	}
	
	return 1;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int FindTask(int a, int b, const struct Task *ARPTask, int NO_Task)
{
	int i;
	
	for (i = 1; i <= 2*NO_ReqEdge+NO_ReqArc; i++)
	{
		if (ARPTask[i].Tail == a && ARPTask[i].Head == b)
			return i;
	}
	
	return 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int RandChoose(int n)
// randomly choose a number between 1 and n
{
	int random;
	
	random = rand();
	
	int k = random%n;
	
	k++;
	
	return k;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int Equal(int *Array1, int *Array2)
{
	int i;
	
	if (Array1[0] != Array2[0])
		return 0;
	
	for (i = 1; i <= Array1[0]; i++)
	{
		if (Array1[i] != Array2[i])
			return 0;
	}
	
	return 1;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void GetLoads(int *Loads, int *Seq, const struct Task *ARPTask)
{
	int i;
	Loads[0] = 1;
	Loads[1] = 0;
	
	for (i = 2; i < Seq[0]; i++)
	{
		if (Seq[i] == 0)
		{
			Loads[0] ++;
			Loads[Loads[0]] = 0;
			continue;
		}
		
		Loads[Loads[0]] += ARPTask[Seq[i]].Demand;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int GetTotalVioLoad(int *Loads, int Cap)
{
	int i, TotalVioLoad = 0;
	
	for (i = 1; i <= Loads[0]; i++)
	{
		if (Loads[i] > Cap)
			TotalVioLoad += Loads[i]-Cap;
	}
	
	return TotalVioLoad;
}
