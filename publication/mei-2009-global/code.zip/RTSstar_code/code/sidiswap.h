
struct Movement
{
	int MovedRoute[250];
	int Saving;
	int VioLoad;
};

struct Task;

extern int NO_ReqEdge;
extern int NO_ReqArc;
extern int NO_Vehicles;

int SingleInsertion(int *ChangedRoutesID, int *MovedTasks, struct Individual *BestSINeighbor, struct Individual *CurrSolution,
int (*TabuList)[50], int TabuTenure, const struct Task *ARPTask, double PenPrmt, double BestFitness, 
double BestFsbFitness, int (*MinCost)[141], int NRE, int NRA, int Cap, int NVeh);

int DoubleInsertion(int *ChangedRoutesID, int *MovedTasks, struct Individual *BestDINeighbor, struct Individual *CurrSolution, 
int (*TabuList)[50], int TabuTenure, const struct Task *ARPTask, double PenPrmt, double BestFitness,
double BestFsbFitness, int (*MinCost)[141], int NRE, int NRA, int Cap, int NVeh);

int SWAP(int *ChangedRoutesID, int *MovedTasks, struct Individual *BestSWAPNeighbor, struct Individual *CurrSolution, 
int (*TabuList)[50], int TabuTenure, const struct Task *ARPTask, double PenPrmt, double BestFitness, 
double BestFsbFitness, int (*MinCost)[141], int NRE, int NRA, int Cap);

void RepairInfeasibility(struct Individual *Indi, const struct Task *ARPTask, int (*MinCost)[141], int NRE, int NRA, int Cap);
