
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "initialization.h"
#include "sidiswap.h"
#include "arrayoperations.h"

#define INF 2100000000

extern int ShortestPath[141][141][141];

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int SingleInsertion(int *ChangedRoutesID, int *MovedTasks, struct Individual *BestSINeighbor, struct Individual *CurrSolution,
int (*TabuList)[50], int TabuTenure, const struct Task *ARPTask, double PenPrmt, double BestFitness, 
double BestFsbFitness, int (*MinCost)[141], int NRE, int NRA, int Cap, int NVeh)
{
	int i, j, k, u, v, w, z;
	int count = 0;
	int Besti, Bestj, Bestu, Bestv, RID1, RID2;
	int Routes[50][250], Positions[50];
	FindPositions(CurrSolution->Sequence, 0, Positions);
	Routes[0][0] = Positions[0]-1;
	for (i = 1; i < Positions[0]; i++)
	{
		AssignSubArray(CurrSolution->Sequence, Positions[i], Positions[i+1], Routes[i]);
	}
	
	struct Individual Neighbor;
	
	MovedTasks[0] = 1;
	BestSINeighbor->Fitness = INF;
	
	for (i = 1; i < Positions[0]; i++)
	{
		RID1 = i;
		
		for (j = 2; j < Routes[i][0]; j++)
		{
			for (u = 0; u < Positions[0]; u++)
			{
				if (u == i)
					continue;
				
				RID2 = u;
				
				if (u == 0 && Routes[0][0] < NVeh && Routes[i][0] > 3)
				{
					AssignArray(CurrSolution->Loads, Neighbor.Loads);
					Neighbor.Loads[i] -= ARPTask[Routes[i][j]].Demand;
					Neighbor.TotalVioLoad = CurrSolution->TotalVioLoad;
					
					if (Neighbor.Loads[i] > Cap)
					{
						Neighbor.TotalVioLoad -= ARPTask[Routes[i][j]].Demand;
					}
					else if (Neighbor.Loads[i] > Cap-ARPTask[Routes[i][j]].Demand)
					{
						Neighbor.TotalVioLoad -= Neighbor.Loads[i]+ARPTask[Routes[i][j]].Demand-Cap;
					}
					
					Neighbor.Loads[0] ++;
					Neighbor.Loads[Neighbor.Loads[0]] = ARPTask[Routes[i][j]].Demand;
					
					if (Neighbor.Loads[Neighbor.Loads[0]] > Cap)
					{
						Neighbor.TotalVioLoad += Neighbor.Loads[Neighbor.Loads[0]]-Cap;
					}
					
					Neighbor.TotalCost = CurrSolution->TotalCost-MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[Routes[i][j]].Tail]
					-MinCost[ARPTask[Routes[i][j]].Head][ARPTask[Routes[i][j+1]].Tail]
					+MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[Routes[i][j+1]].Tail]
					+MinCost[1][ARPTask[Routes[i][j]].Tail]+MinCost[ARPTask[Routes[i][j]].Head][1];
					
					/*if (Neighbor.TotalCost < BestFsbFitness && Neighbor.TotalVioLoad > 0)
					{
						AssignArray(CurrSolution->Sequence, Neighbor.Sequence);
						int p = 0;
						for (k = 1; k < i; k++)
						{
							p += Routes[k][0];
							p --;
						}
						p += j;
						
						DeleteElement(Neighbor.Sequence, p);
						Neighbor.Sequence[0] ++;
						Neighbor.Sequence[Neighbor.Sequence[0]] = CurrSolution->Sequence[p];
						Neighbor.Sequence[0] ++;
						Neighbor.Sequence[Neighbor.Sequence[0]] = 0;
						
						RepairInfeasibility(&Neighbor, ARPTask, MinCost, NRE, NRA, Cap);
					}*/
					
					count ++;
					Neighbor.Fitness = Neighbor.TotalCost+PenPrmt*Neighbor.TotalVioLoad;
					
					if (TabuList[Routes[i][j]][u] == 0 || (Neighbor.TotalVioLoad > 0 && Neighbor.Fitness < BestFitness)
						|| (Neighbor.TotalVioLoad == 0 && Neighbor.Fitness < BestFsbFitness))
					{
  					if (Neighbor.Fitness < BestSINeighbor->Fitness)
	   				{
	 	  				MovedTasks[1] = Routes[i][j];
	 		  			Besti = i;
	 			  		Bestj = j;
	 				  	Bestu = u;
	 					  Bestv = 0;
	 					  ChangedRoutesID[0] = RID1;
	 					  ChangedRoutesID[1] = RID2;
  				    
	  	  			BestSINeighbor->TotalCost = Neighbor.TotalCost;
  			  		AssignArray(Neighbor.Loads, BestSINeighbor->Loads);
	  			  	BestSINeighbor->TotalVioLoad = Neighbor.TotalVioLoad;
		  			  BestSINeighbor->Fitness = Neighbor.Fitness;
			  	  }
				  }
				}
  				
				if (u == 0)
					continue;
				
				for (v = 2; v <= Routes[u][0]; v++)
				{
					//if (ARPTask[Routes[u][v-1]].Head == ARPTask[Routes[u][v]].Tail)
					//	continue;
		  		
		  		if (u == i && v == j)
		  			continue;
		  		
					AssignArray(CurrSolution->Loads, Neighbor.Loads);
					Neighbor.Loads[i] -= ARPTask[Routes[i][j]].Demand;
					Neighbor.Loads[u] += ARPTask[Routes[i][j]].Demand;
					Neighbor.TotalVioLoad = CurrSolution->TotalVioLoad;
					
					if (Neighbor.Loads[i] > Cap)
					{
						Neighbor.TotalVioLoad -= ARPTask[Routes[i][j]].Demand;
					}
					else if (Neighbor.Loads[i] > Cap-ARPTask[Routes[i][j]].Demand)
					{
						Neighbor.TotalVioLoad -= Neighbor.Loads[i]+ARPTask[Routes[i][j]].Demand-Cap;
					}
					
					if (Neighbor.Loads[u] > Cap+ARPTask[Routes[i][j]].Demand)
					{
						Neighbor.TotalVioLoad += ARPTask[Routes[i][j]].Demand;
					}
					else if (Neighbor.Loads[u] > Cap)
					{
						Neighbor.TotalVioLoad += Neighbor.Loads[u]-Cap;
					}
					
					if (Neighbor.Loads[i] == 0)
					{
						RID1 = 0;
						DeleteElement(Neighbor.Loads, i);
					}
					
					Neighbor.TotalCost = CurrSolution->TotalCost-MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[Routes[i][j]].Tail]
					-MinCost[ARPTask[Routes[i][j]].Head][ARPTask[Routes[i][j+1]].Tail]
					-MinCost[ARPTask[Routes[u][v-1]].Head][ARPTask[Routes[u][v]].Tail]
					+MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[Routes[i][j+1]].Tail]
					+MinCost[ARPTask[Routes[u][v-1]].Head][ARPTask[Routes[i][j]].Tail]
					+MinCost[ARPTask[Routes[i][j]].Head][ARPTask[Routes[u][v]].Tail];
					
					/*if (Neighbor.TotalCost < BestFsbFitness && Neighbor.TotalVioLoad > 0)
					{
						AssignArray(CurrSolution->Sequence, Neighbor.Sequence);
						int p = 0;
						for (k = 1; k < i; k++)
						{
							p += Routes[k][0];
							p --;
						}
						p += j;
						
						int q = 0;
						for (k = 1; k < u; k++)
						{
							q += Routes[k][0];
							q --;
						}
						q += v;
						
						DeleteElement(Neighbor.Sequence, p);
						if (q > p)
						{
							AddElement(Neighbor.Sequence, CurrSolution->Sequence[p], q-1);
						}
						else
						{
							AddElement(Neighbor.Sequence, CurrSolution->Sequence[p], q);
						}
						
						RepairInfeasibility(&Neighbor, ARPTask, MinCost, NRE, NRA, Cap);
					}*/
					
					count ++;
					Neighbor.Fitness = Neighbor.TotalCost+PenPrmt*Neighbor.TotalVioLoad;
					
					if (TabuList[Routes[i][j]][u] == 0 || (Neighbor.TotalVioLoad > 0 && Neighbor.Fitness < BestFitness)
						|| (Neighbor.TotalVioLoad == 0 && Neighbor.Fitness < BestFsbFitness))
					{
  					if (Neighbor.Fitness < BestSINeighbor->Fitness)
	   				{
	 	  				MovedTasks[1] = Routes[i][j];
	 		  			Besti = i;
	 			  		Bestj = j;
	 				  	Bestu = u;
	 					  Bestv = v;
	 					  ChangedRoutesID[0] = RID1;
	 					  ChangedRoutesID[1] = RID2;
				      
  		  			BestSINeighbor->TotalCost = Neighbor.TotalCost;
	  		  		AssignArray(Neighbor.Loads, BestSINeighbor->Loads);
		  		  	BestSINeighbor->TotalVioLoad = Neighbor.TotalVioLoad;
			  		  BestSINeighbor->Fitness = Neighbor.Fitness;
				    }
					}
					
					z = ARPTask[Routes[i][j]].Inv;
					
					Neighbor.TotalCost = CurrSolution->TotalCost-MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[Routes[i][j]].Tail]
					-MinCost[ARPTask[Routes[i][j]].Head][ARPTask[Routes[i][j+1]].Tail]
					-MinCost[ARPTask[Routes[u][v-1]].Head][ARPTask[Routes[u][v]].Tail]
					+MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[Routes[i][j+1]].Tail]
					+MinCost[ARPTask[Routes[u][v-1]].Head][ARPTask[z].Tail]+MinCost[ARPTask[z].Head][ARPTask[Routes[u][v]].Tail];
					
					/*if (Neighbor.TotalCost < BestFsbFitness && Neighbor.TotalVioLoad > 0)
					{
						AssignArray(CurrSolution->Sequence, Neighbor.Sequence);
						int p = 0;
						for (k = 1; k < i; k++)
						{
							p += Routes[k][0];
							p --;
						}
						p += j;
						
						int q = 0;
						for (k = 1; k < u; k++)
						{
							q += Routes[k][0];
							q --;
						}
						q += v;
						
						DeleteElement(Neighbor.Sequence, p);
						if (q > p)
						{
							AddElement(Neighbor.Sequence, CurrSolution->Sequence[p], q-1);
						}
						else
						{
							AddElement(Neighbor.Sequence, CurrSolution->Sequence[p], q);
						}
						
						printf("current\n");
						for (k = 1; k <= CurrSolution->Sequence[0]; k++)
						{
							printf("%d ", CurrSolution->Sequence[k]);
						}
						printf("\n");
						printf("i = %d, j = %d, p = %d, u = %d, v = %d, q = %d\n", i, j, p, u, v, q);
						printf("neighbor\n");
						for (k = 1; k <= Neighbor.Sequence[0]; k++)
						{
							printf("%d ", Neighbor.Sequence[k]);
						}
						printf("\n");
						RepairInfeasibility(&Neighbor, ARPTask, MinCost, NRE, NRA, Cap);
					}*/
					
					count ++;
					Neighbor.Fitness = Neighbor.TotalCost+PenPrmt*Neighbor.TotalVioLoad;
					
					if (TabuList[Routes[i][j]][u] == 0 || (Neighbor.TotalVioLoad > 0 && Neighbor.Fitness < BestFitness)
						|| (Neighbor.TotalVioLoad == 0 && Neighbor.Fitness < BestFsbFitness))
					{
  					if (Neighbor.Fitness < BestSINeighbor->Fitness)
	   				{
	 	  				MovedTasks[1] = z;
	 		  			Besti = i;
	 			  		Bestj = j;
	 				  	Bestu = u;
	 					  Bestv = v;
	 					  ChangedRoutesID[0] = RID1;
	 					  ChangedRoutesID[1] = RID2;
				      
  		  			BestSINeighbor->TotalCost = Neighbor.TotalCost;
	  		  		AssignArray(Neighbor.Loads, BestSINeighbor->Loads);
		  		  	BestSINeighbor->TotalVioLoad = Neighbor.TotalVioLoad;
			  		  BestSINeighbor->Fitness = Neighbor.Fitness;
			  		}
				  }
			  }
		  }
		}
	}
	
	if (Bestu == 0)
	{
		BestSINeighbor->Sequence[0] = 1;
		
		for (k = 1; k < Positions[0]; k++)
	  {
  		if (k == Besti)
			{
				DeleteElement(Routes[k], Bestj);
  			BestSINeighbor->Sequence[0] --;
				JoinArray(BestSINeighbor->Sequence, Routes[k]);
			}
  		else
			{
			  BestSINeighbor->Sequence[0] --;
		  	JoinArray(BestSINeighbor->Sequence, Routes[k]);
		  }
		}
	 	
		BestSINeighbor->Sequence[0] ++;
		BestSINeighbor->Sequence[BestSINeighbor->Sequence[0]] = MovedTasks[1];
		BestSINeighbor->Sequence[0] ++;
		BestSINeighbor->Sequence[BestSINeighbor->Sequence[0]] = 0;
	}
	else
	{
		BestSINeighbor->Sequence[0] = 1;
		
		for (k = 1; k < Positions[0]; k++)
		{
  		if (k == Besti)
			{
				DeleteElement(Routes[k], Bestj);
				if (Routes[k][0] == 2)
	  			continue;
			  
				BestSINeighbor->Sequence[0] --;
				JoinArray(BestSINeighbor->Sequence, Routes[k]);
			}
			else if (k == Bestu)
 			{
  			AddElement(Routes[k], MovedTasks[1], Bestv);
	  		BestSINeighbor->Sequence[0] --;
		  	JoinArray(BestSINeighbor->Sequence, Routes[k]);
		  }
			else
			{
			  BestSINeighbor->Sequence[0] --;
		  	JoinArray(BestSINeighbor->Sequence, Routes[k]);
 		  }
  	}
	}
	
	return count;
	
	/*if (PenPrmt > 1000)
	{
		printf("besti = %d, bestj = %d, bestu = %d, bestv = %d, total vioload = %d\n", Besti, Bestj, Bestu, Bestv, BestSINeighbor->TotalVioLoad);
		printf("best neighbor loads\n");
		for (i = 1; i <= BestSINeighbor->Loads[0]; i++)
		{
			printf("%d ", BestSINeighbor->Loads[i]);
		}
		printf("\n");
		printf("NVeh = %d\n", NVeh);
		exit(0);
	}*/
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int DoubleInsertion(int *ChangedRoutesID, int *MovedTasks, struct Individual *BestDINeighbor, struct Individual *CurrSolution, 
int (*TabuList)[50], int TabuTenure, const struct Task *ARPTask, double PenPrmt, double BestFitness,
double BestFsbFitness, int (*MinCost)[141], int NRE, int NRA, int Cap, int NVeh)
{
	int i, j, k, u, v, w, z, m;
	int count = 0;
	int Besti, Bestj, Bestu, Bestv, RID1, RID2;
	int Routes[50][250], Positions[50];
	FindPositions(CurrSolution->Sequence, 0, Positions);
	Routes[0][0] = Positions[0]-1;
	for (i = 1; i < Positions[0]; i++)
	{
		AssignSubArray(CurrSolution->Sequence, Positions[i], Positions[i+1], Routes[i]);
	}
	
	struct Individual Neighbor;
	
	MovedTasks[0] = 2;
	BestDINeighbor->Fitness = INF;
	
	for (i = 1; i < Positions[0]; i++)
	{
		if (Routes[i][0] < 4)
			continue;
		
		RID1 = i;
		
		for (j = 2; j < Routes[i][0]-1; j++)
		{
			for (u = 0; u < Positions[0]; u++)
			{
				if (u == i)
					continue;
				
				RID2 = u;
				
				if (u == 0 && Routes[0][0] < NVeh && Routes[i][0] > 4)
				{
					AssignArray(CurrSolution->Loads, Neighbor.Loads);
					Neighbor.Loads[i] -= ARPTask[Routes[i][j]].Demand+ARPTask[Routes[i][j+1]].Demand;
					Neighbor.TotalVioLoad = CurrSolution->TotalVioLoad;
					
					if (Neighbor.Loads[i] > Cap)
					{
						Neighbor.TotalVioLoad -= ARPTask[Routes[i][j]].Demand+ARPTask[Routes[i][j+1]].Demand;
					}
					else if (Neighbor.Loads[i] > Cap-ARPTask[Routes[i][j]].Demand-ARPTask[Routes[i][j+1]].Demand)
					{
						Neighbor.TotalVioLoad -= Neighbor.Loads[i]+ARPTask[Routes[i][j]].Demand+ARPTask[Routes[i][j+1]].Demand-Cap;
					}
					
					Neighbor.Loads[0] ++;
					Neighbor.Loads[Neighbor.Loads[0]] = ARPTask[Routes[i][j]].Demand+ARPTask[Routes[i][j+1]].Demand;
					
					if (Neighbor.Loads[Neighbor.Loads[0]] > Cap)
					{
						Neighbor.TotalVioLoad += Neighbor.Loads[Neighbor.Loads[0]]-Cap;
					}
					
					Neighbor.TotalCost = CurrSolution->TotalCost-MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[Routes[i][j]].Tail]
					-MinCost[ARPTask[Routes[i][j+1]].Head][ARPTask[Routes[i][j+2]].Tail]
					+MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[Routes[i][j+2]].Tail]
					+MinCost[1][ARPTask[Routes[i][j]].Tail]+MinCost[ARPTask[Routes[i][j+1]].Head][1];
					
					/*if (Neighbor.TotalCost < BestFsbFitness && Neighbor.TotalVioLoad > 0)
					{
						RepairInfeasibility(&Neighbor, ARPTask, MinCost, NRE, NRA, Cap);
					}*/
					
					count ++;
					Neighbor.Fitness = Neighbor.TotalCost+PenPrmt*Neighbor.TotalVioLoad;
					
					if (TabuList[Routes[i][j]][u] == 0 || TabuList[Routes[i][j+1]][u] == 0 || (Neighbor.TotalVioLoad > 0 
						&& Neighbor.Fitness < BestFitness)	|| (Neighbor.TotalVioLoad == 0 && Neighbor.Fitness < BestFsbFitness))
					{
  					if (Neighbor.Fitness < BestDINeighbor->Fitness)
	  				{
		  				MovedTasks[1] = Routes[i][j];
			  	  	MovedTasks[2] = Routes[i][j+1];
				    	Besti = i;
	 				  	Bestj = j;
	 					  Bestu = u;
	 					  Bestv = v;
	 					  ChangedRoutesID[0] = RID1;
				  		ChangedRoutesID[1] = RID2;
  					  
  				  	BestDINeighbor->TotalCost = Neighbor.TotalCost;
    					AssignArray(Neighbor.Loads, BestDINeighbor->Loads);
	    				BestDINeighbor->TotalVioLoad = Neighbor.TotalVioLoad;
		 	  			BestDINeighbor->Fitness = Neighbor.Fitness;
				  	}
				  }
					
					
					w = ARPTask[Routes[i][j]].Inv;
					
					Neighbor.TotalCost = CurrSolution->TotalCost-MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[Routes[i][j]].Tail]
					-MinCost[ARPTask[Routes[i][j]].Head][ARPTask[Routes[i][j+1]].Tail]
					-MinCost[ARPTask[Routes[i][j+1]].Head][ARPTask[Routes[i][j+2]].Tail]
					+MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[Routes[i][j+2]].Tail]
					+MinCost[1][ARPTask[w].Tail]+MinCost[ARPTask[w].Head][ARPTask[Routes[i][j+1]].Tail]
					+MinCost[ARPTask[Routes[i][j+1]].Head][1];
					
					/*if (Neighbor.TotalCost < BestFsbFitness && Neighbor.TotalVioLoad > 0)
					{
						RepairInfeasibility(&Neighbor, ARPTask, MinCost, NRE, NRA, Cap);
					}*/
					
					count ++;
					Neighbor.Fitness = Neighbor.TotalCost+PenPrmt*Neighbor.TotalVioLoad;
					
					if (TabuList[Routes[i][j]][u] == 0 || TabuList[Routes[i][j+1]][u] == 0 || (Neighbor.TotalVioLoad > 0 
						&& Neighbor.Fitness < BestFitness)	|| (Neighbor.TotalVioLoad == 0 && Neighbor.Fitness < BestFsbFitness))
					{
  					if (Neighbor.Fitness < BestDINeighbor->Fitness)
	  				{
		  				MovedTasks[1] = w;
			  	  	MovedTasks[2] = Routes[i][j+1];
				    	Besti = i;
	 				  	Bestj = j;
	 					  Bestu = u;
	 					  Bestv = v;
  					  ChangedRoutesID[0] = RID1;
				  		ChangedRoutesID[1] = RID2;
  					  
  				  	BestDINeighbor->TotalCost = Neighbor.TotalCost;
    					AssignArray(Neighbor.Loads, BestDINeighbor->Loads);
	    				BestDINeighbor->TotalVioLoad = Neighbor.TotalVioLoad;
		 	  			BestDINeighbor->Fitness = Neighbor.Fitness;
				  	}
				  }
				}
				
				if (u == 0)
					continue;
				
				for (v = 2; v <= Routes[u][0]; v++)
				{
					//if (ARPTask[Routes[u][v-1]].Head == ARPTask[Routes[u][v]].Tail)
					//	continue;
					
					if (u == i && v == j)
						continue;
					
					AssignArray(CurrSolution->Loads, Neighbor.Loads);
					Neighbor.Loads[i] -= ARPTask[Routes[i][j]].Demand+ARPTask[Routes[i][j+1]].Demand;
					Neighbor.Loads[u] += ARPTask[Routes[i][j]].Demand+ARPTask[Routes[i][j+1]].Demand;			
					Neighbor.TotalVioLoad = CurrSolution->TotalVioLoad;
					
					if (Neighbor.Loads[i] > Cap)
					{
						Neighbor.TotalVioLoad -= ARPTask[Routes[i][j]].Demand+ARPTask[Routes[i][j+1]].Demand;
					}
					else if (Neighbor.Loads[i] > Cap-ARPTask[Routes[i][j]].Demand-ARPTask[Routes[i][j+1]].Demand)
					{
						Neighbor.TotalVioLoad -= Neighbor.Loads[i]+ARPTask[Routes[i][j]].Demand+ARPTask[Routes[i][j+1]].Demand-Cap;
					}
					
					if (Neighbor.Loads[u] > Cap+ARPTask[Routes[i][j]].Demand+ARPTask[Routes[i][j+1]].Demand)
					{
						Neighbor.TotalVioLoad += ARPTask[Routes[i][j]].Demand+ARPTask[Routes[i][j+1]].Demand;
					}
					else if (Neighbor.Loads[u] > Cap)
					{
						Neighbor.TotalVioLoad += Neighbor.Loads[u]-Cap;
					}
					
					if (Neighbor.Loads[i] == 0)
					{
						RID1 = 0;
						DeleteElement(Neighbor.Loads, i);
					}
					
					Neighbor.TotalCost = CurrSolution->TotalCost-MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[Routes[i][j]].Tail]
					-MinCost[ARPTask[Routes[i][j+1]].Head][ARPTask[Routes[i][j+2]].Tail]
					-MinCost[ARPTask[Routes[u][v-1]].Head][ARPTask[Routes[u][v]].Tail]
					+MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[Routes[i][j+2]].Tail]
					+MinCost[ARPTask[Routes[u][v-1]].Head][ARPTask[Routes[i][j]].Tail]
					+MinCost[ARPTask[Routes[i][j+1]].Head][ARPTask[Routes[u][v]].Tail];
					
					/*if (Neighbor.TotalCost < BestFsbFitness && Neighbor.TotalVioLoad > 0)
					{
						RepairInfeasibility(&Neighbor, ARPTask, MinCost, NRE, NRA, Cap);
					}*/
					
					count ++;
					Neighbor.Fitness = Neighbor.TotalCost+PenPrmt*Neighbor.TotalVioLoad;
					
					if (TabuList[Routes[i][j]][u] == 0 || TabuList[Routes[i][j+1]][u] == 0 || (Neighbor.TotalVioLoad > 0 
						&& Neighbor.Fitness < BestFitness)	|| (Neighbor.TotalVioLoad == 0 && Neighbor.Fitness < BestFsbFitness))
					{
  					if (Neighbor.Fitness < BestDINeighbor->Fitness)
	  				{
		  				MovedTasks[1] = Routes[i][j];
			  	  	MovedTasks[2] = Routes[i][j+1];
				    	Besti = i;
	 				  	Bestj = j;
	 					  Bestu = u;
	 					  Bestv = v;
  					  ChangedRoutesID[0] = RID1;
				  		ChangedRoutesID[1] = RID2;
  					  
  				  	BestDINeighbor->TotalCost = Neighbor.TotalCost;
    					AssignArray(Neighbor.Loads, BestDINeighbor->Loads);
	    				BestDINeighbor->TotalVioLoad = Neighbor.TotalVioLoad;
		 	  			BestDINeighbor->Fitness = Neighbor.Fitness;
				  	}
					}
					
					
					w = ARPTask[Routes[i][j]].Inv;
					
					Neighbor.TotalCost = CurrSolution->TotalCost-MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[Routes[i][j]].Tail]
					-MinCost[ARPTask[Routes[i][j]].Head][ARPTask[Routes[i][j+1]].Tail]
					-MinCost[ARPTask[Routes[i][j+1]].Head][ARPTask[Routes[i][j+2]].Tail]
					-MinCost[ARPTask[Routes[u][v-1]].Head][ARPTask[Routes[u][v]].Tail]
					+MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[Routes[i][j+2]].Tail]
					+MinCost[ARPTask[Routes[u][v-1]].Head][ARPTask[w].Tail]+MinCost[ARPTask[w].Head][ARPTask[Routes[i][j+1]].Tail]
					+MinCost[ARPTask[Routes[i][j+1]].Head][ARPTask[Routes[u][v]].Tail];
					
					/*if (Neighbor.TotalCost < BestFsbFitness && Neighbor.TotalVioLoad > 0)
					{
						RepairInfeasibility(&Neighbor, ARPTask, MinCost, NRE, NRA, Cap);
					}*/
					
					count ++;
					Neighbor.Fitness = Neighbor.TotalCost+PenPrmt*Neighbor.TotalVioLoad;
					
					if (TabuList[Routes[i][j]][u] == 0 || TabuList[Routes[i][j+1]][u] == 0 || (Neighbor.TotalVioLoad > 0 
						&& Neighbor.Fitness < BestFitness)	|| (Neighbor.TotalVioLoad == 0 && Neighbor.Fitness < BestFsbFitness))
					{
  					if (Neighbor.Fitness < BestDINeighbor->Fitness)
	  				{
		  				MovedTasks[1] = w;
			  	  	MovedTasks[2] = Routes[i][j+1];
				    	Besti = i;
	 				  	Bestj = j;
	 					  Bestu = u;
	 					  Bestv = v;
  					  ChangedRoutesID[0] = RID1;
				  		ChangedRoutesID[1] = RID2;
  					  
  				  	BestDINeighbor->TotalCost = Neighbor.TotalCost;
    					AssignArray(Neighbor.Loads, BestDINeighbor->Loads);
	    				BestDINeighbor->TotalVioLoad = Neighbor.TotalVioLoad;
		 	  			BestDINeighbor->Fitness = Neighbor.Fitness;
				  	}
				  }
					
					
					z = ARPTask[Routes[i][j+1]].Inv;
					
					Neighbor.TotalCost = CurrSolution->TotalCost-MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[Routes[i][j]].Tail]
					-MinCost[ARPTask[Routes[i][j]].Head][ARPTask[Routes[i][j+1]].Tail]
					-MinCost[ARPTask[Routes[i][j+1]].Head][ARPTask[Routes[i][j+2]].Tail]
					-MinCost[ARPTask[Routes[u][v-1]].Head][ARPTask[Routes[u][v]].Tail]
					+MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[Routes[i][j+2]].Tail]
					+MinCost[ARPTask[Routes[u][v-1]].Head][ARPTask[Routes[i][j]].Tail]
					+MinCost[ARPTask[Routes[i][j]].Head][ARPTask[z].Tail]+MinCost[ARPTask[z].Head][ARPTask[Routes[u][v]].Tail];
					
					/*if (Neighbor.TotalCost < BestFsbFitness && Neighbor.TotalVioLoad > 0)
					{
						RepairInfeasibility(&Neighbor, ARPTask, MinCost, NRE, NRA, Cap);
					}*/
					
					count ++;
					Neighbor.Fitness = Neighbor.TotalCost+PenPrmt*Neighbor.TotalVioLoad;
					
					if (TabuList[Routes[i][j]][u] == 0 || TabuList[Routes[i][j+1]][u] == 0 || (Neighbor.TotalVioLoad > 0 
						&& Neighbor.Fitness < BestFitness)	|| (Neighbor.TotalVioLoad == 0 && Neighbor.Fitness < BestFsbFitness))
					{
  					if (Neighbor.Fitness < BestDINeighbor->Fitness)
	  				{
		  				MovedTasks[1] = Routes[i][j];
		  		  	MovedTasks[2] = z;
			  	  	Besti = i;
	 			  		Bestj = j;
	 				  	Bestu = u;
	 					  Bestv = v;
	 					  ChangedRoutesID[0] = RID1;
				  		ChangedRoutesID[1] = RID2;
    					
		  		  	BestDINeighbor->TotalCost = Neighbor.TotalCost;
  		  			AssignArray(Neighbor.Loads, BestDINeighbor->Loads);
	  		  		BestDINeighbor->TotalVioLoad = Neighbor.TotalVioLoad;
		 			  	BestDINeighbor->Fitness = Neighbor.Fitness;
					  }
					}
					
					
					Neighbor.TotalCost = CurrSolution->TotalCost-MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[Routes[i][j]].Tail]
					-MinCost[ARPTask[Routes[i][j]].Head][ARPTask[Routes[i][j+1]].Tail]
					-MinCost[ARPTask[Routes[i][j+1]].Head][ARPTask[Routes[i][j+2]].Tail]
					-MinCost[ARPTask[Routes[u][v-1]].Head][ARPTask[Routes[u][v]].Tail]
					+MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[Routes[i][j+2]].Tail]
					+MinCost[ARPTask[Routes[u][v-1]].Head][ARPTask[w].Tail]+MinCost[ARPTask[w].Head][ARPTask[z].Tail]
					+MinCost[ARPTask[z].Head][ARPTask[Routes[u][v]].Tail];
					
					/*if (Neighbor.TotalCost < BestFsbFitness && Neighbor.TotalVioLoad > 0)
					{
						RepairInfeasibility(&Neighbor, ARPTask, MinCost, NRE, NRA, Cap);
					}*/
					
					count ++;
					Neighbor.Fitness = Neighbor.TotalCost+PenPrmt*Neighbor.TotalVioLoad;
					
					if (TabuList[Routes[i][j]][u] == 0 || TabuList[Routes[i][j+1]][u] == 0 || (Neighbor.TotalVioLoad > 0 
						&& Neighbor.Fitness < BestFitness)	|| (Neighbor.TotalVioLoad == 0 && Neighbor.Fitness < BestFsbFitness))
					{
  					if (Neighbor.Fitness < BestDINeighbor->Fitness)
	  				{
	  					MovedTasks[1] = w;
		  		  	MovedTasks[2] = z;
			  	  	Besti = i;
	 			  		Bestj = j;
	 				  	Bestu = u;
	 					  Bestv = v;
  					  ChangedRoutesID[0] = RID1;
				  		ChangedRoutesID[1] = RID2;
				  		
  				  	BestDINeighbor->TotalCost = Neighbor.TotalCost;
    					AssignArray(Neighbor.Loads, BestDINeighbor->Loads);
	    				BestDINeighbor->TotalVioLoad = Neighbor.TotalVioLoad;
		 	  			BestDINeighbor->Fitness = Neighbor.Fitness;
				  	}
				  }
				}
			}
		}
	}
	
	if (Bestu == 0)
	{
		BestDINeighbor->Sequence[0] = 1;
		
		for (k = 1; k < Positions[0]; k++)
	  {
			if (k == Besti)
			{
				DeleteElement(Routes[k], Bestj+1);
				DeleteElement(Routes[k], Bestj);
				BestDINeighbor->Sequence[0] --;
				JoinArray(BestDINeighbor->Sequence, Routes[k]);
			}
			else
			{
 			  BestDINeighbor->Sequence[0] --;
  	  	JoinArray(BestDINeighbor->Sequence, Routes[k]);
	    }
	  }
	  
	  BestDINeighbor->Sequence[0] ++;
		BestDINeighbor->Sequence[BestDINeighbor->Sequence[0]] = MovedTasks[1];
		BestDINeighbor->Sequence[0] ++;
		BestDINeighbor->Sequence[BestDINeighbor->Sequence[0]] = MovedTasks[2];
		BestDINeighbor->Sequence[0] ++;
		BestDINeighbor->Sequence[BestDINeighbor->Sequence[0]] = 0;
	}
	else
	{
		BestDINeighbor->Sequence[0] = 1;
		
		for (k = 1; k < Positions[0]; k++)
		{
  		if (k == Besti)
	  	{
				DeleteElement(Routes[k], Bestj+1);
				DeleteElement(Routes[k], Bestj);
				if (Routes[k][0] == 2)
		  		continue;
					
				BestDINeighbor->Sequence[0] --;
				JoinArray(BestDINeighbor->Sequence, Routes[k]);
			}
 			else if (k == Bestu)
  		{
	  		AddElement(Routes[k], MovedTasks[2], Bestv);
		  	AddElement(Routes[k], MovedTasks[1], Bestv);
			  BestDINeighbor->Sequence[0] --;
				JoinArray(BestDINeighbor->Sequence, Routes[k]);
			}
			else
			{
 			  BestDINeighbor->Sequence[0] --;
  	  	JoinArray(BestDINeighbor->Sequence, Routes[k]);
	    }
	  }
	}
	
	return count;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int SWAP(int *ChangedRoutesID, int *MovedTasks, struct Individual *BestSWAPNeighbor, struct Individual *CurrSolution, 
int (*TabuList)[50], int TabuTenure, const struct Task *ARPTask, double PenPrmt, double BestFitness, 
double BestFsbFitness, int (*MinCost)[141], int NRE, int NRA, int Cap)
{
	int i, j, k, u, v, w, z;
	int count = 0;
	int Besti, Bestj, Bestu, Bestv, RID1, RID2;
	int Routes[50][250], Positions[50], FHRoute[250];
	FindPositions(CurrSolution->Sequence, 0, Positions);
	Routes[0][0] = Positions[0]-1;
	for (i = 1; i < Positions[0]; i++)
	{
		AssignSubArray(CurrSolution->Sequence, Positions[i], Positions[i+1], Routes[i]);
	}
	
	struct Individual Neighbor;
	
	MovedTasks[0] = 2;
	BestSWAPNeighbor->Fitness = INF;
	
	/*if (PenPrmt > 1000)
	{
		printf("PenPrmt = %lf\n", PenPrmt);
		printf("current loads\n");
		for (i = 1; i <= CurrSolution->Loads[0]; i++)
		{
			printf("%d ", CurrSolution->Loads[i]);
		}
		printf("\n");
		printf("CurrSolution->TotalVioLoad = %d\n", CurrSolution->TotalVioLoad);
		printf("Positions[0] = %d\n", Positions[0]);
	}*/
	
	for (i = 1; i < Positions[0]-1; i++)
	{
		RID1 = i;
		
		for (j = 2; j < Routes[i][0]-1; j++)
		{
			for (u = i+1; u < Positions[0]; u++)
			{
				RID2 = u;
				
				for (v = 2; v < Routes[u][0]; v++)
				{
					//if (ARPTask[Routes[u][v-1]].Head == ARPTask[Routes[u][v]].Tail)
					//	continue;
					
					AssignArray(CurrSolution->Loads, Neighbor.Loads);
					Neighbor.Loads[i] -= ARPTask[Routes[i][j]].Demand-ARPTask[Routes[u][v]].Demand;
					Neighbor.Loads[u] += ARPTask[Routes[i][j]].Demand-ARPTask[Routes[u][v]].Demand;			
					Neighbor.TotalVioLoad = CurrSolution->TotalVioLoad;
					
					if (ARPTask[Routes[i][j]].Demand > ARPTask[Routes[u][v]].Demand)
					{
				  	if (Neighbor.Loads[i] > Cap)
					  {
		  				Neighbor.TotalVioLoad -= ARPTask[Routes[i][j]].Demand-ARPTask[Routes[u][v]].Demand;
	  				}
		  			else if (Neighbor.Loads[i] > Cap-ARPTask[Routes[i][j]].Demand+ARPTask[Routes[u][v]].Demand)
			  		{
				  		Neighbor.TotalVioLoad -= Neighbor.Loads[i]+ARPTask[Routes[i][j]].Demand-ARPTask[Routes[u][v]].Demand-Cap;
					  }
  					
	  				if (Neighbor.Loads[u] > Cap+ARPTask[Routes[i][j]].Demand-ARPTask[Routes[u][v]].Demand)
		  			{
			  			Neighbor.TotalVioLoad += ARPTask[Routes[i][j]].Demand-ARPTask[Routes[u][v]].Demand;
				  	}
					  else if (Neighbor.Loads[u] > Cap)
					  {
  						Neighbor.TotalVioLoad += Neighbor.Loads[u]-Cap;
	  				}
	  			}
	  			else
	  			{
	  				if (Neighbor.Loads[u] > Cap)
					  {
		  				Neighbor.TotalVioLoad -= ARPTask[Routes[u][v]].Demand-ARPTask[Routes[i][j]].Demand;
	  				}
		  			else if (Neighbor.Loads[u] > Cap-ARPTask[Routes[u][v]].Demand+ARPTask[Routes[i][j]].Demand)
			  		{
				  		Neighbor.TotalVioLoad -= Neighbor.Loads[u]+ARPTask[Routes[u][v]].Demand-ARPTask[Routes[i][j]].Demand-Cap;
					  }
  					
	  				if (Neighbor.Loads[i] > Cap+ARPTask[Routes[u][v]].Demand-ARPTask[Routes[i][j]].Demand)
		  			{
			  			Neighbor.TotalVioLoad += ARPTask[Routes[u][v]].Demand-ARPTask[Routes[i][j]].Demand;
				  	}
					  else if (Neighbor.Loads[i] > Cap)
					  {
  						Neighbor.TotalVioLoad += Neighbor.Loads[i]-Cap;
	  				}
	  			}
					
					Neighbor.TotalCost = CurrSolution->TotalCost-MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[Routes[i][j]].Tail]
					-MinCost[ARPTask[Routes[i][j]].Head][ARPTask[Routes[i][j+1]].Tail]
					-MinCost[ARPTask[Routes[u][v-1]].Head][ARPTask[Routes[u][v]].Tail]
					-MinCost[ARPTask[Routes[u][v]].Head][ARPTask[Routes[u][v+1]].Tail]
					+MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[Routes[u][v]].Tail]
					+MinCost[ARPTask[Routes[u][v]].Head][ARPTask[Routes[i][j+1]].Tail]
					+MinCost[ARPTask[Routes[u][v-1]].Head][ARPTask[Routes[i][j]].Tail]
					+MinCost[ARPTask[Routes[i][j]].Head][ARPTask[Routes[u][v+1]].Tail];
					
					/*if (Neighbor.TotalCost < BestFsbFitness && Neighbor.TotalVioLoad > 0)
					{
						RepairInfeasibility(&Neighbor, ARPTask, MinCost, NRE, NRA, Cap);
					}*/
					
					count ++;
					Neighbor.Fitness = Neighbor.TotalCost+PenPrmt*Neighbor.TotalVioLoad;
					
					if (TabuList[Routes[i][j]][u] == 0 || TabuList[Routes[u][v]][i] == 0 || (Neighbor.TotalVioLoad > 0 
						&& Neighbor.Fitness < BestFitness)	|| (Neighbor.TotalVioLoad == 0 && Neighbor.Fitness < BestFsbFitness))
					{
  					if (Neighbor.Fitness < BestSWAPNeighbor->Fitness)
	  				{
		  				MovedTasks[1] = Routes[i][j];
			  	  	MovedTasks[2] = Routes[u][v];
				    	Besti = i;
				    	Bestj = j;
				  	  Bestu = u;
				  	  Bestv = v;
				  	  ChangedRoutesID[0] = RID1;
			  			ChangedRoutesID[1] = RID2;
				  	  
  				  	BestSWAPNeighbor->TotalCost = Neighbor.TotalCost;
	    				AssignArray(Neighbor.Loads, BestSWAPNeighbor->Loads);
		   				BestSWAPNeighbor->TotalVioLoad = Neighbor.TotalVioLoad;
		    			BestSWAPNeighbor->Fitness = Neighbor.Fitness;
				  	}
				  }
					
					
					w = ARPTask[Routes[i][j]].Inv;
					
					Neighbor.TotalCost = CurrSolution->TotalCost-MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[Routes[i][j]].Tail]
					-MinCost[ARPTask[Routes[i][j]].Head][ARPTask[Routes[i][j+1]].Tail]
					-MinCost[ARPTask[Routes[u][v-1]].Head][ARPTask[Routes[u][v]].Tail]
					-MinCost[ARPTask[Routes[u][v]].Head][ARPTask[Routes[u][v+1]].Tail]
					+MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[Routes[u][v]].Tail]
					+MinCost[ARPTask[Routes[u][v]].Head][ARPTask[Routes[i][j+1]].Tail]
					+MinCost[ARPTask[Routes[u][v-1]].Head][ARPTask[w].Tail]+MinCost[ARPTask[w].Head][ARPTask[Routes[u][v+1]].Tail];
					
					/*if (Neighbor.TotalCost < BestFsbFitness && Neighbor.TotalVioLoad > 0)
					{
						RepairInfeasibility(&Neighbor, ARPTask, MinCost, NRE, NRA, Cap);
					}*/
					
					count ++;
					Neighbor.Fitness = Neighbor.TotalCost+PenPrmt*Neighbor.TotalVioLoad;
					
					if (TabuList[Routes[i][j]][u] == 0 || TabuList[Routes[u][v]][i] == 0 || (Neighbor.TotalVioLoad > 0 
						&& Neighbor.Fitness < BestFitness)	|| (Neighbor.TotalVioLoad == 0 && Neighbor.Fitness < BestFsbFitness))
					{
  					if (Neighbor.Fitness < BestSWAPNeighbor->Fitness)
	  				{
		  				MovedTasks[1] = w;
			  	  	MovedTasks[2] = Routes[u][v];
			  	  	Besti = i;
				    	Bestj = j;
				    	Bestu = u;
				  	  Bestv = v;
				  	  ChangedRoutesID[0] = RID1;
			  			ChangedRoutesID[1] = RID2;
				  	  
  				  	BestSWAPNeighbor->TotalCost = Neighbor.TotalCost;
	    				AssignArray(Neighbor.Loads, BestSWAPNeighbor->Loads);
		   				BestSWAPNeighbor->TotalVioLoad = Neighbor.TotalVioLoad;
		    			BestSWAPNeighbor->Fitness = Neighbor.Fitness;
				  	}
					}
					
					
					z = ARPTask[Routes[u][v]].Inv;
					
					Neighbor.TotalCost = CurrSolution->TotalCost-MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[Routes[i][j]].Tail]
					-MinCost[ARPTask[Routes[i][j]].Head][ARPTask[Routes[i][j+1]].Tail]
					-MinCost[ARPTask[Routes[u][v-1]].Head][ARPTask[Routes[u][v]].Tail]
					-MinCost[ARPTask[Routes[u][v]].Head][ARPTask[Routes[u][v+1]].Tail]
					+MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[z].Tail]+MinCost[ARPTask[z].Head][ARPTask[Routes[i][j+1]].Tail]
					+MinCost[ARPTask[Routes[u][v-1]].Head][ARPTask[Routes[i][j]].Tail]
					+MinCost[ARPTask[Routes[i][j]].Head][ARPTask[Routes[u][v+1]].Tail];
					
					/*if (Neighbor.TotalCost < BestFsbFitness && Neighbor.TotalVioLoad > 0)
					{
						RepairInfeasibility(&Neighbor, ARPTask, MinCost, NRE, NRA, Cap);
					}*/
					
					count ++;
					Neighbor.Fitness = Neighbor.TotalCost+PenPrmt*Neighbor.TotalVioLoad;
					
					if (TabuList[Routes[i][j]][u] == 0 || TabuList[Routes[u][v]][i] == 0 || (Neighbor.TotalVioLoad > 0 
						&& Neighbor.Fitness < BestFitness)	|| (Neighbor.TotalVioLoad == 0 && Neighbor.Fitness < BestFsbFitness))
					{
  					if (Neighbor.Fitness < BestSWAPNeighbor->Fitness)
	  				{
		  				MovedTasks[1] = Routes[i][j];
		  		  	MovedTasks[2] = z;
			  	  	Besti = i;
				    	Bestj = j;
				    	Bestu = u;
				  	  Bestv = v;
				  	  ChangedRoutesID[0] = RID1;
			  			ChangedRoutesID[1] = RID2;
			  			
  				  	BestSWAPNeighbor->TotalCost = Neighbor.TotalCost;
	    				AssignArray(Neighbor.Loads, BestSWAPNeighbor->Loads);
		   				BestSWAPNeighbor->TotalVioLoad = Neighbor.TotalVioLoad;
		    			BestSWAPNeighbor->Fitness = Neighbor.Fitness;
				  	}
					}
					
					
					Neighbor.TotalCost = CurrSolution->TotalCost-MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[Routes[i][j]].Tail]
					-MinCost[ARPTask[Routes[i][j]].Head][ARPTask[Routes[i][j+1]].Tail]
					-MinCost[ARPTask[Routes[u][v-1]].Head][ARPTask[Routes[u][v]].Tail]
					-MinCost[ARPTask[Routes[u][v]].Head][ARPTask[Routes[u][v+1]].Tail]
					+MinCost[ARPTask[Routes[i][j-1]].Head][ARPTask[z].Tail]+MinCost[ARPTask[z].Head][ARPTask[Routes[i][j+1]].Tail]
					+MinCost[ARPTask[Routes[u][v-1]].Head][ARPTask[w].Tail]+MinCost[ARPTask[w].Head][ARPTask[Routes[u][v+1]].Tail];
					
					/*if (Neighbor.TotalCost < BestFsbFitness && Neighbor.TotalVioLoad > 0)
					{
						RepairInfeasibility(&Neighbor, ARPTask, MinCost, NRE, NRA, Cap);
					}*/
					
					count ++;
					Neighbor.Fitness = Neighbor.TotalCost+PenPrmt*Neighbor.TotalVioLoad;
					
					if (TabuList[Routes[i][j]][u] == 0 || TabuList[Routes[u][v]][i] == 0 || (Neighbor.TotalVioLoad > 0 
						&& Neighbor.Fitness < BestFitness)	|| (Neighbor.TotalVioLoad == 0 && Neighbor.Fitness < BestFsbFitness))
					{
  					if (Neighbor.Fitness < BestSWAPNeighbor->Fitness)
	  				{
		  				MovedTasks[1] = w;
			  	  	MovedTasks[2] = z;
				    	Besti = i;
				    	Bestj = j;
				  	  Bestu = u;
				  	  Bestv = v;
				  	  ChangedRoutesID[0] = RID1;
			  			ChangedRoutesID[1] = RID2;
				  	  
  				  	BestSWAPNeighbor->TotalCost = Neighbor.TotalCost;
	    				AssignArray(Neighbor.Loads, BestSWAPNeighbor->Loads);
		   				BestSWAPNeighbor->TotalVioLoad = Neighbor.TotalVioLoad;
		    			BestSWAPNeighbor->Fitness = Neighbor.Fitness;
				  	}
				  }
				}
			}
		}
	}
	
	BestSWAPNeighbor->Sequence[0] = 1;
	
	for (k = 1; k < Positions[0]; k++)
 	{
  	if (k == Besti)
	  {
			DeleteElement(Routes[k], Bestj);
			AddElement(Routes[k], MovedTasks[2], Bestj);	
			BestSWAPNeighbor->Sequence[0] --;
			JoinArray(BestSWAPNeighbor->Sequence, Routes[k]);
		}
 		else if (k == Bestu)
  	{
	  	DeleteElement(Routes[k], Bestv);
		  AddElement(Routes[k], MovedTasks[1], Bestv);
			BestSWAPNeighbor->Sequence[0] --;
			JoinArray(BestSWAPNeighbor->Sequence, Routes[k]);
		}
		else
		{
 		  BestSWAPNeighbor->Sequence[0] --;
    	JoinArray(BestSWAPNeighbor->Sequence, Routes[k]);
    }
	}
	
	return count;
	
	/*if (PenPrmt > 1000)
	{
		printf("besti = %d, bestj = %d, bestu = %d, bestv = %d, total vioload = %d\n", Besti, Bestj, Bestu, Bestv, BestSWAPNeighbor->TotalVioLoad);
		printf("best neighbor loads\n");
		for (i = 1; i <= BestSWAPNeighbor->Loads[0]; i++)
		{
			printf("%d ", BestSWAPNeighbor->Loads[i]);
		}
		printf("\n");
		exit(0);
	}*/
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void RepairInfeasibility(struct Individual *Indi, const struct Task *ARPTask, int (*MinCost)[141], int NRE, int NRA, int Cap)
{
	int i, j, k, RoutesNum;
	int NodeRoutes[50][250], TaskRoutes[50][250];
	int InRoutes[NRE+NRA+1][50], CheckMark[NRE+NRA+1];
	int NO_Task = 2*NRE+NRA;
	
	//printf("indi total cost = %d, total vioload = %d\n", Indi->TotalCost, Indi->TotalVioLoad);
	
	RoutesNum = 0;
	for (i = 1; i < Indi->Sequence[0]; i++)
	{
		if (Indi->Sequence[i] == 0)
		{
			TaskRoutes[RoutesNum][0] ++;
    	TaskRoutes[RoutesNum][TaskRoutes[RoutesNum][0]] = 0;
  		RoutesNum ++;
	  	TaskRoutes[RoutesNum][0] = 1;
	  	TaskRoutes[RoutesNum][1] = 0;
	  }
	  else
	  {
	  	TaskRoutes[RoutesNum][0] ++;
	  	TaskRoutes[RoutesNum][TaskRoutes[RoutesNum][0]] = Indi->Sequence[i];
	  }
	}
	
	TaskRoutes[RoutesNum][0] ++;
	TaskRoutes[RoutesNum][TaskRoutes[RoutesNum][0]] = 0;
	
	for (i = 1; i <= RoutesNum; i++)
	{
		NodeRoutes[i][0] = 0;
		
		for (j = 1; j < TaskRoutes[i][0]; j++)
		{
			for (k = 1; k <= ShortestPath[ARPTask[TaskRoutes[i][j]].Head][ARPTask[TaskRoutes[i][j+1]].Tail][0]; k++)
			{
				NodeRoutes[i][0] ++;
				NodeRoutes[i][NodeRoutes[i][0]] = ShortestPath[ARPTask[TaskRoutes[i][j]].Head][ARPTask[TaskRoutes[i][j+1]].Tail][k];
			}
		}
	}
	
	for (i = 1; i <= NRE+NRA; i++)
	{
		InRoutes[i][0] = 0;
	}
	
	for (i = 1; i <= RoutesNum; i++)
	{
		memset(CheckMark, 0, sizeof(CheckMark));
		
		for (j = 1; j < NodeRoutes[i][0]; j++)
		{
			int TID = FindTask(NodeRoutes[i][j], NodeRoutes[i][j+1], ARPTask, NO_Task);
			if (TID > NRE)
			{
				TID -= NRE;
			}
			
			if (TID == 0)
				continue;
			
			if (!CheckMark[TID])
  		{
	  		CheckMark[TID] = 1;
		  	InRoutes[TID][0] ++;
			  InRoutes[TID][InRoutes[TID][0]] = i;
		  }
		}
	}
	
	/*for (i = 1; i <= RoutesNum; i++)
	{
		printf("task route %d\n", i);
		for (j = 1; j <= TaskRoutes[i][0]; j++)
		{
			printf("%d ", TaskRoutes[i][j]);
		}
		printf("\n");
	}
	
	for (i = 1; i <= RoutesNum; i++)
	{
		printf("node route %d\n", i);
		for (j = 1; j <= NodeRoutes[i][0]; j++)
		{
			printf("%d ", NodeRoutes[i][j]);
		}
		printf("\n");
	}
	
	for (i = 1; i <= NRE+NRA; i++)
	{
		printf("task (%d, %d) is in routes: ", ARPTask[i].Tail, ARPTask[i].Head);
		for (j = 1; j <= InRoutes[i][0]; j++)
		{
			printf("%d ", InRoutes[i][j]);
		}
		printf("\n");
	}*/
	
	int FreeTasks[NRE+NRA+1];
	FreeTasks[0] = 0;
	
	for (i = 1; i <= NRE+NRA; i++)
	{
		if (InRoutes[i][0] == 1)
			continue;
		
		FreeTasks[0] ++;
		FreeTasks[FreeTasks[0]] = i;
	}
	
	struct TaskAssignment
	{
		int Assignment[NRE+NRA+1];
		int Loads[RoutesNum+1];
		int TotalVioLoad;
	};
	
	struct TaskAssignment CurrTA, NeighTA, NextTA, BestTA;
	
	memset(CurrTA.Assignment, 0, sizeof(CurrTA.Assignment));
	memset(CurrTA.Loads, 0, sizeof(CurrTA.Loads));
	CurrTA.Loads[0] = RoutesNum;
	
	for (i = 1; i <= NRE+NRA; i++)
	{
		if (InRoutes[i][0] == 1)
		{
			CurrTA.Assignment[i] = InRoutes[i][1];
			CurrTA.Loads[InRoutes[i][1]] += ARPTask[i].Demand;
		}
	}
	
	int LeftTasks[NRE+NRA+1], RouteCandDemands[RoutesNum+1], CandRoutes[NRE+NRA+1][50];
	AssignArray(FreeTasks, LeftTasks);
	memset(RouteCandDemands, 0, sizeof(RouteCandDemands));
	for (i = 1; i <= NRE+NRA; i++)
	{
		CandRoutes[i][0] = 0;
		for (j = 1; j <= InRoutes[i][0]; j++)
		{
			if (CurrTA.Loads[InRoutes[i][j]] >= Cap)
				continue;
			
			CandRoutes[i][0] ++;
			CandRoutes[i][CandRoutes[i][0]] = InRoutes[i][j];
		}
	}
	
	for (i = 1; i <= LeftTasks[0]; i++)
	{
		for (j = 1; j <= InRoutes[LeftTasks[i]][0]; j++)
		{
			RouteCandDemands[InRoutes[LeftTasks[i]][j]] += ARPTask[LeftTasks[i]].Demand;
		}
	}
	
	int SelID, AssignedRouteID;
	int n;
	for (n = 1; n <= FreeTasks[0]; n++)
	{
		/*printf("assignment\n");
  	for (i = 1; i <= NRE+NRA; i++)
	  {
  		printf("%d ", CurrTA.Assignment[i]);
	  }
  	printf("\n");
	  printf("Loads\n");
  	for (i = 1; i <= RoutesNum; i++)
  	{
  		printf("%d ", CurrTA.Loads[i]);
  	}
  	printf("\n");*/
  	
		SelID = 0;
		for (i = 1; i <= LeftTasks[0]; i++)
		{
			if (SelID == 0)
			{
				SelID = i;
			}
			else if (CandRoutes[LeftTasks[i]][0] < CandRoutes[LeftTasks[SelID]][0])
			{
				SelID = i;
			}
			else if (CandRoutes[LeftTasks[i]][0] == CandRoutes[LeftTasks[SelID]][0])
			{
				if (ARPTask[LeftTasks[i]].Demand > ARPTask[LeftTasks[SelID]].Demand)
				{
					SelID = i;
				}
			}
		}
		
		AssignedRouteID = 0;
		for (i = 1; i <= InRoutes[LeftTasks[SelID]][0]; i++)
		{
			if (AssignedRouteID == 0)
			{
				AssignedRouteID = i;
			}
			else if (CurrTA.Loads[InRoutes[LeftTasks[SelID]][i]]+ARPTask[LeftTasks[SelID]].Demand <
				CurrTA.Loads[InRoutes[LeftTasks[SelID]][AssignedRouteID]]+ARPTask[LeftTasks[SelID]].Demand)
			{
				AssignedRouteID = i;
			}
			else if (CurrTA.Loads[InRoutes[LeftTasks[SelID]][i]]+ARPTask[LeftTasks[SelID]].Demand ==
				CurrTA.Loads[InRoutes[LeftTasks[SelID]][AssignedRouteID]]+ARPTask[LeftTasks[SelID]].Demand)
			{
				if (RouteCandDemands[InRoutes[LeftTasks[SelID]][i]]+CurrTA.Loads[InRoutes[LeftTasks[SelID]][i]] >
					RouteCandDemands[InRoutes[LeftTasks[SelID]][AssignedRouteID]]+
					CurrTA.Loads[InRoutes[LeftTasks[SelID]][AssignedRouteID]])
				{
					AssignedRouteID = i;
				}
			}
		}
		
		CurrTA.Assignment[LeftTasks[SelID]] = InRoutes[LeftTasks[SelID]][AssignedRouteID];
		CurrTA.Loads[CurrTA.Assignment[LeftTasks[SelID]]] += ARPTask[LeftTasks[SelID]].Demand;
		for (i = 1; i <= InRoutes[LeftTasks[SelID]][0]; i++)
		{
			RouteCandDemands[InRoutes[LeftTasks[SelID]][i]] -= ARPTask[LeftTasks[SelID]].Demand;
		}
		
		if (CurrTA.Loads[CurrTA.Assignment[LeftTasks[SelID]]] >= Cap)
		{
			for (i = 1; i <= NRE+NRA; i++)
    	{
    		for (j = 1; j <= CandRoutes[i][0]; j++)
    		{
    			if (CandRoutes[i][j] == CurrTA.Assignment[LeftTasks[SelID]])
    			{
    				DeleteElement(CandRoutes[i], j);
    				break;
    			}
    		}
    	}
		}
		
		DeleteElement(LeftTasks, SelID);
	}
	
	CurrTA.TotalVioLoad = 0;
	for (i = 1; i <= RoutesNum; i++)
	{
		if (CurrTA.Loads[i] > Cap)
			CurrTA.TotalVioLoad += CurrTA.Loads[i]-Cap;
	}
	
	BestTA = CurrTA;
	
	/*printf("initial assignment\n");
	for (i = 1; i <= NRE+NRA; i++)
	{
		printf("%d ", CurrTA.Assignment[i]);
	}
	printf("\n");
	printf("initial Loads\n");
	for (i = 1; i <= RoutesNum; i++)
	{
		printf("%d ", CurrTA.Loads[i]);
	}
	printf("\n");
	printf("initial total vioload = %d\n", CurrTA.TotalVioLoad);*/
	
	int TabuList[NRE+NRA+1];
	int TabuTenure = FreeTasks[0]/2;
	int TabuTask, Tabu;
	
	memset(TabuList, 0, sizeof(TabuList));
	
	int count = 0;
	int stlcount = 0;
	while (BestTA.TotalVioLoad > 0)
	{
		count ++;
		stlcount ++;
		NextTA.TotalVioLoad = INF;
		
		for (i = 1; i <= FreeTasks[0]; i++)
		{
			for (j = 1; j <= InRoutes[FreeTasks[i]][0]; j++)
			{
				if (InRoutes[FreeTasks[i]][j] == CurrTA.Assignment[FreeTasks[i]])
					continue;
				
				NeighTA = CurrTA;
				NeighTA.Assignment[FreeTasks[i]] = InRoutes[FreeTasks[i]][j];
				NeighTA.Loads[CurrTA.Assignment[FreeTasks[i]]] -= ARPTask[FreeTasks[i]].Demand;
				NeighTA.Loads[NeighTA.Assignment[FreeTasks[i]]] += ARPTask[FreeTasks[i]].Demand;
				
				if (CurrTA.Loads[NeighTA.Assignment[FreeTasks[i]]] >= Cap)
				{
					NeighTA.TotalVioLoad += ARPTask[FreeTasks[i]].Demand;
				}
				else if (NeighTA.Loads[NeighTA.Assignment[FreeTasks[i]]] > Cap)
				{
					NeighTA.TotalVioLoad += NeighTA.Loads[NeighTA.Assignment[FreeTasks[i]]]-Cap;
				}
				
				if (NeighTA.Loads[CurrTA.Assignment[FreeTasks[i]]] >= Cap)
				{
					NeighTA.TotalVioLoad -= ARPTask[FreeTasks[i]].Demand;
				}
				else if (CurrTA.Loads[CurrTA.Assignment[FreeTasks[i]]] > Cap)
				{
					NeighTA.TotalVioLoad -= CurrTA.Loads[CurrTA.Assignment[FreeTasks[i]]]-Cap;
				}
				
				Tabu = 0;
				if (TabuList[FreeTasks[i]] > 0 && NeighTA.TotalVioLoad >= BestTA.TotalVioLoad)
					Tabu = 1;
				
				if (Tabu)
					continue;
				
				if (NeighTA.TotalVioLoad < NextTA.TotalVioLoad)
				{
					NextTA = NeighTA;
					TabuTask = FreeTasks[i];
				}
			}
		}
		
		for (i = 1; i <= NRE+NRA; i++)
		{
			if (TabuList[i] > 0)
				TabuList[i] --;
		}
		
		TabuList[TabuTask] = TabuTenure;
		CurrTA = NextTA;
		
		if (CurrTA.TotalVioLoad < BestTA.TotalVioLoad)
		{
			stlcount = 0;
			BestTA = CurrTA;
		}
		
		if (count == 2*(NRE+NRA) || stlcount == (NRE+NRA)/2)
			break;
	}
	
	if (BestTA.TotalVioLoad > Indi->TotalVioLoad)
		return;
	
	int Served[NRE+NRA+1];
	memset(Served, 0, sizeof(Served));
	
	Indi->Sequence[0] = 1;
	Indi->Sequence[1] = 0;
	
	for (i = 1; i <= RoutesNum; i++)
	{
		for (j = 1; j < NodeRoutes[i][0]; j++)
		{
  		int TID = FindTask(NodeRoutes[i][j], NodeRoutes[i][j+1], ARPTask, NO_Task);
  		int TmpTID = TID;
  		
  		if (TmpTID > NRE)
			{
				TmpTID -= NRE;
			}
			
			if (TmpTID == 0)
				continue;
			
			if (BestTA.Assignment[TmpTID] == i && !Served[TmpTID])
			{
				Served[TmpTID] = 1;
				Indi->Sequence[0] ++;
				Indi->Sequence[Indi->Sequence[0]] = TID;
			}
  	}
  	
  	if (Indi->Sequence[Indi->Sequence[0]] != 0)
  	{
  		Indi->Sequence[0] ++;
			Indi->Sequence[Indi->Sequence[0]] = 0;
  	}
	}
	
	for (i = BestTA.Loads[0]; i > 0; i--)
	{
		if (BestTA.Loads[i] == 0)
			DeleteElement(BestTA.Loads, i);
	}
	
	//GetLoads(Indi->Loads, Indi->Sequence, ARPTask);
	Indi->TotalCost = CalcTaskSeqTotalCost(Indi->Sequence, ARPTask, MinCost);
	AssignArray(BestTA.Loads, Indi->Loads);
	Indi->TotalVioLoad = BestTA.TotalVioLoad;
	
	if (!Legal(Indi->Sequence, ARPTask, NRE, NRA))
	{
		printf("assignment\n");
		for (i = 1; i <= NRE+NRA; i++)
		{
			printf("%d ", BestTA.Assignment[i]);
		}
		printf("\n");
		printf("seq\n");
		for (i = 1; i <= Indi->Sequence[0]; i++)
		{
			printf("%d ", Indi->Sequence[i]);
		}
		printf("\n");
		printf("ERROR\n");
		exit(0);
	}
	
	/*printf("final assignment\n");
	for (i = 1; i <= NRE+NRA; i++)
	{
		printf("%d ", BestTA.Assignment[i]);
	}
	printf("\n");
	printf("final Loads\n");
	for (i = 1; i <= RoutesNum; i++)
	{
		printf("%d ", BestTA.Loads[i]);
	}
	printf("\n");
	printf("final total vioload = %d\n", BestTA.TotalVioLoad);*/
	
	/*printf("indi sequence\n");
	for (i = 1; i <= Indi->Sequence[0]; i++)
	{
		printf("%d ", Indi->Sequence[i]);
	}
	printf("\n");
	printf("indi loads\n");
	for (i = 1; i <= Indi->Loads[0]; i++)
	{
		printf("%d ", Indi->Loads[i]);
	}
	printf("\n");
	printf("indi total cost = %d, total vioload = %d\n", Indi->TotalCost, Indi->TotalVioLoad);*/
}
