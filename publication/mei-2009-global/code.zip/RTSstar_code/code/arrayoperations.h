
struct Task;

void DeleteElement(int *Array, int k);

void AddElement(int *Array, int a, int k);

void PMultiply(int *MultiArray, int *Array1, int *Array2);

void ReverseDirection(int *Array, int k1, int k2);

void FindPositions(int *Array, int a, int *Position);

int FindArc(int Tail, int Head, const struct Task *ARPTask, int NO_Arc);

int CalcTaskSeqTotalCost(int *Array, const struct Task *ARPTask, int (*MinCost)[141]);

void RemoveDelimiter(int *Array);

int Split(int *SplittedArray, int *Array, const struct Task *ARPTask, int (*MinCost)[141], int Cap);

int FleetLimitedSplit(int *SplittedArray, int *Array, const struct Task *ARPTask, int (*MinCost)[141], int Cap);

void RandPerm(int *Array, int n);

void RemoveRedundantElements(int *Array);

void AssignArray(int *Array1, int *Array2);

void AssignSubArray(int *Array1, int k1, int k2, int *Array2);

int min(int *Array);

int max(int *Array);

void JoinArray(int *JointArray, int *Array);

int Legal(int *Solution, const struct Task *ARPTask, int NRE, int NRA);

int FindTask(int a, int b, const struct Task *ARPTask, int NO_Task);

int RandChoose(int n);

int Equal(int *Array1, int *Array2);

void GetLoads(int *Loads, int *Seq, const struct Task *ARPTask);

int GetTotalVioLoad(int *Loads, int Cap);
