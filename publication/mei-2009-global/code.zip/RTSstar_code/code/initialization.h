
extern int NO_ReqEdge;
extern int NO_ReqArc;
extern int NO_Vehicles;

struct Task
{
	int Tail;
	int Head;
	int DeadCost;
	int ServCost;
	int Demand;
	int Inv;
};

struct Arc
{
	int Tail;
	int Head;
	int TravCost;
};

struct Individual
{
	int Sequence[250];
	int Assignment[250];
	int TotalCost;
	int Loads[50];
	int TotalVioLoad;
	double Fitness;
};

void RandScanningInit(struct Individual *Indi, const struct Task *ARPTask, int (*MinCost)[141], int NRE, int NRA, int Cap,
int NVeh);

void RandAssignInit(struct Individual *Indi, const struct Task *ARPTask, int (*MinCost)[141], int NRE, int NRA, int Cap,
int NVeh);

void PathScanning(struct Individual *PSSolution, const struct Task *ARPTask, int *ServMark, int (*MinCost)[141],
int NRE, int NRA, int NVeh, int Cap);

void RandPermInit(int *RPIndi, const struct Task *ARPTask, int NRE, int NRA);

void ModifiedDijkstra(int (*MinCost)[141], int (*Cost)[141], int NVer);
